/*     */ package javax.activation;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeType
/*     */   implements Externalizable
/*     */ {
/*     */   private String primaryType;
/*     */   private String subType;
/*     */   private MimeTypeParameterList parameters;
/*     */   private static final String TSPECIALS = "()<>@,;:/[]?=\\\"";
/*     */   
/*     */   public MimeType() {
/*  65 */     this.primaryType = "application";
/*  66 */     this.subType = "*";
/*  67 */     this.parameters = new MimeTypeParameterList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeType(String rawdata) throws MimeTypeParseException {
/*  77 */     parse(rawdata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeType(String primary, String sub) throws MimeTypeParseException {
/*  91 */     if (isValidToken(primary)) {
/*  92 */       this.primaryType = primary.toLowerCase(Locale.ENGLISH);
/*     */     } else {
/*  94 */       throw new MimeTypeParseException("Primary type is invalid.");
/*     */     } 
/*     */ 
/*     */     
/*  98 */     if (isValidToken(sub)) {
/*  99 */       this.subType = sub.toLowerCase(Locale.ENGLISH);
/*     */     } else {
/* 101 */       throw new MimeTypeParseException("Sub type is invalid.");
/*     */     } 
/*     */     
/* 104 */     this.parameters = new MimeTypeParameterList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(String rawdata) throws MimeTypeParseException {
/* 111 */     int slashIndex = rawdata.indexOf('/');
/* 112 */     int semIndex = rawdata.indexOf(';');
/* 113 */     if (slashIndex < 0 && semIndex < 0)
/*     */     {
/*     */       
/* 116 */       throw new MimeTypeParseException("Unable to find a sub type."); } 
/* 117 */     if (slashIndex < 0 && semIndex >= 0)
/*     */     {
/*     */       
/* 120 */       throw new MimeTypeParseException("Unable to find a sub type."); } 
/* 121 */     if (slashIndex >= 0 && semIndex < 0) {
/*     */       
/* 123 */       this
/* 124 */         .primaryType = rawdata.substring(0, slashIndex).trim().toLowerCase(Locale.ENGLISH);
/* 125 */       this
/* 126 */         .subType = rawdata.substring(slashIndex + 1).trim().toLowerCase(Locale.ENGLISH);
/* 127 */       this.parameters = new MimeTypeParameterList();
/* 128 */     } else if (slashIndex < semIndex) {
/*     */       
/* 130 */       this
/* 131 */         .primaryType = rawdata.substring(0, slashIndex).trim().toLowerCase(Locale.ENGLISH);
/* 132 */       this
/* 133 */         .subType = rawdata.substring(slashIndex + 1, semIndex).trim().toLowerCase(Locale.ENGLISH);
/* 134 */       this.parameters = new MimeTypeParameterList(rawdata.substring(semIndex));
/*     */     }
/*     */     else {
/*     */       
/* 138 */       throw new MimeTypeParseException("Unable to find a sub type.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     if (!isValidToken(this.primaryType)) {
/* 145 */       throw new MimeTypeParseException("Primary type is invalid.");
/*     */     }
/*     */     
/* 148 */     if (!isValidToken(this.subType)) {
/* 149 */       throw new MimeTypeParseException("Sub type is invalid.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrimaryType() {
/* 158 */     return this.primaryType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrimaryType(String primary) throws MimeTypeParseException {
/* 170 */     if (!isValidToken(this.primaryType))
/* 171 */       throw new MimeTypeParseException("Primary type is invalid."); 
/* 172 */     this.primaryType = primary.toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubType() {
/* 181 */     return this.subType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubType(String sub) throws MimeTypeParseException {
/* 193 */     if (!isValidToken(this.subType))
/* 194 */       throw new MimeTypeParseException("Sub type is invalid."); 
/* 195 */     this.subType = sub.toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeTypeParameterList getParameters() {
/* 204 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String name) {
/* 215 */     return this.parameters.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String name, String value) {
/* 226 */     this.parameters.set(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeParameter(String name) {
/* 235 */     this.parameters.remove(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 242 */     return getBaseType() + this.parameters.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBaseType() {
/* 252 */     return this.primaryType + "/" + this.subType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(MimeType type) {
/* 263 */     return (this.primaryType.equals(type.getPrimaryType()) && (this.subType
/* 264 */       .equals("*") || type
/* 265 */       .getSubType().equals("*") || this.subType
/* 266 */       .equals(type.getSubType())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(String rawdata) throws MimeTypeParseException {
/* 278 */     return match(new MimeType(rawdata));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 291 */     out.writeUTF(toString());
/* 292 */     out.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/*     */     try {
/* 309 */       parse(in.readUTF());
/* 310 */     } catch (MimeTypeParseException e) {
/* 311 */       throw new IOException(e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isTokenChar(char c) {
/* 321 */     return (c > ' ' && c < '' && "()<>@,;:/[]?=\\\"".indexOf(c) < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isValidToken(String s) {
/* 328 */     int len = s.length();
/* 329 */     if (len > 0) {
/* 330 */       for (int i = 0; i < len; i++) {
/* 331 */         char c = s.charAt(i);
/* 332 */         if (!isTokenChar(c)) {
/* 333 */           return false;
/*     */         }
/*     */       } 
/* 336 */       return true;
/*     */     } 
/* 338 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\MimeType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */