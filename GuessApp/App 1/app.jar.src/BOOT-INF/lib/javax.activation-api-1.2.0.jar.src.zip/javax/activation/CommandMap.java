/*     */ package javax.activation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CommandMap
/*     */ {
/*  56 */   private static CommandMap defaultCommandMap = null;
/*  57 */   private static Map<ClassLoader, CommandMap> map = new WeakHashMap<ClassLoader, CommandMap>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized CommandMap getDefaultCommandMap() {
/*  78 */     if (defaultCommandMap != null) {
/*  79 */       return defaultCommandMap;
/*     */     }
/*     */     
/*  82 */     ClassLoader tccl = SecuritySupport.getContextClassLoader();
/*  83 */     CommandMap def = map.get(tccl);
/*  84 */     if (def == null) {
/*  85 */       def = new MailcapCommandMap();
/*  86 */       map.put(tccl, def);
/*     */     } 
/*  88 */     return def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultCommandMap(CommandMap commandMap) {
/* 100 */     SecurityManager security = System.getSecurityManager();
/* 101 */     if (security != null) {
/*     */       
/*     */       try {
/* 104 */         security.checkSetFactory();
/* 105 */       } catch (SecurityException ex) {
/*     */ 
/*     */ 
/*     */         
/* 109 */         ClassLoader cl = CommandMap.class.getClassLoader();
/* 110 */         if (cl == null || cl.getParent() == null || cl != commandMap
/* 111 */           .getClass().getClassLoader()) {
/* 112 */           throw ex;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 117 */     map.remove(SecuritySupport.getContextClassLoader());
/* 118 */     defaultCommandMap = commandMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract CommandInfo[] getPreferredCommands(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo[] getPreferredCommands(String mimeType, DataSource ds) {
/* 146 */     return getPreferredCommands(mimeType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract CommandInfo[] getAllCommands(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo[] getAllCommands(String mimeType, DataSource ds) {
/* 174 */     return getAllCommands(mimeType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract CommandInfo getCommand(String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandInfo getCommand(String mimeType, String cmdName, DataSource ds) {
/* 203 */     return getCommand(mimeType, cmdName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DataContentHandler createDataContentHandler(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataContentHandler createDataContentHandler(String mimeType, DataSource ds) {
/* 235 */     return createDataContentHandler(mimeType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getMimeTypes() {
/* 247 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\CommandMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */