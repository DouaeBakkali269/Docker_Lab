/*     */ package javax.activation;
/*     */ 
/*     */ import com.sun.activation.registries.LogSupport;
/*     */ import com.sun.activation.registries.MimeTypeFile;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimetypesFileTypeMap
/*     */   extends FileTypeMap
/*     */ {
/*     */   private MimeTypeFile[] DB;
/*     */   private static final int PROG = 0;
/*     */   private static final String defaultType = "application/octet-stream";
/*     */   private static final String confDir;
/*     */   
/*     */   static {
/* 102 */     String dir = null;
/*     */     try {
/* 104 */       dir = AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */           {
/*     */             public Object run() {
/* 107 */               String home = System.getProperty("java.home");
/* 108 */               String newdir = home + File.separator + "conf";
/* 109 */               File conf = new File(newdir);
/* 110 */               if (conf.exists()) {
/* 111 */                 return newdir + File.separator;
/*     */               }
/* 113 */               return home + File.separator + "lib" + File.separator;
/*     */             }
/*     */           });
/* 116 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 119 */     confDir = dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap() {
/* 126 */     Vector<MimeTypeFile> dbv = new Vector(5);
/* 127 */     MimeTypeFile mf = null;
/* 128 */     dbv.addElement(null);
/*     */     
/* 130 */     LogSupport.log("MimetypesFileTypeMap: load HOME");
/*     */     try {
/* 132 */       String user_home = System.getProperty("user.home");
/*     */       
/* 134 */       if (user_home != null) {
/* 135 */         String path = user_home + File.separator + ".mime.types";
/* 136 */         mf = loadFile(path);
/* 137 */         if (mf != null)
/* 138 */           dbv.addElement(mf); 
/*     */       } 
/* 140 */     } catch (SecurityException securityException) {}
/*     */     
/* 142 */     LogSupport.log("MimetypesFileTypeMap: load SYS");
/*     */     
/*     */     try {
/* 145 */       if (confDir != null) {
/* 146 */         mf = loadFile(confDir + "mime.types");
/* 147 */         if (mf != null)
/* 148 */           dbv.addElement(mf); 
/*     */       } 
/* 150 */     } catch (SecurityException securityException) {}
/*     */     
/* 152 */     LogSupport.log("MimetypesFileTypeMap: load JAR");
/*     */     
/* 154 */     loadAllResources(dbv, "META-INF/mime.types");
/*     */     
/* 156 */     LogSupport.log("MimetypesFileTypeMap: load DEF");
/* 157 */     mf = loadResource("/META-INF/mimetypes.default");
/*     */     
/* 159 */     if (mf != null) {
/* 160 */       dbv.addElement(mf);
/*     */     }
/* 162 */     this.DB = new MimeTypeFile[dbv.size()];
/* 163 */     dbv.copyInto((Object[])this.DB);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeTypeFile loadResource(String name) {
/* 170 */     InputStream clis = null;
/*     */     try {
/* 172 */       clis = SecuritySupport.getResourceAsStream(getClass(), name);
/* 173 */       if (clis != null) {
/* 174 */         MimeTypeFile mf = new MimeTypeFile(clis);
/* 175 */         if (LogSupport.isLoggable()) {
/* 176 */           LogSupport.log("MimetypesFileTypeMap: successfully loaded mime types file: " + name);
/*     */         }
/* 178 */         return mf;
/*     */       } 
/* 180 */       if (LogSupport.isLoggable()) {
/* 181 */         LogSupport.log("MimetypesFileTypeMap: not loading mime types file: " + name);
/*     */       }
/*     */     }
/* 184 */     catch (IOException e) {
/* 185 */       if (LogSupport.isLoggable())
/* 186 */         LogSupport.log("MimetypesFileTypeMap: can't load " + name, e); 
/* 187 */     } catch (SecurityException sex) {
/* 188 */       if (LogSupport.isLoggable())
/* 189 */         LogSupport.log("MimetypesFileTypeMap: can't load " + name, sex); 
/*     */     } finally {
/*     */       try {
/* 192 */         if (clis != null)
/* 193 */           clis.close(); 
/* 194 */       } catch (IOException iOException) {}
/*     */     } 
/* 196 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadAllResources(Vector<MimeTypeFile> v, String name) {
/* 203 */     boolean anyLoaded = false;
/*     */     try {
/*     */       URL[] urls;
/* 206 */       ClassLoader cld = null;
/*     */       
/* 208 */       cld = SecuritySupport.getContextClassLoader();
/* 209 */       if (cld == null)
/* 210 */         cld = getClass().getClassLoader(); 
/* 211 */       if (cld != null) {
/* 212 */         urls = SecuritySupport.getResources(cld, name);
/*     */       } else {
/* 214 */         urls = SecuritySupport.getSystemResources(name);
/* 215 */       }  if (urls != null) {
/* 216 */         if (LogSupport.isLoggable())
/* 217 */           LogSupport.log("MimetypesFileTypeMap: getResources"); 
/* 218 */         for (int i = 0; i < urls.length; i++) {
/* 219 */           URL url = urls[i];
/* 220 */           InputStream clis = null;
/* 221 */           if (LogSupport.isLoggable());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 254 */     catch (Exception ex) {
/* 255 */       if (LogSupport.isLoggable()) {
/* 256 */         LogSupport.log("MimetypesFileTypeMap: can't load " + name, ex);
/*     */       }
/*     */     } 
/*     */     
/* 260 */     if (!anyLoaded) {
/* 261 */       LogSupport.log("MimetypesFileTypeMap: !anyLoaded");
/* 262 */       MimeTypeFile mf = loadResource("/" + name);
/* 263 */       if (mf != null) {
/* 264 */         v.addElement(mf);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeTypeFile loadFile(String name) {
/* 272 */     MimeTypeFile mtf = null;
/*     */     
/*     */     try {
/* 275 */       mtf = new MimeTypeFile(name);
/* 276 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 279 */     return mtf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap(String mimeTypeFileName) throws IOException {
/* 290 */     this();
/* 291 */     this.DB[0] = new MimeTypeFile(mimeTypeFileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimetypesFileTypeMap(InputStream is) {
/* 301 */     this();
/*     */     try {
/* 303 */       this.DB[0] = new MimeTypeFile(is);
/* 304 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addMimeTypes(String mime_types) {
/* 316 */     if (this.DB[0] == null) {
/* 317 */       this.DB[0] = new MimeTypeFile();
/*     */     }
/* 319 */     this.DB[0].appendToRegistry(mime_types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType(File f) {
/* 331 */     return getContentType(f.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String getContentType(String filename) {
/* 344 */     int dot_pos = filename.lastIndexOf(".");
/*     */     
/* 346 */     if (dot_pos < 0) {
/* 347 */       return "application/octet-stream";
/*     */     }
/* 349 */     String file_ext = filename.substring(dot_pos + 1);
/* 350 */     if (file_ext.length() == 0) {
/* 351 */       return "application/octet-stream";
/*     */     }
/* 353 */     for (int i = 0; i < this.DB.length; i++) {
/* 354 */       if (this.DB[i] != null) {
/*     */         
/* 356 */         String result = this.DB[i].getMIMETypeString(file_ext);
/* 357 */         if (result != null)
/* 358 */           return result; 
/*     */       } 
/* 360 */     }  return "application/octet-stream";
/*     */   }
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\MimetypesFileTypeMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */