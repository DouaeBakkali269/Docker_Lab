/*     */ package javax.activation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SecuritySupport
/*     */ {
/*     */   public static ClassLoader getContextClassLoader() {
/*  58 */     return 
/*  59 */       AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>() {
/*     */           public Object run() {
/*  61 */             ClassLoader cl = null;
/*     */             try {
/*  63 */               cl = Thread.currentThread().getContextClassLoader();
/*  64 */             } catch (SecurityException securityException) {}
/*  65 */             return cl;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static InputStream getResourceAsStream(final Class c, final String name) throws IOException {
/*     */     try {
/*  73 */       return 
/*  74 */         AccessController.<InputStream>doPrivileged(new PrivilegedExceptionAction<InputStream>() {
/*     */             public Object run() throws IOException {
/*  76 */               return c.getResourceAsStream(name);
/*     */             }
/*     */           });
/*  79 */     } catch (PrivilegedActionException e) {
/*  80 */       throw (IOException)e.getException();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static URL[] getResources(final ClassLoader cl, final String name) {
/*  85 */     return 
/*  86 */       AccessController.<URL[]>doPrivileged(new PrivilegedAction<URL>() {
/*     */           public Object run() {
/*  88 */             URL[] ret = null;
/*     */             
/*  90 */             try { List<URL> v = new ArrayList();
/*  91 */               Enumeration<URL> e = cl.getResources(name);
/*  92 */               while (e != null && e.hasMoreElements()) {
/*  93 */                 URL url = e.nextElement();
/*  94 */                 if (url != null)
/*  95 */                   v.add(url); 
/*     */               } 
/*  97 */               if (v.size() > 0) {
/*  98 */                 ret = new URL[v.size()];
/*  99 */                 ret = v.<URL>toArray(ret);
/*     */               }  }
/* 101 */             catch (IOException iOException) {  }
/* 102 */             catch (SecurityException securityException) {}
/* 103 */             return ret;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static URL[] getSystemResources(final String name) {
/* 109 */     return 
/* 110 */       AccessController.<URL[]>doPrivileged(new PrivilegedAction<URL>() {
/*     */           public Object run() {
/* 112 */             URL[] ret = null;
/*     */             
/* 114 */             try { List<URL> v = new ArrayList();
/* 115 */               Enumeration<URL> e = ClassLoader.getSystemResources(name);
/* 116 */               while (e != null && e.hasMoreElements()) {
/* 117 */                 URL url = e.nextElement();
/* 118 */                 if (url != null)
/* 119 */                   v.add(url); 
/*     */               } 
/* 121 */               if (v.size() > 0) {
/* 122 */                 ret = new URL[v.size()];
/* 123 */                 ret = v.<URL>toArray(ret);
/*     */               }  }
/* 125 */             catch (IOException iOException) {  }
/* 126 */             catch (SecurityException securityException) {}
/* 127 */             return ret;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static InputStream openStream(final URL url) throws IOException {
/*     */     try {
/* 134 */       return 
/* 135 */         AccessController.<InputStream>doPrivileged(new PrivilegedExceptionAction<InputStream>() {
/*     */             public Object run() throws IOException {
/* 137 */               return url.openStream();
/*     */             }
/*     */           });
/* 140 */     } catch (PrivilegedActionException e) {
/* 141 */       throw (IOException)e.getException();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\SecuritySupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */