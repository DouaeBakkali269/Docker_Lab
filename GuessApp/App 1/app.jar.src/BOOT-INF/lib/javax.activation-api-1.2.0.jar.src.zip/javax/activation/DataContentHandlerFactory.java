package javax.activation;

public interface DataContentHandlerFactory {
  DataContentHandler createDataContentHandler(String paramString);
}


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\javax.activation-api-1.2.0.jar!\javax\activation\DataContentHandlerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */