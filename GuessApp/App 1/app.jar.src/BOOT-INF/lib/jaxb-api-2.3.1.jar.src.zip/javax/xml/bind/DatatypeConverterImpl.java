/*      */ package javax.xml.bind;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.TimeZone;
/*      */ import javax.xml.datatype.DatatypeConfigurationException;
/*      */ import javax.xml.datatype.DatatypeFactory;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DatatypeConverterImpl
/*      */   implements DatatypeConverterInterface
/*      */ {
/*   74 */   public static final DatatypeConverterInterface theInstance = new DatatypeConverterImpl();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String parseString(String lexicalXSDString) {
/*   80 */     return lexicalXSDString;
/*      */   }
/*      */   
/*      */   public BigInteger parseInteger(String lexicalXSDInteger) {
/*   84 */     return _parseInteger(lexicalXSDInteger);
/*      */   }
/*      */   
/*      */   public static BigInteger _parseInteger(CharSequence s) {
/*   88 */     return new BigInteger(removeOptionalPlus(WhiteSpaceProcessor.trim(s)).toString());
/*      */   }
/*      */   
/*      */   public String printInteger(BigInteger val) {
/*   92 */     return _printInteger(val);
/*      */   }
/*      */   
/*      */   public static String _printInteger(BigInteger val) {
/*   96 */     return val.toString();
/*      */   }
/*      */   
/*      */   public int parseInt(String s) {
/*  100 */     return _parseInt(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _parseInt(CharSequence s) {
/*  114 */     int len = s.length();
/*  115 */     int sign = 1;
/*      */     
/*  117 */     int r = 0;
/*      */     
/*  119 */     for (int i = 0; i < len; i++) {
/*  120 */       char ch = s.charAt(i);
/*  121 */       if (!WhiteSpaceProcessor.isWhiteSpace(ch))
/*      */       {
/*  123 */         if ('0' <= ch && ch <= '9') {
/*  124 */           r = r * 10 + ch - 48;
/*  125 */         } else if (ch == '-') {
/*  126 */           sign = -1;
/*  127 */         } else if (ch != '+') {
/*      */ 
/*      */           
/*  130 */           throw new NumberFormatException("Not a number: " + s);
/*      */         } 
/*      */       }
/*      */     } 
/*  134 */     return r * sign;
/*      */   }
/*      */   
/*      */   public long parseLong(String lexicalXSLong) {
/*  138 */     return _parseLong(lexicalXSLong);
/*      */   }
/*      */   
/*      */   public static long _parseLong(CharSequence s) {
/*  142 */     return Long.parseLong(removeOptionalPlus(WhiteSpaceProcessor.trim(s)).toString());
/*      */   }
/*      */   
/*      */   public short parseShort(String lexicalXSDShort) {
/*  146 */     return _parseShort(lexicalXSDShort);
/*      */   }
/*      */   
/*      */   public static short _parseShort(CharSequence s) {
/*  150 */     return (short)_parseInt(s);
/*      */   }
/*      */   
/*      */   public String printShort(short val) {
/*  154 */     return _printShort(val);
/*      */   }
/*      */   
/*      */   public static String _printShort(short val) {
/*  158 */     return String.valueOf(val);
/*      */   }
/*      */   
/*      */   public BigDecimal parseDecimal(String content) {
/*  162 */     return _parseDecimal(content);
/*      */   }
/*      */   
/*      */   public static BigDecimal _parseDecimal(CharSequence content) {
/*  166 */     content = WhiteSpaceProcessor.trim(content);
/*      */     
/*  168 */     if (content.length() <= 0) {
/*  169 */       return null;
/*      */     }
/*      */     
/*  172 */     return new BigDecimal(content.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float parseFloat(String lexicalXSDFloat) {
/*  188 */     return _parseFloat(lexicalXSDFloat);
/*      */   }
/*      */   
/*      */   public static float _parseFloat(CharSequence _val) {
/*  192 */     String s = WhiteSpaceProcessor.trim(_val).toString();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  208 */     if (s.equals("NaN")) {
/*  209 */       return Float.NaN;
/*      */     }
/*  211 */     if (s.equals("INF")) {
/*  212 */       return Float.POSITIVE_INFINITY;
/*      */     }
/*  214 */     if (s.equals("-INF")) {
/*  215 */       return Float.NEGATIVE_INFINITY;
/*      */     }
/*      */     
/*  218 */     if (s.length() == 0 || 
/*  219 */       !isDigitOrPeriodOrSign(s.charAt(0)) || 
/*  220 */       !isDigitOrPeriodOrSign(s.charAt(s.length() - 1))) {
/*  221 */       throw new NumberFormatException();
/*      */     }
/*      */ 
/*      */     
/*  225 */     return Float.parseFloat(s);
/*      */   }
/*      */   
/*      */   public String printFloat(float v) {
/*  229 */     return _printFloat(v);
/*      */   }
/*      */   
/*      */   public static String _printFloat(float v) {
/*  233 */     if (Float.isNaN(v)) {
/*  234 */       return "NaN";
/*      */     }
/*  236 */     if (v == Float.POSITIVE_INFINITY) {
/*  237 */       return "INF";
/*      */     }
/*  239 */     if (v == Float.NEGATIVE_INFINITY) {
/*  240 */       return "-INF";
/*      */     }
/*  242 */     return String.valueOf(v);
/*      */   }
/*      */   
/*      */   public double parseDouble(String lexicalXSDDouble) {
/*  246 */     return _parseDouble(lexicalXSDDouble);
/*      */   }
/*      */   
/*      */   public static double _parseDouble(CharSequence _val) {
/*  250 */     String val = WhiteSpaceProcessor.trim(_val).toString();
/*      */     
/*  252 */     if (val.equals("NaN")) {
/*  253 */       return Double.NaN;
/*      */     }
/*  255 */     if (val.equals("INF")) {
/*  256 */       return Double.POSITIVE_INFINITY;
/*      */     }
/*  258 */     if (val.equals("-INF")) {
/*  259 */       return Double.NEGATIVE_INFINITY;
/*      */     }
/*      */     
/*  262 */     if (val.length() == 0 || 
/*  263 */       !isDigitOrPeriodOrSign(val.charAt(0)) || 
/*  264 */       !isDigitOrPeriodOrSign(val.charAt(val.length() - 1))) {
/*  265 */       throw new NumberFormatException(val);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  270 */     return Double.parseDouble(val);
/*      */   }
/*      */   
/*      */   public boolean parseBoolean(String lexicalXSDBoolean) {
/*  274 */     Boolean b = _parseBoolean(lexicalXSDBoolean);
/*  275 */     return (b == null) ? false : b.booleanValue();
/*      */   } public static Boolean _parseBoolean(CharSequence literal) {
/*      */     char ch;
/*      */     String strTrue, strFalse;
/*  279 */     if (literal == null) {
/*  280 */       return null;
/*      */     }
/*      */     
/*  283 */     int i = 0;
/*  284 */     int len = literal.length();
/*      */     
/*  286 */     boolean value = false;
/*      */     
/*  288 */     if (literal.length() <= 0) {
/*  289 */       return null;
/*      */     }
/*      */     
/*      */     do {
/*  293 */       ch = literal.charAt(i++);
/*  294 */     } while (WhiteSpaceProcessor.isWhiteSpace(ch) && i < len);
/*      */     
/*  296 */     int strIndex = 0;
/*      */     
/*  298 */     switch (ch) {
/*      */       case '1':
/*  300 */         value = true;
/*      */         break;
/*      */       case '0':
/*  303 */         value = false;
/*      */         break;
/*      */       case 't':
/*  306 */         strTrue = "rue";
/*      */         do {
/*  308 */           ch = literal.charAt(i++);
/*  309 */         } while (strTrue.charAt(strIndex++) == ch && i < len && strIndex < 3);
/*      */         
/*  311 */         if (strIndex == 3) {
/*  312 */           value = true; break;
/*      */         } 
/*  314 */         return Boolean.valueOf(false);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 'f':
/*  320 */         strFalse = "alse";
/*      */         do {
/*  322 */           ch = literal.charAt(i++);
/*  323 */         } while (strFalse.charAt(strIndex++) == ch && i < len && strIndex < 4);
/*      */ 
/*      */         
/*  326 */         if (strIndex == 4) {
/*  327 */           value = false; break;
/*      */         } 
/*  329 */         return Boolean.valueOf(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  336 */     if (i < len) {
/*      */       do {
/*  338 */         ch = literal.charAt(i++);
/*  339 */       } while (WhiteSpaceProcessor.isWhiteSpace(ch) && i < len);
/*      */     }
/*      */     
/*  342 */     if (i == len) {
/*  343 */       return Boolean.valueOf(value);
/*      */     }
/*  345 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String printBoolean(boolean val) {
/*  351 */     return val ? "true" : "false";
/*      */   }
/*      */   
/*      */   public static String _printBoolean(boolean val) {
/*  355 */     return val ? "true" : "false";
/*      */   }
/*      */   
/*      */   public byte parseByte(String lexicalXSDByte) {
/*  359 */     return _parseByte(lexicalXSDByte);
/*      */   }
/*      */   
/*      */   public static byte _parseByte(CharSequence literal) {
/*  363 */     return (byte)_parseInt(literal);
/*      */   }
/*      */   
/*      */   public String printByte(byte val) {
/*  367 */     return _printByte(val);
/*      */   }
/*      */   
/*      */   public static String _printByte(byte val) {
/*  371 */     return String.valueOf(val);
/*      */   }
/*      */   
/*      */   public QName parseQName(String lexicalXSDQName, NamespaceContext nsc) {
/*  375 */     return _parseQName(lexicalXSDQName, nsc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static QName _parseQName(CharSequence text, NamespaceContext nsc) {
/*      */     String uri, localPart, prefix;
/*  382 */     int length = text.length();
/*      */ 
/*      */     
/*  385 */     int start = 0;
/*  386 */     while (start < length && WhiteSpaceProcessor.isWhiteSpace(text.charAt(start))) {
/*  387 */       start++;
/*      */     }
/*      */     
/*  390 */     int end = length;
/*  391 */     while (end > start && WhiteSpaceProcessor.isWhiteSpace(text.charAt(end - 1))) {
/*  392 */       end--;
/*      */     }
/*      */     
/*  395 */     if (end == start) {
/*  396 */       throw new IllegalArgumentException("input is empty");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  405 */     int idx = start + 1;
/*  406 */     while (idx < end && text.charAt(idx) != ':') {
/*  407 */       idx++;
/*      */     }
/*      */     
/*  410 */     if (idx == end) {
/*  411 */       uri = nsc.getNamespaceURI("");
/*  412 */       localPart = text.subSequence(start, end).toString();
/*  413 */       prefix = "";
/*      */     } else {
/*      */       
/*  416 */       prefix = text.subSequence(start, idx).toString();
/*  417 */       localPart = text.subSequence(idx + 1, end).toString();
/*  418 */       uri = nsc.getNamespaceURI(prefix);
/*      */ 
/*      */       
/*  421 */       if (uri == null || uri.length() == 0)
/*      */       {
/*      */         
/*  424 */         throw new IllegalArgumentException("prefix " + prefix + " is not bound to a namespace");
/*      */       }
/*      */     } 
/*      */     
/*  428 */     return new QName(uri, localPart, prefix);
/*      */   }
/*      */   
/*      */   public Calendar parseDateTime(String lexicalXSDDateTime) {
/*  432 */     return _parseDateTime(lexicalXSDDateTime);
/*      */   }
/*      */   
/*      */   public static GregorianCalendar _parseDateTime(CharSequence s) {
/*  436 */     String val = WhiteSpaceProcessor.trim(s).toString();
/*  437 */     return datatypeFactory.newXMLGregorianCalendar(val).toGregorianCalendar();
/*      */   }
/*      */   
/*      */   public String printDateTime(Calendar val) {
/*  441 */     return _printDateTime(val);
/*      */   }
/*      */   
/*      */   public static String _printDateTime(Calendar val) {
/*  445 */     return CalendarFormatter.doFormat("%Y-%M-%DT%h:%m:%s%z", val);
/*      */   }
/*      */   
/*      */   public byte[] parseBase64Binary(String lexicalXSDBase64Binary) {
/*  449 */     return _parseBase64Binary(lexicalXSDBase64Binary);
/*      */   }
/*      */   
/*      */   public byte[] parseHexBinary(String s) {
/*  453 */     int len = s.length();
/*      */ 
/*      */     
/*  456 */     if (len % 2 != 0) {
/*  457 */       throw new IllegalArgumentException("hexBinary needs to be even-length: " + s);
/*      */     }
/*      */     
/*  460 */     byte[] out = new byte[len / 2];
/*      */     
/*  462 */     for (int i = 0; i < len; i += 2) {
/*  463 */       int h = hexToBin(s.charAt(i));
/*  464 */       int l = hexToBin(s.charAt(i + 1));
/*  465 */       if (h == -1 || l == -1) {
/*  466 */         throw new IllegalArgumentException("contains illegal character for hexBinary: " + s);
/*      */       }
/*      */       
/*  469 */       out[i / 2] = (byte)(h * 16 + l);
/*      */     } 
/*      */     
/*  472 */     return out;
/*      */   }
/*      */   
/*      */   private static int hexToBin(char ch) {
/*  476 */     if ('0' <= ch && ch <= '9') {
/*  477 */       return ch - 48;
/*      */     }
/*  479 */     if ('A' <= ch && ch <= 'F') {
/*  480 */       return ch - 65 + 10;
/*      */     }
/*  482 */     if ('a' <= ch && ch <= 'f') {
/*  483 */       return ch - 97 + 10;
/*      */     }
/*  485 */     return -1;
/*      */   }
/*  487 */   private static final char[] hexCode = "0123456789ABCDEF".toCharArray();
/*      */   
/*      */   public String printHexBinary(byte[] data) {
/*  490 */     StringBuilder r = new StringBuilder(data.length * 2);
/*  491 */     for (byte b : data) {
/*  492 */       r.append(hexCode[b >> 4 & 0xF]);
/*  493 */       r.append(hexCode[b & 0xF]);
/*      */     } 
/*  495 */     return r.toString();
/*      */   }
/*      */   
/*      */   public long parseUnsignedInt(String lexicalXSDUnsignedInt) {
/*  499 */     return _parseLong(lexicalXSDUnsignedInt);
/*      */   }
/*      */   
/*      */   public String printUnsignedInt(long val) {
/*  503 */     return _printLong(val);
/*      */   }
/*      */   
/*      */   public int parseUnsignedShort(String lexicalXSDUnsignedShort) {
/*  507 */     return _parseInt(lexicalXSDUnsignedShort);
/*      */   }
/*      */   
/*      */   public Calendar parseTime(String lexicalXSDTime) {
/*  511 */     return datatypeFactory.newXMLGregorianCalendar(lexicalXSDTime).toGregorianCalendar();
/*      */   }
/*      */   
/*      */   public String printTime(Calendar val) {
/*  515 */     return CalendarFormatter.doFormat("%h:%m:%s%z", val);
/*      */   }
/*      */   
/*      */   public Calendar parseDate(String lexicalXSDDate) {
/*  519 */     return datatypeFactory.newXMLGregorianCalendar(lexicalXSDDate).toGregorianCalendar();
/*      */   }
/*      */   
/*      */   public String printDate(Calendar val) {
/*  523 */     return _printDate(val);
/*      */   }
/*      */   
/*      */   public static String _printDate(Calendar val) {
/*  527 */     return CalendarFormatter.doFormat("%Y-%M-%D" + "%z", val);
/*      */   }
/*      */   
/*      */   public String parseAnySimpleType(String lexicalXSDAnySimpleType) {
/*  531 */     return lexicalXSDAnySimpleType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String printString(String val) {
/*  537 */     return val;
/*      */   }
/*      */   
/*      */   public String printInt(int val) {
/*  541 */     return _printInt(val);
/*      */   }
/*      */   
/*      */   public static String _printInt(int val) {
/*  545 */     return String.valueOf(val);
/*      */   }
/*      */   
/*      */   public String printLong(long val) {
/*  549 */     return _printLong(val);
/*      */   }
/*      */   
/*      */   public static String _printLong(long val) {
/*  553 */     return String.valueOf(val);
/*      */   }
/*      */   
/*      */   public String printDecimal(BigDecimal val) {
/*  557 */     return _printDecimal(val);
/*      */   }
/*      */   
/*      */   public static String _printDecimal(BigDecimal val) {
/*  561 */     return val.toPlainString();
/*      */   }
/*      */   
/*      */   public String printDouble(double v) {
/*  565 */     return _printDouble(v);
/*      */   }
/*      */   
/*      */   public static String _printDouble(double v) {
/*  569 */     if (Double.isNaN(v)) {
/*  570 */       return "NaN";
/*      */     }
/*  572 */     if (v == Double.POSITIVE_INFINITY) {
/*  573 */       return "INF";
/*      */     }
/*  575 */     if (v == Double.NEGATIVE_INFINITY) {
/*  576 */       return "-INF";
/*      */     }
/*  578 */     return String.valueOf(v);
/*      */   }
/*      */   
/*      */   public String printQName(QName val, NamespaceContext nsc) {
/*  582 */     return _printQName(val, nsc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _printQName(QName val, NamespaceContext nsc) {
/*  588 */     String qname, prefix = nsc.getPrefix(val.getNamespaceURI());
/*  589 */     String localPart = val.getLocalPart();
/*      */     
/*  591 */     if (prefix == null || prefix.length() == 0) {
/*  592 */       qname = localPart;
/*      */     } else {
/*  594 */       qname = prefix + ':' + localPart;
/*      */     } 
/*      */     
/*  597 */     return qname;
/*      */   }
/*      */   
/*      */   public String printBase64Binary(byte[] val) {
/*  601 */     return _printBase64Binary(val);
/*      */   }
/*      */   
/*      */   public String printUnsignedShort(int val) {
/*  605 */     return String.valueOf(val);
/*      */   }
/*      */   
/*      */   public String printAnySimpleType(String val) {
/*  609 */     return val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String installHook(String s) {
/*  618 */     DatatypeConverter.setDatatypeConverter(theInstance);
/*  619 */     return s;
/*      */   }
/*      */   
/*  622 */   private static final byte[] decodeMap = initDecodeMap();
/*      */   private static final byte PADDING = 127;
/*      */   
/*      */   private static byte[] initDecodeMap() {
/*  626 */     byte[] map = new byte[128];
/*      */     int i;
/*  628 */     for (i = 0; i < 128; i++) {
/*  629 */       map[i] = -1;
/*      */     }
/*      */     
/*  632 */     for (i = 65; i <= 90; i++) {
/*  633 */       map[i] = (byte)(i - 65);
/*      */     }
/*  635 */     for (i = 97; i <= 122; i++) {
/*  636 */       map[i] = (byte)(i - 97 + 26);
/*      */     }
/*  638 */     for (i = 48; i <= 57; i++) {
/*  639 */       map[i] = (byte)(i - 48 + 52);
/*      */     }
/*  641 */     map[43] = 62;
/*  642 */     map[47] = 63;
/*  643 */     map[61] = Byte.MAX_VALUE;
/*      */     
/*  645 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int guessLength(String text) {
/*  669 */     int len = text.length();
/*      */ 
/*      */     
/*  672 */     int j = len - 1;
/*  673 */     while (j >= 0) {
/*  674 */       byte code = decodeMap[text.charAt(j)];
/*  675 */       if (code == Byte.MAX_VALUE) {
/*      */         j--; continue;
/*      */       } 
/*  678 */       if (code == -1)
/*      */       {
/*  680 */         return text.length() / 4 * 3;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  685 */     j++;
/*  686 */     int padSize = len - j;
/*  687 */     if (padSize > 2)
/*      */     {
/*  689 */       return text.length() / 4 * 3;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  694 */     return text.length() / 4 * 3 - padSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] _parseBase64Binary(String text) {
/*  707 */     int buflen = guessLength(text);
/*  708 */     byte[] out = new byte[buflen];
/*  709 */     int o = 0;
/*      */     
/*  711 */     int len = text.length();
/*      */ 
/*      */     
/*  714 */     byte[] quadruplet = new byte[4];
/*  715 */     int q = 0;
/*      */ 
/*      */     
/*  718 */     for (int i = 0; i < len; i++) {
/*  719 */       char ch = text.charAt(i);
/*  720 */       byte v = decodeMap[ch];
/*      */       
/*  722 */       if (v != -1) {
/*  723 */         quadruplet[q++] = v;
/*      */       }
/*      */       
/*  726 */       if (q == 4) {
/*      */         
/*  728 */         out[o++] = (byte)(quadruplet[0] << 2 | quadruplet[1] >> 4);
/*  729 */         if (quadruplet[2] != Byte.MAX_VALUE) {
/*  730 */           out[o++] = (byte)(quadruplet[1] << 4 | quadruplet[2] >> 2);
/*      */         }
/*  732 */         if (quadruplet[3] != Byte.MAX_VALUE) {
/*  733 */           out[o++] = (byte)(quadruplet[2] << 6 | quadruplet[3]);
/*      */         }
/*  735 */         q = 0;
/*      */       } 
/*      */     } 
/*      */     
/*  739 */     if (buflen == o)
/*      */     {
/*  741 */       return out;
/*      */     }
/*      */ 
/*      */     
/*  745 */     byte[] nb = new byte[o];
/*  746 */     System.arraycopy(out, 0, nb, 0, o);
/*  747 */     return nb;
/*      */   }
/*  749 */   private static final char[] encodeMap = initEncodeMap(); private static final DatatypeFactory datatypeFactory;
/*      */   
/*      */   private static char[] initEncodeMap() {
/*  752 */     char[] map = new char[64];
/*      */     int i;
/*  754 */     for (i = 0; i < 26; i++) {
/*  755 */       map[i] = (char)(65 + i);
/*      */     }
/*  757 */     for (i = 26; i < 52; i++) {
/*  758 */       map[i] = (char)(97 + i - 26);
/*      */     }
/*  760 */     for (i = 52; i < 62; i++) {
/*  761 */       map[i] = (char)(48 + i - 52);
/*      */     }
/*  763 */     map[62] = '+';
/*  764 */     map[63] = '/';
/*      */     
/*  766 */     return map;
/*      */   }
/*      */   
/*      */   public static char encode(int i) {
/*  770 */     return encodeMap[i & 0x3F];
/*      */   }
/*      */   
/*      */   public static byte encodeByte(int i) {
/*  774 */     return (byte)encodeMap[i & 0x3F];
/*      */   }
/*      */   
/*      */   public static String _printBase64Binary(byte[] input) {
/*  778 */     return _printBase64Binary(input, 0, input.length);
/*      */   }
/*      */   
/*      */   public static String _printBase64Binary(byte[] input, int offset, int len) {
/*  782 */     char[] buf = new char[(len + 2) / 3 * 4];
/*  783 */     int ptr = _printBase64Binary(input, offset, len, buf, 0);
/*  784 */     assert ptr == buf.length;
/*  785 */     return new String(buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _printBase64Binary(byte[] input, int offset, int len, char[] buf, int ptr) {
/*  799 */     int remaining = len;
/*      */     int i;
/*  801 */     for (i = offset; remaining >= 3; remaining -= 3, i += 3) {
/*  802 */       buf[ptr++] = encode(input[i] >> 2);
/*  803 */       buf[ptr++] = encode((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  806 */       buf[ptr++] = encode((input[i + 1] & 0xF) << 2 | input[i + 2] >> 6 & 0x3);
/*      */ 
/*      */       
/*  809 */       buf[ptr++] = encode(input[i + 2] & 0x3F);
/*      */     } 
/*      */     
/*  812 */     if (remaining == 1) {
/*  813 */       buf[ptr++] = encode(input[i] >> 2);
/*  814 */       buf[ptr++] = encode((input[i] & 0x3) << 4);
/*  815 */       buf[ptr++] = '=';
/*  816 */       buf[ptr++] = '=';
/*      */     } 
/*      */     
/*  819 */     if (remaining == 2) {
/*  820 */       buf[ptr++] = encode(input[i] >> 2);
/*  821 */       buf[ptr++] = encode((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */       
/*  823 */       buf[ptr++] = encode((input[i + 1] & 0xF) << 2);
/*  824 */       buf[ptr++] = '=';
/*      */     } 
/*  826 */     return ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _printBase64Binary(byte[] input, int offset, int len, byte[] out, int ptr) {
/*  840 */     byte[] buf = out;
/*  841 */     int remaining = len;
/*      */     int i;
/*  843 */     for (i = offset; remaining >= 3; remaining -= 3, i += 3) {
/*  844 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  845 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  848 */       buf[ptr++] = encodeByte((input[i + 1] & 0xF) << 2 | input[i + 2] >> 6 & 0x3);
/*      */ 
/*      */       
/*  851 */       buf[ptr++] = encodeByte(input[i + 2] & 0x3F);
/*      */     } 
/*      */     
/*  854 */     if (remaining == 1) {
/*  855 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  856 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4);
/*  857 */       buf[ptr++] = 61;
/*  858 */       buf[ptr++] = 61;
/*      */     } 
/*      */     
/*  861 */     if (remaining == 2) {
/*  862 */       buf[ptr++] = encodeByte(input[i] >> 2);
/*  863 */       buf[ptr++] = encodeByte((input[i] & 0x3) << 4 | input[i + 1] >> 4 & 0xF);
/*      */ 
/*      */       
/*  866 */       buf[ptr++] = encodeByte((input[i + 1] & 0xF) << 2);
/*  867 */       buf[ptr++] = 61;
/*      */     } 
/*      */     
/*  870 */     return ptr;
/*      */   }
/*      */   
/*      */   private static CharSequence removeOptionalPlus(CharSequence s) {
/*  874 */     int len = s.length();
/*      */     
/*  876 */     if (len <= 1 || s.charAt(0) != '+') {
/*  877 */       return s;
/*      */     }
/*      */     
/*  880 */     s = s.subSequence(1, len);
/*  881 */     char ch = s.charAt(0);
/*  882 */     if ('0' <= ch && ch <= '9') {
/*  883 */       return s;
/*      */     }
/*  885 */     if ('.' == ch) {
/*  886 */       return s;
/*      */     }
/*      */     
/*  889 */     throw new NumberFormatException();
/*      */   }
/*      */   
/*      */   private static boolean isDigitOrPeriodOrSign(char ch) {
/*  893 */     if ('0' <= ch && ch <= '9') {
/*  894 */       return true;
/*      */     }
/*  896 */     if (ch == '+' || ch == '-' || ch == '.') {
/*  897 */       return true;
/*      */     }
/*  899 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   static {
/*      */     try {
/*  905 */       datatypeFactory = DatatypeFactory.newInstance();
/*  906 */     } catch (DatatypeConfigurationException e) {
/*  907 */       throw new Error(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static final class CalendarFormatter
/*      */   {
/*      */     public static String doFormat(String format, Calendar cal) throws IllegalArgumentException {
/*  914 */       int fidx = 0;
/*  915 */       int flen = format.length();
/*  916 */       StringBuilder buf = new StringBuilder();
/*      */       
/*  918 */       while (fidx < flen) {
/*  919 */         char fch = format.charAt(fidx++);
/*      */         
/*  921 */         if (fch != '%') {
/*  922 */           buf.append(fch);
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  927 */         switch (format.charAt(fidx++)) {
/*      */           case 'Y':
/*  929 */             formatYear(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'M':
/*  933 */             formatMonth(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'D':
/*  937 */             formatDays(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'h':
/*  941 */             formatHours(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'm':
/*  945 */             formatMinutes(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 's':
/*  949 */             formatSeconds(cal, buf);
/*      */             continue;
/*      */           
/*      */           case 'z':
/*  953 */             formatTimeZone(cal, buf);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */         
/*  958 */         throw new InternalError();
/*      */       } 
/*      */ 
/*      */       
/*  962 */       return buf.toString();
/*      */     }
/*      */     private static void formatYear(Calendar cal, StringBuilder buf) {
/*      */       String s;
/*  966 */       int year = cal.get(1);
/*      */ 
/*      */       
/*  969 */       if (year <= 0) {
/*      */         
/*  971 */         s = Integer.toString(1 - year);
/*      */       } else {
/*      */         
/*  974 */         s = Integer.toString(year);
/*      */       } 
/*      */       
/*  977 */       while (s.length() < 4) {
/*  978 */         s = '0' + s;
/*      */       }
/*  980 */       if (year <= 0) {
/*  981 */         s = '-' + s;
/*      */       }
/*      */       
/*  984 */       buf.append(s);
/*      */     }
/*      */     
/*      */     private static void formatMonth(Calendar cal, StringBuilder buf) {
/*  988 */       formatTwoDigits(cal.get(2) + 1, buf);
/*      */     }
/*      */     
/*      */     private static void formatDays(Calendar cal, StringBuilder buf) {
/*  992 */       formatTwoDigits(cal.get(5), buf);
/*      */     }
/*      */     
/*      */     private static void formatHours(Calendar cal, StringBuilder buf) {
/*  996 */       formatTwoDigits(cal.get(11), buf);
/*      */     }
/*      */     
/*      */     private static void formatMinutes(Calendar cal, StringBuilder buf) {
/* 1000 */       formatTwoDigits(cal.get(12), buf);
/*      */     }
/*      */     
/*      */     private static void formatSeconds(Calendar cal, StringBuilder buf) {
/* 1004 */       formatTwoDigits(cal.get(13), buf);
/* 1005 */       if (cal.isSet(14)) {
/* 1006 */         int n = cal.get(14);
/* 1007 */         if (n != 0) {
/* 1008 */           String ms = Integer.toString(n);
/* 1009 */           while (ms.length() < 3) {
/* 1010 */             ms = '0' + ms;
/*      */           }
/* 1012 */           buf.append('.');
/* 1013 */           buf.append(ms);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private static void formatTimeZone(Calendar cal, StringBuilder buf) {
/* 1020 */       TimeZone tz = cal.getTimeZone();
/*      */       
/* 1022 */       if (tz == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1027 */       int offset = tz.getOffset(cal.getTime().getTime());
/*      */       
/* 1029 */       if (offset == 0) {
/* 1030 */         buf.append('Z');
/*      */         
/*      */         return;
/*      */       } 
/* 1034 */       if (offset >= 0) {
/* 1035 */         buf.append('+');
/*      */       } else {
/* 1037 */         buf.append('-');
/* 1038 */         offset *= -1;
/*      */       } 
/*      */       
/* 1041 */       offset /= 60000;
/*      */       
/* 1043 */       formatTwoDigits(offset / 60, buf);
/* 1044 */       buf.append(':');
/* 1045 */       formatTwoDigits(offset % 60, buf);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static void formatTwoDigits(int n, StringBuilder buf) {
/* 1051 */       if (n < 10) {
/* 1052 */         buf.append('0');
/*      */       }
/* 1054 */       buf.append(n);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\DatatypeConverterImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */