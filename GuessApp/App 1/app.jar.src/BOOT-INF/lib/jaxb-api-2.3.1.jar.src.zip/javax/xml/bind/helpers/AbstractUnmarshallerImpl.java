/*     */ package javax.xml.bind.helpers;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.PropertyException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.ValidationEventHandler;
/*     */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import javax.xml.bind.attachment.AttachmentUnmarshaller;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import javax.xml.validation.Schema;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUnmarshallerImpl
/*     */   implements Unmarshaller
/*     */ {
/*  89 */   private ValidationEventHandler eventHandler = new DefaultValidationEventHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean validating = false;
/*     */ 
/*     */ 
/*     */   
/*  98 */   private XMLReader reader = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLReader getXMLReader() throws JAXBException {
/* 110 */     if (this.reader == null) {
/*     */       
/*     */       try {
/* 113 */         SAXParserFactory parserFactory = SAXParserFactory.newInstance();
/* 114 */         parserFactory.setNamespaceAware(true);
/*     */ 
/*     */ 
/*     */         
/* 118 */         parserFactory.setValidating(false);
/* 119 */         this.reader = parserFactory.newSAXParser().getXMLReader();
/* 120 */       } catch (ParserConfigurationException e) {
/* 121 */         throw new JAXBException(e);
/* 122 */       } catch (SAXException e) {
/* 123 */         throw new JAXBException(e);
/*     */       } 
/*     */     }
/* 126 */     return this.reader;
/*     */   }
/*     */   
/*     */   public Object unmarshal(Source source) throws JAXBException {
/* 130 */     if (source == null) {
/* 131 */       throw new IllegalArgumentException(
/* 132 */           Messages.format("Shared.MustNotBeNull", "source"));
/*     */     }
/*     */     
/* 135 */     if (source instanceof SAXSource)
/* 136 */       return unmarshal((SAXSource)source); 
/* 137 */     if (source instanceof StreamSource)
/* 138 */       return unmarshal(streamSourceToInputSource((StreamSource)source)); 
/* 139 */     if (source instanceof DOMSource) {
/* 140 */       return unmarshal(((DOMSource)source).getNode());
/*     */     }
/*     */     
/* 143 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object unmarshal(SAXSource source) throws JAXBException {
/* 149 */     XMLReader r = source.getXMLReader();
/* 150 */     if (r == null) {
/* 151 */       r = getXMLReader();
/*     */     }
/* 153 */     return unmarshal(r, source.getInputSource());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object unmarshal(XMLReader paramXMLReader, InputSource paramInputSource) throws JAXBException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object unmarshal(InputSource source) throws JAXBException {
/* 165 */     if (source == null) {
/* 166 */       throw new IllegalArgumentException(
/* 167 */           Messages.format("Shared.MustNotBeNull", "source"));
/*     */     }
/*     */     
/* 170 */     return unmarshal(getXMLReader(), source);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object unmarshal(String url) throws JAXBException {
/* 175 */     return unmarshal(new InputSource(url));
/*     */   }
/*     */   
/*     */   public final Object unmarshal(URL url) throws JAXBException {
/* 179 */     if (url == null) {
/* 180 */       throw new IllegalArgumentException(
/* 181 */           Messages.format("Shared.MustNotBeNull", "url"));
/*     */     }
/*     */     
/* 184 */     return unmarshal(url.toExternalForm());
/*     */   }
/*     */   
/*     */   public final Object unmarshal(File f) throws JAXBException {
/* 188 */     if (f == null) {
/* 189 */       throw new IllegalArgumentException(
/* 190 */           Messages.format("Shared.MustNotBeNull", "file"));
/*     */     }
/*     */     
/*     */     try {
/* 194 */       return unmarshal(new BufferedInputStream(new FileInputStream(f)));
/* 195 */     } catch (FileNotFoundException e) {
/* 196 */       throw new IllegalArgumentException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object unmarshal(InputStream is) throws JAXBException {
/* 203 */     if (is == null) {
/* 204 */       throw new IllegalArgumentException(
/* 205 */           Messages.format("Shared.MustNotBeNull", "is"));
/*     */     }
/*     */     
/* 208 */     InputSource isrc = new InputSource(is);
/* 209 */     return unmarshal(isrc);
/*     */   }
/*     */   
/*     */   public final Object unmarshal(Reader reader) throws JAXBException {
/* 213 */     if (reader == null) {
/* 214 */       throw new IllegalArgumentException(
/* 215 */           Messages.format("Shared.MustNotBeNull", "reader"));
/*     */     }
/*     */     
/* 218 */     InputSource isrc = new InputSource(reader);
/* 219 */     return unmarshal(isrc);
/*     */   }
/*     */ 
/*     */   
/*     */   private static InputSource streamSourceToInputSource(StreamSource ss) {
/* 224 */     InputSource is = new InputSource();
/* 225 */     is.setSystemId(ss.getSystemId());
/* 226 */     is.setByteStream(ss.getInputStream());
/* 227 */     is.setCharacterStream(ss.getReader());
/*     */     
/* 229 */     return is;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidating() throws JAXBException {
/* 246 */     return this.validating;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEventHandler(ValidationEventHandler handler) throws JAXBException {
/* 266 */     if (handler == null) {
/* 267 */       this.eventHandler = new DefaultValidationEventHandler();
/*     */     } else {
/* 269 */       this.eventHandler = handler;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidating(boolean validating) throws JAXBException {
/* 287 */     this.validating = validating;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationEventHandler getEventHandler() throws JAXBException {
/* 300 */     return this.eventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UnmarshalException createUnmarshalException(SAXException e) {
/* 325 */     Exception nested = e.getException();
/* 326 */     if (nested instanceof UnmarshalException) {
/* 327 */       return (UnmarshalException)nested;
/*     */     }
/* 329 */     if (nested instanceof RuntimeException)
/*     */     {
/*     */ 
/*     */       
/* 333 */       throw (RuntimeException)nested;
/*     */     }
/*     */ 
/*     */     
/* 337 */     if (nested != null) {
/* 338 */       return new UnmarshalException(nested);
/*     */     }
/* 340 */     return new UnmarshalException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String name, Object value) throws PropertyException {
/* 352 */     if (name == null) {
/* 353 */       throw new IllegalArgumentException(
/* 354 */           Messages.format("Shared.MustNotBeNull", "name"));
/*     */     }
/*     */     
/* 357 */     throw new PropertyException(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String name) throws PropertyException {
/* 369 */     if (name == null) {
/* 370 */       throw new IllegalArgumentException(
/* 371 */           Messages.format("Shared.MustNotBeNull", "name"));
/*     */     }
/*     */     
/* 374 */     throw new PropertyException(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unmarshal(XMLEventReader reader) throws JAXBException {
/* 379 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object unmarshal(XMLStreamReader reader) throws JAXBException {
/* 384 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(Node node, Class<T> expectedType) throws JAXBException {
/* 388 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(Source source, Class<T> expectedType) throws JAXBException {
/* 392 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(XMLStreamReader reader, Class<T> expectedType) throws JAXBException {
/* 396 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <T> JAXBElement<T> unmarshal(XMLEventReader reader, Class<T> expectedType) throws JAXBException {
/* 400 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setSchema(Schema schema) {
/* 404 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Schema getSchema() {
/* 408 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setAdapter(XmlAdapter adapter) {
/* 412 */     if (adapter == null)
/* 413 */       throw new IllegalArgumentException(); 
/* 414 */     setAdapter(adapter.getClass(), adapter);
/*     */   }
/*     */   
/*     */   public <A extends XmlAdapter> void setAdapter(Class<A> type, A adapter) {
/* 418 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public <A extends XmlAdapter> A getAdapter(Class<A> type) {
/* 422 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setAttachmentUnmarshaller(AttachmentUnmarshaller au) {
/* 426 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public AttachmentUnmarshaller getAttachmentUnmarshaller() {
/* 430 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setListener(Unmarshaller.Listener listener) {
/* 434 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Unmarshaller.Listener getListener() {
/* 438 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bind\helpers\AbstractUnmarshallerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */