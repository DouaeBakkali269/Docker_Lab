/*     */ package javax.xml.bind.util;
/*     */ 
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.DTDHandler;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.XMLFilter;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.XMLFilterImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAXBSource
/*     */   extends SAXSource
/*     */ {
/*     */   private final Marshaller marshaller;
/*     */   private final Object contentObject;
/*     */   
/*     */   public JAXBSource(JAXBContext context, Object contentObject) throws JAXBException {
/* 126 */     this(
/* 127 */         (context == null) ? 
/* 128 */         assertionFailed(Messages.format("JAXBSource.NullContext")) : 
/* 129 */         context.createMarshaller(), 
/*     */         
/* 131 */         (contentObject == null) ? 
/* 132 */         assertionFailed(Messages.format("JAXBSource.NullContent")) : 
/* 133 */         contentObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JAXBSource(Marshaller marshaller, Object contentObject) throws JAXBException {
/* 154 */     if (marshaller == null) {
/* 155 */       throw new JAXBException(
/* 156 */           Messages.format("JAXBSource.NullMarshaller"));
/*     */     }
/* 158 */     if (contentObject == null) {
/* 159 */       throw new JAXBException(
/* 160 */           Messages.format("JAXBSource.NullContent"));
/*     */     }
/* 162 */     this.marshaller = marshaller;
/* 163 */     this.contentObject = contentObject;
/*     */     
/* 165 */     setXMLReader(this.pseudoParser);
/*     */     
/* 167 */     setInputSource(new InputSource());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   private final XMLReader pseudoParser = new XMLReader() { private LexicalHandler lexicalHandler;
/*     */       public boolean getFeature(String name) throws SAXNotRecognizedException {
/* 178 */         if (name.equals("http://xml.org/sax/features/namespaces"))
/* 179 */           return true; 
/* 180 */         if (name.equals("http://xml.org/sax/features/namespace-prefixes"))
/* 181 */           return false; 
/* 182 */         throw new SAXNotRecognizedException(name);
/*     */       }
/*     */       private EntityResolver entityResolver; private DTDHandler dtdHandler;
/*     */       public void setFeature(String name, boolean value) throws SAXNotRecognizedException {
/* 186 */         if (name.equals("http://xml.org/sax/features/namespaces") && value)
/*     */           return; 
/* 188 */         if (name.equals("http://xml.org/sax/features/namespace-prefixes") && !value)
/*     */           return; 
/* 190 */         throw new SAXNotRecognizedException(name);
/*     */       }
/*     */       
/*     */       public Object getProperty(String name) throws SAXNotRecognizedException {
/* 194 */         if ("http://xml.org/sax/properties/lexical-handler".equals(name)) {
/* 195 */           return this.lexicalHandler;
/*     */         }
/* 197 */         throw new SAXNotRecognizedException(name);
/*     */       }
/*     */       
/*     */       public void setProperty(String name, Object value) throws SAXNotRecognizedException {
/* 201 */         if ("http://xml.org/sax/properties/lexical-handler".equals(name)) {
/* 202 */           this.lexicalHandler = (LexicalHandler)value;
/*     */           return;
/*     */         } 
/* 205 */         throw new SAXNotRecognizedException(name);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void setEntityResolver(EntityResolver resolver) {
/* 213 */         this.entityResolver = resolver;
/*     */       }
/*     */       public EntityResolver getEntityResolver() {
/* 216 */         return this.entityResolver;
/*     */       }
/*     */ 
/*     */       
/*     */       public void setDTDHandler(DTDHandler handler) {
/* 221 */         this.dtdHandler = handler;
/*     */       }
/*     */       public DTDHandler getDTDHandler() {
/* 224 */         return this.dtdHandler;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 230 */       private XMLFilter repeater = new XMLFilterImpl(); private ErrorHandler errorHandler;
/*     */       
/*     */       public void setContentHandler(ContentHandler handler) {
/* 233 */         this.repeater.setContentHandler(handler);
/*     */       }
/*     */       public ContentHandler getContentHandler() {
/* 236 */         return this.repeater.getContentHandler();
/*     */       }
/*     */ 
/*     */       
/*     */       public void setErrorHandler(ErrorHandler handler) {
/* 241 */         this.errorHandler = handler;
/*     */       }
/*     */       public ErrorHandler getErrorHandler() {
/* 244 */         return this.errorHandler;
/*     */       }
/*     */       
/*     */       public void parse(InputSource input) throws SAXException {
/* 248 */         parse();
/*     */       }
/*     */       
/*     */       public void parse(String systemId) throws SAXException {
/* 252 */         parse();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void parse() throws SAXException {
/*     */         try {
/* 260 */           JAXBSource.this.marshaller.marshal(JAXBSource.this.contentObject, (XMLFilterImpl)this.repeater);
/* 261 */         } catch (JAXBException e) {
/*     */ 
/*     */           
/* 264 */           SAXParseException se = new SAXParseException(e.getMessage(), null, null, -1, -1, (Exception)e);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 269 */           if (this.errorHandler != null) {
/* 270 */             this.errorHandler.fatalError(se);
/*     */           }
/*     */ 
/*     */           
/* 274 */           throw se;
/*     */         } 
/*     */       } }
/*     */   ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Marshaller assertionFailed(String message) throws JAXBException {
/* 286 */     throw new JAXBException(message);
/*     */   }
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\jaxb-api-2.3.1.jar!\javax\xml\bin\\util\JAXBSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */