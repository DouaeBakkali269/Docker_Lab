package META-INF.versions.9.javax.xml.bind;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Messages;

class ModuleUtil {
  private static Logger logger = Logger.getLogger("javax.xml.bind");
  
  static Class[] getClassesFromContextPath(String paramString, ClassLoader paramClassLoader) throws JAXBException {
    ArrayList<Class<?>> arrayList = new ArrayList();
    if (paramString == null || paramString.isEmpty())
      return (Class[])arrayList.toArray((Object[])new Class[0]); 
    String[] arrayOfString = paramString.split(":");
    for (String str : arrayOfString) {
      try {
        Class<?> clazz = paramClassLoader.loadClass(str + ".ObjectFactory");
        arrayList.add(clazz);
      } catch (ClassNotFoundException classNotFoundException) {
        try {
          Class<?> clazz = findFirstByJaxbIndex(str, paramClassLoader);
          if (clazz != null)
            arrayList.add(clazz); 
        } catch (IOException iOException) {
          throw new JAXBException(iOException);
        } 
      } 
    } 
    if (logger.isLoggable(Level.FINE))
      logger.log(Level.FINE, "Resolved classes from context path: {0}", arrayList); 
    return (Class[])arrayList.<Class<?>[]>toArray((Class<?>[][])new Class[0]);
  }
  
  static Class findFirstByJaxbIndex(String paramString, ClassLoader paramClassLoader) throws IOException, JAXBException {
    String str = paramString.replace('.', '/') + "/jaxb.index";
    InputStream inputStream = paramClassLoader.getResourceAsStream(str);
    if (inputStream == null)
      return null; 
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
    try {
      String str1 = bufferedReader.readLine();
      while (str1 != null) {
        str1 = str1.trim();
        if (str1.startsWith("#") || str1.length() == 0) {
          str1 = bufferedReader.readLine();
          continue;
        } 
        try {
          return paramClassLoader.loadClass(paramString + "." + paramString);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new JAXBException(Messages.format("ContextFinder.ErrorLoadClass", str1, paramString), classNotFoundException);
        } 
      } 
    } finally {
      bufferedReader.close();
    } 
    return null;
  }
  
  public static void delegateAddOpensToImplModule(Class[] paramArrayOfClass, Class<?> paramClass) throws JAXBException {
    Module module1 = paramClass.getModule();
    Module module2 = JAXBContext.class.getModule();
    for (Class<?> clazz1 : paramArrayOfClass) {
      Class<?> clazz2 = clazz1.isArray() ? clazz1.getComponentType() : clazz1;
      Module module = clazz2.getModule();
      String str = clazz2.getPackageName();
      if (module.isNamed() && !module.getName().equals("java.base")) {
        if (!module.isOpen(str, module2))
          throw new JAXBException(Messages.format("JAXBClasses.notOpen", str, clazz2.getName(), module.getName())); 
        module.addOpens(str, module1);
        if (logger.isLoggable(Level.FINE))
          logger.log(Level.FINE, "Propagating openness of package {0} in {1} to {2}.", (Object[])new String[] { str, module.getName(), module1.getName() }); 
      } 
    } 
  }
}


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\jaxb-api-2.3.1.jar!\META-INF\versions\9\javax\xml\bind\ModuleUtil.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */