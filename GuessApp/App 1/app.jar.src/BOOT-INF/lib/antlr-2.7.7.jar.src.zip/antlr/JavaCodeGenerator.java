/*      */ package antlr;
/*      */ 
/*      */ import antlr.actions.java.ActionLexer;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ import java.io.IOException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JavaCodeGenerator
/*      */   extends CodeGenerator
/*      */ {
/*      */   public static final int NO_MAPPING = -999;
/*      */   public static final int CONTINUE_LAST_MAPPING = -888;
/*      */   private JavaCodeGeneratorPrintWriterManager printWriterManager;
/*   30 */   private int defaultLine = -999;
/*      */   
/*   32 */   protected int syntacticPredLevel = 0;
/*      */ 
/*      */   
/*      */   protected boolean genAST = false;
/*      */ 
/*      */   
/*      */   protected boolean saveText = false;
/*      */   
/*      */   String labeledElementType;
/*      */   
/*      */   String labeledElementASTType;
/*      */   
/*      */   String labeledElementInit;
/*      */   
/*      */   String commonExtraArgs;
/*      */   
/*      */   String commonExtraParams;
/*      */   
/*      */   String commonLocalVars;
/*      */   
/*      */   String lt1Value;
/*      */   
/*      */   String exceptionThrown;
/*      */   
/*      */   String throwNoViable;
/*      */   
/*      */   RuleBlock currentRule;
/*      */   
/*      */   String currentASTResult;
/*      */   
/*   62 */   Hashtable treeVariableMap = new Hashtable();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   67 */   Hashtable declaredASTVariables = new Hashtable();
/*      */ 
/*      */   
/*   70 */   int astVarNumber = 1;
/*      */ 
/*      */   
/*   73 */   protected static final String NONUNIQUE = new String();
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int caseSizeThreshold = 127;
/*      */ 
/*      */   
/*      */   private Vector semPreds;
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaCodeGenerator() {
/*   85 */     this.charFormatter = new JavaCharFormatter();
/*      */   }
/*      */   
/*      */   protected void printAction(String paramString) {
/*   89 */     printAction(paramString, this.defaultLine);
/*      */   }
/*      */   protected void printAction(String paramString, int paramInt) {
/*   92 */     getPrintWriterManager().startMapping(paramInt);
/*   93 */     super.printAction(paramString);
/*   94 */     getPrintWriterManager().endMapping();
/*      */   }
/*      */   
/*      */   public void println(String paramString) {
/*   98 */     println(paramString, this.defaultLine);
/*      */   }
/*      */   public void println(String paramString, int paramInt) {
/*  101 */     if (paramInt > 0 || paramInt == -888)
/*  102 */       getPrintWriterManager().startSingleSourceLineMapping(paramInt); 
/*  103 */     super.println(paramString);
/*  104 */     if (paramInt > 0 || paramInt == -888)
/*  105 */       getPrintWriterManager().endMapping(); 
/*      */   }
/*      */   
/*      */   protected void print(String paramString) {
/*  109 */     print(paramString, this.defaultLine);
/*      */   }
/*      */   protected void print(String paramString, int paramInt) {
/*  112 */     if (paramInt > 0 || paramInt == -888)
/*  113 */       getPrintWriterManager().startMapping(paramInt); 
/*  114 */     super.print(paramString);
/*  115 */     if (paramInt > 0 || paramInt == -888)
/*  116 */       getPrintWriterManager().endMapping(); 
/*      */   }
/*      */   
/*      */   protected void _print(String paramString) {
/*  120 */     _print(paramString, this.defaultLine);
/*      */   }
/*      */   protected void _print(String paramString, int paramInt) {
/*  123 */     if (paramInt > 0 || paramInt == -888)
/*  124 */       getPrintWriterManager().startMapping(paramInt); 
/*  125 */     super._print(paramString);
/*  126 */     if (paramInt > 0 || paramInt == -888)
/*  127 */       getPrintWriterManager().endMapping(); 
/*      */   }
/*      */   
/*      */   protected void _println(String paramString) {
/*  131 */     _println(paramString, this.defaultLine);
/*      */   }
/*      */   protected void _println(String paramString, int paramInt) {
/*  134 */     if (paramInt > 0 || paramInt == -888)
/*  135 */       getPrintWriterManager().startMapping(paramInt); 
/*  136 */     super._println(paramString);
/*  137 */     if (paramInt > 0 || paramInt == -888) {
/*  138 */       getPrintWriterManager().endMapping();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int addSemPred(String paramString) {
/*  147 */     this.semPreds.appendElement(paramString);
/*  148 */     return this.semPreds.size() - 1;
/*      */   }
/*      */   
/*      */   public void exitIfError() {
/*  152 */     if (this.antlrTool.hasError()) {
/*  153 */       this.antlrTool.fatalError("Exiting due to errors.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen() {
/*      */     try {
/*  162 */       Enumeration enumeration = this.behavior.grammars.elements();
/*  163 */       while (enumeration.hasMoreElements()) {
/*  164 */         Grammar grammar = enumeration.nextElement();
/*      */         
/*  166 */         grammar.setGrammarAnalyzer(this.analyzer);
/*  167 */         grammar.setCodeGenerator(this);
/*  168 */         this.analyzer.setGrammar(grammar);
/*      */         
/*  170 */         setupGrammarParameters(grammar);
/*  171 */         grammar.generate();
/*      */ 
/*      */         
/*  174 */         exitIfError();
/*      */       } 
/*      */ 
/*      */       
/*  178 */       Enumeration enumeration1 = this.behavior.tokenManagers.elements();
/*  179 */       while (enumeration1.hasMoreElements()) {
/*  180 */         TokenManager tokenManager = enumeration1.nextElement();
/*  181 */         if (!tokenManager.isReadOnly()) {
/*      */ 
/*      */ 
/*      */           
/*  185 */           genTokenTypes(tokenManager);
/*      */           
/*  187 */           genTokenInterchange(tokenManager);
/*      */         } 
/*  189 */         exitIfError();
/*      */       }
/*      */     
/*  192 */     } catch (IOException iOException) {
/*  193 */       this.antlrTool.reportException(iOException, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ActionElement paramActionElement) {
/*  201 */     int i = this.defaultLine;
/*      */     try {
/*  203 */       this.defaultLine = paramActionElement.getLine();
/*  204 */       if (this.DEBUG_CODE_GENERATOR) System.out.println("genAction(" + paramActionElement + ")"); 
/*  205 */       if (paramActionElement.isSemPred) {
/*  206 */         genSemPred(paramActionElement.actionText, paramActionElement.line);
/*      */       } else {
/*      */         
/*  209 */         if (this.grammar.hasSyntacticPredicate) {
/*  210 */           println("if ( inputState.guessing==0 ) {");
/*  211 */           this.tabs++;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  216 */         ActionTransInfo actionTransInfo = new ActionTransInfo();
/*  217 */         String str = processActionForSpecialSymbols(paramActionElement.actionText, paramActionElement.getLine(), this.currentRule, actionTransInfo);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  222 */         if (actionTransInfo.refRuleRoot != null)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  227 */           println(actionTransInfo.refRuleRoot + " = (" + this.labeledElementASTType + ")currentAST.root;");
/*      */         }
/*      */ 
/*      */         
/*  231 */         printAction(str);
/*      */         
/*  233 */         if (actionTransInfo.assignToRoot) {
/*      */           
/*  235 */           println("currentAST.root = " + actionTransInfo.refRuleRoot + ";");
/*      */           
/*  237 */           println("currentAST.child = " + actionTransInfo.refRuleRoot + "!=null &&" + actionTransInfo.refRuleRoot + ".getFirstChild()!=null ?", -999);
/*  238 */           this.tabs++;
/*  239 */           println(actionTransInfo.refRuleRoot + ".getFirstChild() : " + actionTransInfo.refRuleRoot + ";");
/*  240 */           this.tabs--;
/*  241 */           println("currentAST.advanceChildToEnd();");
/*      */         } 
/*      */         
/*  244 */         if (this.grammar.hasSyntacticPredicate) {
/*  245 */           this.tabs--;
/*  246 */           println("}", -999);
/*      */         } 
/*      */       } 
/*      */     } finally {
/*  250 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(AlternativeBlock paramAlternativeBlock) {
/*  258 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("gen(" + paramAlternativeBlock + ")"); 
/*  259 */     println("{", -999);
/*  260 */     genBlockPreamble(paramAlternativeBlock);
/*  261 */     genBlockInitAction(paramAlternativeBlock);
/*      */ 
/*      */     
/*  264 */     String str = this.currentASTResult;
/*  265 */     if (paramAlternativeBlock.getLabel() != null) {
/*  266 */       this.currentASTResult = paramAlternativeBlock.getLabel();
/*      */     }
/*      */     
/*  269 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramAlternativeBlock);
/*      */     
/*  271 */     JavaBlockFinishingInfo javaBlockFinishingInfo = genCommonBlock(paramAlternativeBlock, true);
/*  272 */     genBlockFinish(javaBlockFinishingInfo, this.throwNoViable, paramAlternativeBlock.getLine());
/*      */     
/*  274 */     println("}", -999);
/*      */ 
/*      */     
/*  277 */     this.currentASTResult = str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(BlockEndElement paramBlockEndElement) {
/*  286 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genRuleEnd(" + paramBlockEndElement + ")");
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(CharLiteralElement paramCharLiteralElement) {
/*  293 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genChar(" + paramCharLiteralElement + ")");
/*      */     
/*  295 */     if (paramCharLiteralElement.getLabel() != null) {
/*  296 */       println(paramCharLiteralElement.getLabel() + " = " + this.lt1Value + ";", paramCharLiteralElement.getLine());
/*      */     }
/*      */     
/*  299 */     boolean bool = this.saveText;
/*  300 */     this.saveText = (this.saveText && paramCharLiteralElement.getAutoGenType() == 1);
/*  301 */     genMatch(paramCharLiteralElement);
/*  302 */     this.saveText = bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(CharRangeElement paramCharRangeElement) {
/*  309 */     int i = this.defaultLine;
/*      */     try {
/*  311 */       this.defaultLine = paramCharRangeElement.getLine();
/*  312 */       if (paramCharRangeElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  313 */         println(paramCharRangeElement.getLabel() + " = " + this.lt1Value + ";");
/*      */       }
/*  315 */       boolean bool = (this.grammar instanceof LexerGrammar && (!this.saveText || paramCharRangeElement.getAutoGenType() == 3)) ? true : false;
/*      */ 
/*      */ 
/*      */       
/*  319 */       if (bool) {
/*  320 */         println("_saveIndex=text.length();");
/*      */       }
/*      */       
/*  323 */       println("matchRange(" + paramCharRangeElement.beginText + "," + paramCharRangeElement.endText + ");");
/*      */       
/*  325 */       if (bool) {
/*  326 */         println("text.setLength(_saveIndex);");
/*      */       }
/*      */     } finally {
/*  329 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(LexerGrammar paramLexerGrammar) throws IOException {
/*  335 */     int i = this.defaultLine;
/*      */     try {
/*  337 */       this.defaultLine = -999;
/*      */       
/*  339 */       if (paramLexerGrammar.debuggingOutput) {
/*  340 */         this.semPreds = new Vector();
/*      */       }
/*  342 */       setGrammar(paramLexerGrammar);
/*  343 */       if (!(this.grammar instanceof LexerGrammar)) {
/*  344 */         this.antlrTool.panic("Internal error generating lexer");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  349 */       this.currentOutput = getPrintWriterManager().setupOutput(this.antlrTool, this.grammar);
/*      */       
/*  351 */       this.genAST = false;
/*  352 */       this.saveText = true;
/*      */       
/*  354 */       this.tabs = 0;
/*      */ 
/*      */       
/*  357 */       genHeader();
/*      */ 
/*      */       
/*      */       try {
/*  361 */         this.defaultLine = this.behavior.getHeaderActionLine("");
/*  362 */         println(this.behavior.getHeaderAction(""));
/*      */       } finally {
/*  364 */         this.defaultLine = -999;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  369 */       println("import java.io.InputStream;");
/*  370 */       println("import antlr.TokenStreamException;");
/*  371 */       println("import antlr.TokenStreamIOException;");
/*  372 */       println("import antlr.TokenStreamRecognitionException;");
/*  373 */       println("import antlr.CharStreamException;");
/*  374 */       println("import antlr.CharStreamIOException;");
/*  375 */       println("import antlr.ANTLRException;");
/*  376 */       println("import java.io.Reader;");
/*  377 */       println("import java.util.Hashtable;");
/*  378 */       println("import antlr." + this.grammar.getSuperClass() + ";");
/*  379 */       println("import antlr.InputBuffer;");
/*  380 */       println("import antlr.ByteBuffer;");
/*  381 */       println("import antlr.CharBuffer;");
/*  382 */       println("import antlr.Token;");
/*  383 */       println("import antlr.CommonToken;");
/*  384 */       println("import antlr.RecognitionException;");
/*  385 */       println("import antlr.NoViableAltForCharException;");
/*  386 */       println("import antlr.MismatchedCharException;");
/*  387 */       println("import antlr.TokenStream;");
/*  388 */       println("import antlr.ANTLRHashString;");
/*  389 */       println("import antlr.LexerSharedInputState;");
/*  390 */       println("import antlr.collections.impl.BitSet;");
/*  391 */       println("import antlr.SemanticException;");
/*      */ 
/*      */       
/*  394 */       println(this.grammar.preambleAction.getText());
/*      */ 
/*      */       
/*  397 */       String str1 = null;
/*  398 */       if (this.grammar.superClass != null) {
/*  399 */         str1 = this.grammar.superClass;
/*      */       } else {
/*      */         
/*  402 */         str1 = "antlr." + this.grammar.getSuperClass();
/*      */       } 
/*      */ 
/*      */       
/*  406 */       if (this.grammar.comment != null) {
/*  407 */         _println(this.grammar.comment);
/*      */       }
/*      */ 
/*      */       
/*  411 */       String str2 = "public";
/*  412 */       Token token1 = (Token)this.grammar.options.get("classHeaderPrefix");
/*  413 */       if (token1 != null) {
/*  414 */         String str = StringUtils.stripFrontBack(token1.getText(), "\"", "\"");
/*  415 */         if (str != null) {
/*  416 */           str2 = str;
/*      */         }
/*      */       } 
/*      */       
/*  420 */       print(str2 + " ");
/*  421 */       print("class " + this.grammar.getClassName() + " extends " + str1);
/*  422 */       println(" implements " + this.grammar.tokenManager.getName() + TokenTypesFileSuffix + ", TokenStream");
/*  423 */       Token token2 = (Token)this.grammar.options.get("classHeaderSuffix");
/*  424 */       if (token2 != null) {
/*  425 */         String str = StringUtils.stripFrontBack(token2.getText(), "\"", "\"");
/*  426 */         if (str != null) {
/*  427 */           print(", " + str);
/*      */         }
/*      */       } 
/*  430 */       println(" {");
/*      */ 
/*      */       
/*  433 */       print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null), this.grammar.classMemberAction.getLine());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  442 */       println("public " + this.grammar.getClassName() + "(InputStream in) {");
/*  443 */       this.tabs++;
/*  444 */       println("this(new ByteBuffer(in));");
/*  445 */       this.tabs--;
/*  446 */       println("}");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  452 */       println("public " + this.grammar.getClassName() + "(Reader in) {");
/*  453 */       this.tabs++;
/*  454 */       println("this(new CharBuffer(in));");
/*  455 */       this.tabs--;
/*  456 */       println("}");
/*      */       
/*  458 */       println("public " + this.grammar.getClassName() + "(InputBuffer ib) {");
/*  459 */       this.tabs++;
/*      */       
/*  461 */       if (this.grammar.debuggingOutput) {
/*  462 */         println("this(new LexerSharedInputState(new antlr.debug.DebuggingInputBuffer(ib)));");
/*      */       } else {
/*  464 */         println("this(new LexerSharedInputState(ib));");
/*  465 */       }  this.tabs--;
/*  466 */       println("}");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  471 */       println("public " + this.grammar.getClassName() + "(LexerSharedInputState state) {");
/*  472 */       this.tabs++;
/*      */       
/*  474 */       println("super(state);");
/*      */ 
/*      */       
/*  477 */       if (this.grammar.debuggingOutput) {
/*  478 */         println("  ruleNames  = _ruleNames;");
/*  479 */         println("  semPredNames = _semPredNames;");
/*  480 */         println("  setupDebugging();");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  486 */       println("caseSensitiveLiterals = " + paramLexerGrammar.caseSensitiveLiterals + ";");
/*  487 */       println("setCaseSensitive(" + paramLexerGrammar.caseSensitive + ");");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  492 */       println("literals = new Hashtable();");
/*  493 */       Enumeration enumeration = this.grammar.tokenManager.getTokenSymbolKeys();
/*  494 */       while (enumeration.hasMoreElements()) {
/*  495 */         String str = enumeration.nextElement();
/*  496 */         if (str.charAt(0) != '"') {
/*      */           continue;
/*      */         }
/*  499 */         TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/*  500 */         if (tokenSymbol instanceof StringLiteralSymbol) {
/*  501 */           StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)tokenSymbol;
/*  502 */           println("literals.put(new ANTLRHashString(" + stringLiteralSymbol.getId() + ", this), new Integer(" + stringLiteralSymbol.getTokenType() + "));");
/*      */         } 
/*      */       } 
/*  505 */       this.tabs--;
/*      */ 
/*      */       
/*  508 */       println("}");
/*      */ 
/*      */       
/*  511 */       if (this.grammar.debuggingOutput) {
/*  512 */         println("private static final String _ruleNames[] = {");
/*      */         
/*  514 */         Enumeration enumeration2 = this.grammar.rules.elements();
/*  515 */         boolean bool = false;
/*  516 */         while (enumeration2.hasMoreElements()) {
/*  517 */           GrammarSymbol grammarSymbol = enumeration2.nextElement();
/*  518 */           if (grammarSymbol instanceof RuleSymbol)
/*  519 */             println("  \"" + ((RuleSymbol)grammarSymbol).getId() + "\","); 
/*      */         } 
/*  521 */         println("};");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  527 */       genNextToken();
/*      */ 
/*      */       
/*  530 */       Enumeration enumeration1 = this.grammar.rules.elements();
/*  531 */       byte b = 0;
/*  532 */       while (enumeration1.hasMoreElements()) {
/*  533 */         RuleSymbol ruleSymbol = enumeration1.nextElement();
/*      */         
/*  535 */         if (!ruleSymbol.getId().equals("mnextToken")) {
/*  536 */           genRule(ruleSymbol, false, b++);
/*      */         }
/*  538 */         exitIfError();
/*      */       } 
/*      */ 
/*      */       
/*  542 */       if (this.grammar.debuggingOutput) {
/*  543 */         genSemPredMap();
/*      */       }
/*      */       
/*  546 */       genBitsets(this.bitsetsUsed, ((LexerGrammar)this.grammar).charVocabulary.size());
/*      */       
/*  548 */       println("");
/*  549 */       println("}");
/*      */ 
/*      */       
/*  552 */       getPrintWriterManager().finishOutput();
/*      */     } finally {
/*  554 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(OneOrMoreBlock paramOneOrMoreBlock) {
/*  562 */     int i = this.defaultLine; try {
/*      */       String str1, str2;
/*  564 */       this.defaultLine = paramOneOrMoreBlock.getLine();
/*  565 */       if (this.DEBUG_CODE_GENERATOR) System.out.println("gen+(" + paramOneOrMoreBlock + ")");
/*      */ 
/*      */       
/*  568 */       println("{", -999);
/*  569 */       genBlockPreamble(paramOneOrMoreBlock);
/*  570 */       if (paramOneOrMoreBlock.getLabel() != null) {
/*  571 */         str2 = "_cnt_" + paramOneOrMoreBlock.getLabel();
/*      */       } else {
/*      */         
/*  574 */         str2 = "_cnt" + paramOneOrMoreBlock.ID;
/*      */       } 
/*  576 */       println("int " + str2 + "=0;");
/*  577 */       if (paramOneOrMoreBlock.getLabel() != null) {
/*  578 */         str1 = paramOneOrMoreBlock.getLabel();
/*      */       } else {
/*      */         
/*  581 */         str1 = "_loop" + paramOneOrMoreBlock.ID;
/*      */       } 
/*  583 */       println(str1 + ":");
/*  584 */       println("do {");
/*  585 */       this.tabs++;
/*      */ 
/*      */       
/*  588 */       genBlockInitAction(paramOneOrMoreBlock);
/*      */ 
/*      */       
/*  591 */       String str3 = this.currentASTResult;
/*  592 */       if (paramOneOrMoreBlock.getLabel() != null) {
/*  593 */         this.currentASTResult = paramOneOrMoreBlock.getLabel();
/*      */       }
/*      */       
/*  596 */       boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramOneOrMoreBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  608 */       boolean bool1 = false;
/*  609 */       int j = this.grammar.maxk;
/*      */       
/*  611 */       if (!paramOneOrMoreBlock.greedy && paramOneOrMoreBlock.exitLookaheadDepth <= this.grammar.maxk && paramOneOrMoreBlock.exitCache[paramOneOrMoreBlock.exitLookaheadDepth].containsEpsilon()) {
/*      */ 
/*      */         
/*  614 */         bool1 = true;
/*  615 */         j = paramOneOrMoreBlock.exitLookaheadDepth;
/*      */       }
/*  617 */       else if (!paramOneOrMoreBlock.greedy && paramOneOrMoreBlock.exitLookaheadDepth == Integer.MAX_VALUE) {
/*      */         
/*  619 */         bool1 = true;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  624 */       if (bool1) {
/*  625 */         if (this.DEBUG_CODE_GENERATOR) {
/*  626 */           System.out.println("nongreedy (...)+ loop; exit depth is " + paramOneOrMoreBlock.exitLookaheadDepth);
/*      */         }
/*      */         
/*  629 */         String str = getLookaheadTestExpression(paramOneOrMoreBlock.exitCache, j);
/*      */ 
/*      */         
/*  632 */         println("// nongreedy exit test", -999);
/*  633 */         println("if ( " + str2 + ">=1 && " + str + ") break " + str1 + ";", -888);
/*      */       } 
/*      */       
/*  636 */       JavaBlockFinishingInfo javaBlockFinishingInfo = genCommonBlock(paramOneOrMoreBlock, false);
/*  637 */       genBlockFinish(javaBlockFinishingInfo, "if ( " + str2 + ">=1 ) { break " + str1 + "; } else {" + this.throwNoViable + "}", paramOneOrMoreBlock.getLine());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  643 */       println(str2 + "++;");
/*  644 */       this.tabs--;
/*  645 */       println("} while (true);");
/*  646 */       println("}");
/*      */ 
/*      */       
/*  649 */       this.currentASTResult = str3;
/*      */     } finally {
/*  651 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(ParserGrammar paramParserGrammar) throws IOException {
/*  657 */     int i = this.defaultLine;
/*      */     try {
/*  659 */       this.defaultLine = -999;
/*      */ 
/*      */       
/*  662 */       if (paramParserGrammar.debuggingOutput) {
/*  663 */         this.semPreds = new Vector();
/*      */       }
/*  665 */       setGrammar(paramParserGrammar);
/*  666 */       if (!(this.grammar instanceof ParserGrammar)) {
/*  667 */         this.antlrTool.panic("Internal error generating parser");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  672 */       this.currentOutput = getPrintWriterManager().setupOutput(this.antlrTool, this.grammar);
/*      */       
/*  674 */       this.genAST = this.grammar.buildAST;
/*      */       
/*  676 */       this.tabs = 0;
/*      */ 
/*      */       
/*  679 */       genHeader();
/*      */       
/*      */       try {
/*  682 */         this.defaultLine = this.behavior.getHeaderActionLine("");
/*  683 */         println(this.behavior.getHeaderAction(""));
/*      */       } finally {
/*  685 */         this.defaultLine = -999;
/*      */       } 
/*      */ 
/*      */       
/*  689 */       println("import antlr.TokenBuffer;");
/*  690 */       println("import antlr.TokenStreamException;");
/*  691 */       println("import antlr.TokenStreamIOException;");
/*  692 */       println("import antlr.ANTLRException;");
/*  693 */       println("import antlr." + this.grammar.getSuperClass() + ";");
/*  694 */       println("import antlr.Token;");
/*  695 */       println("import antlr.TokenStream;");
/*  696 */       println("import antlr.RecognitionException;");
/*  697 */       println("import antlr.NoViableAltException;");
/*  698 */       println("import antlr.MismatchedTokenException;");
/*  699 */       println("import antlr.SemanticException;");
/*  700 */       println("import antlr.ParserSharedInputState;");
/*  701 */       println("import antlr.collections.impl.BitSet;");
/*  702 */       if (this.genAST) {
/*  703 */         println("import antlr.collections.AST;");
/*  704 */         println("import java.util.Hashtable;");
/*  705 */         println("import antlr.ASTFactory;");
/*  706 */         println("import antlr.ASTPair;");
/*  707 */         println("import antlr.collections.impl.ASTArray;");
/*      */       } 
/*      */ 
/*      */       
/*  711 */       println(this.grammar.preambleAction.getText());
/*      */ 
/*      */       
/*  714 */       String str1 = null;
/*  715 */       if (this.grammar.superClass != null) {
/*  716 */         str1 = this.grammar.superClass;
/*      */       } else {
/*  718 */         str1 = "antlr." + this.grammar.getSuperClass();
/*      */       } 
/*      */       
/*  721 */       if (this.grammar.comment != null) {
/*  722 */         _println(this.grammar.comment);
/*      */       }
/*      */ 
/*      */       
/*  726 */       String str2 = "public";
/*  727 */       Token token1 = (Token)this.grammar.options.get("classHeaderPrefix");
/*  728 */       if (token1 != null) {
/*  729 */         String str = StringUtils.stripFrontBack(token1.getText(), "\"", "\"");
/*  730 */         if (str != null) {
/*  731 */           str2 = str;
/*      */         }
/*      */       } 
/*      */       
/*  735 */       print(str2 + " ");
/*  736 */       print("class " + this.grammar.getClassName() + " extends " + str1);
/*  737 */       println("       implements " + this.grammar.tokenManager.getName() + TokenTypesFileSuffix);
/*      */       
/*  739 */       Token token2 = (Token)this.grammar.options.get("classHeaderSuffix");
/*  740 */       if (token2 != null) {
/*  741 */         String str = StringUtils.stripFrontBack(token2.getText(), "\"", "\"");
/*  742 */         if (str != null)
/*  743 */           print(", " + str); 
/*      */       } 
/*  745 */       println(" {");
/*      */ 
/*      */ 
/*      */       
/*  749 */       if (this.grammar.debuggingOutput) {
/*  750 */         println("private static final String _ruleNames[] = {");
/*      */         
/*  752 */         Enumeration enumeration1 = this.grammar.rules.elements();
/*  753 */         boolean bool = false;
/*  754 */         while (enumeration1.hasMoreElements()) {
/*  755 */           GrammarSymbol grammarSymbol = enumeration1.nextElement();
/*  756 */           if (grammarSymbol instanceof RuleSymbol)
/*  757 */             println("  \"" + ((RuleSymbol)grammarSymbol).getId() + "\","); 
/*      */         } 
/*  759 */         println("};");
/*      */       } 
/*      */ 
/*      */       
/*  763 */       print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null), this.grammar.classMemberAction.getLine());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  769 */       println("");
/*  770 */       println("protected " + this.grammar.getClassName() + "(TokenBuffer tokenBuf, int k) {");
/*  771 */       println("  super(tokenBuf,k);");
/*  772 */       println("  tokenNames = _tokenNames;");
/*      */ 
/*      */       
/*  775 */       if (this.grammar.debuggingOutput) {
/*  776 */         println("  ruleNames  = _ruleNames;");
/*  777 */         println("  semPredNames = _semPredNames;");
/*  778 */         println("  setupDebugging(tokenBuf);");
/*      */       } 
/*  780 */       if (this.grammar.buildAST) {
/*  781 */         println("  buildTokenTypeASTClassMap();");
/*  782 */         println("  astFactory = new ASTFactory(getTokenTypeToASTClassMap());");
/*      */       } 
/*  784 */       println("}");
/*  785 */       println("");
/*      */       
/*  787 */       println("public " + this.grammar.getClassName() + "(TokenBuffer tokenBuf) {");
/*  788 */       println("  this(tokenBuf," + this.grammar.maxk + ");");
/*  789 */       println("}");
/*  790 */       println("");
/*      */ 
/*      */       
/*  793 */       println("protected " + this.grammar.getClassName() + "(TokenStream lexer, int k) {");
/*  794 */       println("  super(lexer,k);");
/*  795 */       println("  tokenNames = _tokenNames;");
/*      */ 
/*      */ 
/*      */       
/*  799 */       if (this.grammar.debuggingOutput) {
/*  800 */         println("  ruleNames  = _ruleNames;");
/*  801 */         println("  semPredNames = _semPredNames;");
/*  802 */         println("  setupDebugging(lexer);");
/*      */       } 
/*  804 */       if (this.grammar.buildAST) {
/*  805 */         println("  buildTokenTypeASTClassMap();");
/*  806 */         println("  astFactory = new ASTFactory(getTokenTypeToASTClassMap());");
/*      */       } 
/*  808 */       println("}");
/*  809 */       println("");
/*      */       
/*  811 */       println("public " + this.grammar.getClassName() + "(TokenStream lexer) {");
/*  812 */       println("  this(lexer," + this.grammar.maxk + ");");
/*  813 */       println("}");
/*  814 */       println("");
/*      */       
/*  816 */       println("public " + this.grammar.getClassName() + "(ParserSharedInputState state) {");
/*  817 */       println("  super(state," + this.grammar.maxk + ");");
/*  818 */       println("  tokenNames = _tokenNames;");
/*  819 */       if (this.grammar.buildAST) {
/*  820 */         println("  buildTokenTypeASTClassMap();");
/*  821 */         println("  astFactory = new ASTFactory(getTokenTypeToASTClassMap());");
/*      */       } 
/*  823 */       println("}");
/*  824 */       println("");
/*      */ 
/*      */       
/*  827 */       Enumeration enumeration = this.grammar.rules.elements();
/*  828 */       byte b = 0;
/*  829 */       while (enumeration.hasMoreElements()) {
/*  830 */         GrammarSymbol grammarSymbol = enumeration.nextElement();
/*  831 */         if (grammarSymbol instanceof RuleSymbol) {
/*  832 */           RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/*  833 */           genRule(ruleSymbol, (ruleSymbol.references.size() == 0), b++);
/*      */         } 
/*  835 */         exitIfError();
/*      */       } 
/*      */ 
/*      */       
/*  839 */       genTokenStrings();
/*      */       
/*  841 */       if (this.grammar.buildAST) {
/*  842 */         genTokenASTNodeMap();
/*      */       }
/*      */ 
/*      */       
/*  846 */       genBitsets(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType());
/*      */ 
/*      */       
/*  849 */       if (this.grammar.debuggingOutput) {
/*  850 */         genSemPredMap();
/*      */       }
/*      */       
/*  853 */       println("");
/*  854 */       println("}");
/*      */ 
/*      */       
/*  857 */       getPrintWriterManager().finishOutput();
/*      */     } finally {
/*  859 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(RuleRefElement paramRuleRefElement) {
/*  867 */     int i = this.defaultLine;
/*      */     try {
/*  869 */       this.defaultLine = paramRuleRefElement.getLine();
/*  870 */       if (this.DEBUG_CODE_GENERATOR) System.out.println("genRR(" + paramRuleRefElement + ")"); 
/*  871 */       RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/*  872 */       if (ruleSymbol == null || !ruleSymbol.isDefined()) {
/*      */         
/*  874 */         this.antlrTool.error("Rule '" + paramRuleRefElement.targetRule + "' is not defined", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */         return;
/*      */       } 
/*  877 */       if (!(ruleSymbol instanceof RuleSymbol)) {
/*      */         
/*  879 */         this.antlrTool.error("'" + paramRuleRefElement.targetRule + "' does not name a grammar rule", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */         
/*      */         return;
/*      */       } 
/*  883 */       genErrorTryForElement(paramRuleRefElement);
/*      */ 
/*      */ 
/*      */       
/*  887 */       if (this.grammar instanceof TreeWalkerGrammar && paramRuleRefElement.getLabel() != null && this.syntacticPredLevel == 0)
/*      */       {
/*      */         
/*  890 */         println(paramRuleRefElement.getLabel() + " = _t==ASTNULL ? null : " + this.lt1Value + ";");
/*      */       }
/*      */ 
/*      */       
/*  894 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramRuleRefElement.getAutoGenType() == 3)) {
/*  895 */         println("_saveIndex=text.length();");
/*      */       }
/*      */ 
/*      */       
/*  899 */       printTabs();
/*  900 */       if (paramRuleRefElement.idAssign != null) {
/*      */         
/*  902 */         if (ruleSymbol.block.returnAction == null) {
/*  903 */           this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' has no return type", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */         }
/*  905 */         _print(paramRuleRefElement.idAssign + "=");
/*      */ 
/*      */       
/*      */       }
/*  909 */       else if (!(this.grammar instanceof LexerGrammar) && this.syntacticPredLevel == 0 && ruleSymbol.block.returnAction != null) {
/*  910 */         this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' returns a value", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  915 */       GenRuleInvocation(paramRuleRefElement);
/*      */ 
/*      */       
/*  918 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramRuleRefElement.getAutoGenType() == 3)) {
/*  919 */         println("text.setLength(_saveIndex);");
/*      */       }
/*      */ 
/*      */       
/*  923 */       if (this.syntacticPredLevel == 0) {
/*  924 */         boolean bool = (this.grammar.hasSyntacticPredicate && ((this.grammar.buildAST && paramRuleRefElement.getLabel() != null) || (this.genAST && paramRuleRefElement.getAutoGenType() == 1))) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  931 */         if (bool);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  936 */         if (this.grammar.buildAST && paramRuleRefElement.getLabel() != null)
/*      */         {
/*  938 */           println(paramRuleRefElement.getLabel() + "_AST = (" + this.labeledElementASTType + ")returnAST;");
/*      */         }
/*  940 */         if (this.genAST) {
/*  941 */           switch (paramRuleRefElement.getAutoGenType()) {
/*      */             
/*      */             case 1:
/*  944 */               println("astFactory.addASTChild(currentAST, returnAST);");
/*      */               break;
/*      */             case 2:
/*  947 */               this.antlrTool.error("Internal: encountered ^ after rule reference");
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  955 */         if (this.grammar instanceof LexerGrammar && paramRuleRefElement.getLabel() != null) {
/*  956 */           println(paramRuleRefElement.getLabel() + "=_returnToken;");
/*      */         }
/*      */         
/*  959 */         if (bool);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  964 */       genErrorCatchForElement(paramRuleRefElement);
/*      */     } finally {
/*  966 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(StringLiteralElement paramStringLiteralElement) {
/*  974 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genString(" + paramStringLiteralElement + ")");
/*      */ 
/*      */     
/*  977 */     if (paramStringLiteralElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  978 */       println(paramStringLiteralElement.getLabel() + " = " + this.lt1Value + ";", paramStringLiteralElement.getLine());
/*      */     }
/*      */ 
/*      */     
/*  982 */     genElementAST(paramStringLiteralElement);
/*      */ 
/*      */     
/*  985 */     boolean bool = this.saveText;
/*  986 */     this.saveText = (this.saveText && paramStringLiteralElement.getAutoGenType() == 1);
/*      */ 
/*      */     
/*  989 */     genMatch(paramStringLiteralElement);
/*      */     
/*  991 */     this.saveText = bool;
/*      */ 
/*      */     
/*  994 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*  995 */       println("_t = _t.getNextSibling();", paramStringLiteralElement.getLine());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TokenRangeElement paramTokenRangeElement) {
/* 1003 */     genErrorTryForElement(paramTokenRangeElement);
/* 1004 */     if (paramTokenRangeElement.getLabel() != null && this.syntacticPredLevel == 0) {
/* 1005 */       println(paramTokenRangeElement.getLabel() + " = " + this.lt1Value + ";", paramTokenRangeElement.getLine());
/*      */     }
/*      */ 
/*      */     
/* 1009 */     genElementAST(paramTokenRangeElement);
/*      */ 
/*      */     
/* 1012 */     println("matchRange(" + paramTokenRangeElement.beginText + "," + paramTokenRangeElement.endText + ");", paramTokenRangeElement.getLine());
/* 1013 */     genErrorCatchForElement(paramTokenRangeElement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TokenRefElement paramTokenRefElement) {
/* 1020 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genTokenRef(" + paramTokenRefElement + ")"); 
/* 1021 */     if (this.grammar instanceof LexerGrammar) {
/* 1022 */       this.antlrTool.panic("Token reference found in lexer");
/*      */     }
/* 1024 */     genErrorTryForElement(paramTokenRefElement);
/*      */     
/* 1026 */     if (paramTokenRefElement.getLabel() != null && this.syntacticPredLevel == 0) {
/* 1027 */       println(paramTokenRefElement.getLabel() + " = " + this.lt1Value + ";", paramTokenRefElement.getLine());
/*      */     }
/*      */ 
/*      */     
/* 1031 */     genElementAST(paramTokenRefElement);
/*      */     
/* 1033 */     genMatch(paramTokenRefElement);
/* 1034 */     genErrorCatchForElement(paramTokenRefElement);
/*      */ 
/*      */     
/* 1037 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 1038 */       println("_t = _t.getNextSibling();", paramTokenRefElement.getLine());
/*      */     }
/*      */   }
/*      */   
/*      */   public void gen(TreeElement paramTreeElement) {
/* 1043 */     int i = this.defaultLine;
/*      */     try {
/* 1045 */       this.defaultLine = paramTreeElement.getLine();
/*      */       
/* 1047 */       println("AST __t" + paramTreeElement.ID + " = _t;");
/*      */ 
/*      */       
/* 1050 */       if (paramTreeElement.root.getLabel() != null) {
/* 1051 */         println(paramTreeElement.root.getLabel() + " = _t==ASTNULL ? null :(" + this.labeledElementASTType + ")_t;", paramTreeElement.root.getLine());
/*      */       }
/*      */ 
/*      */       
/* 1055 */       if (paramTreeElement.root.getAutoGenType() == 3) {
/* 1056 */         this.antlrTool.error("Suffixing a root node with '!' is not implemented", this.grammar.getFilename(), paramTreeElement.getLine(), paramTreeElement.getColumn());
/*      */         
/* 1058 */         paramTreeElement.root.setAutoGenType(1);
/*      */       } 
/* 1060 */       if (paramTreeElement.root.getAutoGenType() == 2) {
/* 1061 */         this.antlrTool.warning("Suffixing a root node with '^' is redundant; already a root", this.grammar.getFilename(), paramTreeElement.getLine(), paramTreeElement.getColumn());
/*      */         
/* 1063 */         paramTreeElement.root.setAutoGenType(1);
/*      */       } 
/*      */ 
/*      */       
/* 1067 */       genElementAST(paramTreeElement.root);
/* 1068 */       if (this.grammar.buildAST) {
/*      */         
/* 1070 */         println("ASTPair __currentAST" + paramTreeElement.ID + " = currentAST.copy();");
/*      */         
/* 1072 */         println("currentAST.root = currentAST.child;");
/* 1073 */         println("currentAST.child = null;");
/*      */       } 
/*      */ 
/*      */       
/* 1077 */       if (paramTreeElement.root instanceof WildcardElement) {
/* 1078 */         println("if ( _t==null ) throw new MismatchedTokenException();", paramTreeElement.root.getLine());
/*      */       } else {
/*      */         
/* 1081 */         genMatch(paramTreeElement.root);
/*      */       } 
/*      */       
/* 1084 */       println("_t = _t.getFirstChild();");
/*      */ 
/*      */       
/* 1087 */       for (byte b = 0; b < paramTreeElement.getAlternatives().size(); b++) {
/* 1088 */         Alternative alternative = paramTreeElement.getAlternativeAt(b);
/* 1089 */         AlternativeElement alternativeElement = alternative.head;
/* 1090 */         while (alternativeElement != null) {
/* 1091 */           alternativeElement.generate();
/* 1092 */           alternativeElement = alternativeElement.next;
/*      */         } 
/*      */       } 
/*      */       
/* 1096 */       if (this.grammar.buildAST)
/*      */       {
/*      */         
/* 1099 */         println("currentAST = __currentAST" + paramTreeElement.ID + ";");
/*      */       }
/*      */       
/* 1102 */       println("_t = __t" + paramTreeElement.ID + ";");
/*      */       
/* 1104 */       println("_t = _t.getNextSibling();");
/*      */     } finally {
/* 1106 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException {
/* 1112 */     int i = this.defaultLine;
/*      */     try {
/* 1114 */       this.defaultLine = -999;
/*      */       
/* 1116 */       setGrammar(paramTreeWalkerGrammar);
/* 1117 */       if (!(this.grammar instanceof TreeWalkerGrammar)) {
/* 1118 */         this.antlrTool.panic("Internal error generating tree-walker");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1123 */       this.currentOutput = getPrintWriterManager().setupOutput(this.antlrTool, this.grammar);
/*      */       
/* 1125 */       this.genAST = this.grammar.buildAST;
/* 1126 */       this.tabs = 0;
/*      */ 
/*      */       
/* 1129 */       genHeader();
/*      */       
/*      */       try {
/* 1132 */         this.defaultLine = this.behavior.getHeaderActionLine("");
/* 1133 */         println(this.behavior.getHeaderAction(""));
/*      */       } finally {
/* 1135 */         this.defaultLine = -999;
/*      */       } 
/*      */ 
/*      */       
/* 1139 */       println("import antlr." + this.grammar.getSuperClass() + ";");
/* 1140 */       println("import antlr.Token;");
/* 1141 */       println("import antlr.collections.AST;");
/* 1142 */       println("import antlr.RecognitionException;");
/* 1143 */       println("import antlr.ANTLRException;");
/* 1144 */       println("import antlr.NoViableAltException;");
/* 1145 */       println("import antlr.MismatchedTokenException;");
/* 1146 */       println("import antlr.SemanticException;");
/* 1147 */       println("import antlr.collections.impl.BitSet;");
/* 1148 */       println("import antlr.ASTPair;");
/* 1149 */       println("import antlr.collections.impl.ASTArray;");
/*      */ 
/*      */       
/* 1152 */       println(this.grammar.preambleAction.getText());
/*      */ 
/*      */       
/* 1155 */       String str1 = null;
/* 1156 */       if (this.grammar.superClass != null) {
/* 1157 */         str1 = this.grammar.superClass;
/*      */       } else {
/*      */         
/* 1160 */         str1 = "antlr." + this.grammar.getSuperClass();
/*      */       } 
/* 1162 */       println("");
/*      */ 
/*      */       
/* 1165 */       if (this.grammar.comment != null) {
/* 1166 */         _println(this.grammar.comment);
/*      */       }
/*      */ 
/*      */       
/* 1170 */       String str2 = "public";
/* 1171 */       Token token1 = (Token)this.grammar.options.get("classHeaderPrefix");
/* 1172 */       if (token1 != null) {
/* 1173 */         String str = StringUtils.stripFrontBack(token1.getText(), "\"", "\"");
/* 1174 */         if (str != null) {
/* 1175 */           str2 = str;
/*      */         }
/*      */       } 
/*      */       
/* 1179 */       print(str2 + " ");
/* 1180 */       print("class " + this.grammar.getClassName() + " extends " + str1);
/* 1181 */       println("       implements " + this.grammar.tokenManager.getName() + TokenTypesFileSuffix);
/* 1182 */       Token token2 = (Token)this.grammar.options.get("classHeaderSuffix");
/* 1183 */       if (token2 != null) {
/* 1184 */         String str = StringUtils.stripFrontBack(token2.getText(), "\"", "\"");
/* 1185 */         if (str != null) {
/* 1186 */           print(", " + str);
/*      */         }
/*      */       } 
/* 1189 */       println(" {");
/*      */ 
/*      */       
/* 1192 */       print(processActionForSpecialSymbols(this.grammar.classMemberAction.getText(), this.grammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null), this.grammar.classMemberAction.getLine());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1198 */       println("public " + this.grammar.getClassName() + "() {");
/* 1199 */       this.tabs++;
/* 1200 */       println("tokenNames = _tokenNames;");
/* 1201 */       this.tabs--;
/* 1202 */       println("}");
/* 1203 */       println("");
/*      */ 
/*      */       
/* 1206 */       Enumeration enumeration = this.grammar.rules.elements();
/* 1207 */       byte b = 0;
/* 1208 */       String str3 = "";
/* 1209 */       while (enumeration.hasMoreElements()) {
/* 1210 */         GrammarSymbol grammarSymbol = enumeration.nextElement();
/* 1211 */         if (grammarSymbol instanceof RuleSymbol) {
/* 1212 */           RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/* 1213 */           genRule(ruleSymbol, (ruleSymbol.references.size() == 0), b++);
/*      */         } 
/* 1215 */         exitIfError();
/*      */       } 
/*      */ 
/*      */       
/* 1219 */       genTokenStrings();
/*      */ 
/*      */       
/* 1222 */       genBitsets(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType());
/*      */ 
/*      */       
/* 1225 */       println("}");
/* 1226 */       println("");
/*      */ 
/*      */       
/* 1229 */       getPrintWriterManager().finishOutput();
/*      */     } finally {
/* 1231 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(WildcardElement paramWildcardElement) {
/* 1239 */     int i = this.defaultLine;
/*      */     try {
/* 1241 */       this.defaultLine = paramWildcardElement.getLine();
/*      */       
/* 1243 */       if (paramWildcardElement.getLabel() != null && this.syntacticPredLevel == 0) {
/* 1244 */         println(paramWildcardElement.getLabel() + " = " + this.lt1Value + ";");
/*      */       }
/*      */ 
/*      */       
/* 1248 */       genElementAST(paramWildcardElement);
/*      */       
/* 1250 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 1251 */         println("if ( _t==null ) throw new MismatchedTokenException();");
/*      */       }
/* 1253 */       else if (this.grammar instanceof LexerGrammar) {
/* 1254 */         if (this.grammar instanceof LexerGrammar && (!this.saveText || paramWildcardElement.getAutoGenType() == 3))
/*      */         {
/* 1256 */           println("_saveIndex=text.length();");
/*      */         }
/* 1258 */         println("matchNot(EOF_CHAR);");
/* 1259 */         if (this.grammar instanceof LexerGrammar && (!this.saveText || paramWildcardElement.getAutoGenType() == 3))
/*      */         {
/* 1261 */           println("text.setLength(_saveIndex);");
/*      */         }
/*      */       } else {
/*      */         
/* 1265 */         println("matchNot(" + getValueString(1) + ");");
/*      */       } 
/*      */ 
/*      */       
/* 1269 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 1270 */         println("_t = _t.getNextSibling();");
/*      */       }
/*      */     } finally {
/* 1273 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ZeroOrMoreBlock paramZeroOrMoreBlock) {
/* 1281 */     int i = this.defaultLine; try {
/*      */       String str1;
/* 1283 */       this.defaultLine = paramZeroOrMoreBlock.getLine();
/* 1284 */       if (this.DEBUG_CODE_GENERATOR) System.out.println("gen*(" + paramZeroOrMoreBlock + ")"); 
/* 1285 */       println("{");
/* 1286 */       genBlockPreamble(paramZeroOrMoreBlock);
/*      */       
/* 1288 */       if (paramZeroOrMoreBlock.getLabel() != null) {
/* 1289 */         str1 = paramZeroOrMoreBlock.getLabel();
/*      */       } else {
/*      */         
/* 1292 */         str1 = "_loop" + paramZeroOrMoreBlock.ID;
/*      */       } 
/* 1294 */       println(str1 + ":");
/* 1295 */       println("do {");
/* 1296 */       this.tabs++;
/*      */ 
/*      */       
/* 1299 */       genBlockInitAction(paramZeroOrMoreBlock);
/*      */ 
/*      */       
/* 1302 */       String str2 = this.currentASTResult;
/* 1303 */       if (paramZeroOrMoreBlock.getLabel() != null) {
/* 1304 */         this.currentASTResult = paramZeroOrMoreBlock.getLabel();
/*      */       }
/*      */       
/* 1307 */       boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramZeroOrMoreBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1319 */       boolean bool1 = false;
/* 1320 */       int j = this.grammar.maxk;
/*      */       
/* 1322 */       if (!paramZeroOrMoreBlock.greedy && paramZeroOrMoreBlock.exitLookaheadDepth <= this.grammar.maxk && paramZeroOrMoreBlock.exitCache[paramZeroOrMoreBlock.exitLookaheadDepth].containsEpsilon()) {
/*      */ 
/*      */         
/* 1325 */         bool1 = true;
/* 1326 */         j = paramZeroOrMoreBlock.exitLookaheadDepth;
/*      */       }
/* 1328 */       else if (!paramZeroOrMoreBlock.greedy && paramZeroOrMoreBlock.exitLookaheadDepth == Integer.MAX_VALUE) {
/*      */         
/* 1330 */         bool1 = true;
/*      */       } 
/* 1332 */       if (bool1) {
/* 1333 */         if (this.DEBUG_CODE_GENERATOR) {
/* 1334 */           System.out.println("nongreedy (...)* loop; exit depth is " + paramZeroOrMoreBlock.exitLookaheadDepth);
/*      */         }
/*      */         
/* 1337 */         String str = getLookaheadTestExpression(paramZeroOrMoreBlock.exitCache, j);
/*      */ 
/*      */         
/* 1340 */         println("// nongreedy exit test");
/* 1341 */         println("if (" + str + ") break " + str1 + ";");
/*      */       } 
/*      */       
/* 1344 */       JavaBlockFinishingInfo javaBlockFinishingInfo = genCommonBlock(paramZeroOrMoreBlock, false);
/* 1345 */       genBlockFinish(javaBlockFinishingInfo, "break " + str1 + ";", paramZeroOrMoreBlock.getLine());
/*      */       
/* 1347 */       this.tabs--;
/* 1348 */       println("} while (true);");
/* 1349 */       println("}");
/*      */ 
/*      */       
/* 1352 */       this.currentASTResult = str2;
/*      */     } finally {
/* 1354 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genAlt(Alternative paramAlternative, AlternativeBlock paramAlternativeBlock) {
/* 1364 */     boolean bool1 = this.genAST;
/* 1365 */     this.genAST = (this.genAST && paramAlternative.getAutoGen());
/*      */     
/* 1367 */     boolean bool2 = this.saveText;
/* 1368 */     this.saveText = (this.saveText && paramAlternative.getAutoGen());
/*      */ 
/*      */     
/* 1371 */     Hashtable hashtable = this.treeVariableMap;
/* 1372 */     this.treeVariableMap = new Hashtable();
/*      */ 
/*      */     
/* 1375 */     if (paramAlternative.exceptionSpec != null) {
/* 1376 */       println("try {      // for error handling", paramAlternative.head.getLine());
/* 1377 */       this.tabs++;
/*      */     } 
/*      */     
/* 1380 */     AlternativeElement alternativeElement = paramAlternative.head;
/* 1381 */     while (!(alternativeElement instanceof BlockEndElement)) {
/* 1382 */       alternativeElement.generate();
/* 1383 */       alternativeElement = alternativeElement.next;
/*      */     } 
/*      */     
/* 1386 */     if (this.genAST) {
/* 1387 */       if (paramAlternativeBlock instanceof RuleBlock) {
/*      */         
/* 1389 */         RuleBlock ruleBlock = (RuleBlock)paramAlternativeBlock;
/* 1390 */         if (this.grammar.hasSyntacticPredicate);
/*      */ 
/*      */ 
/*      */         
/* 1394 */         println(ruleBlock.getRuleName() + "_AST = (" + this.labeledElementASTType + ")currentAST.root;", -888);
/* 1395 */         if (this.grammar.hasSyntacticPredicate);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1400 */       else if (paramAlternativeBlock.getLabel() != null) {
/*      */ 
/*      */         
/* 1403 */         this.antlrTool.warning("Labeled subrules not yet supported", this.grammar.getFilename(), paramAlternativeBlock.getLine(), paramAlternativeBlock.getColumn());
/*      */       } 
/*      */     }
/*      */     
/* 1407 */     if (paramAlternative.exceptionSpec != null) {
/*      */       
/* 1409 */       this.tabs--;
/* 1410 */       println("}", -999);
/* 1411 */       genErrorHandler(paramAlternative.exceptionSpec);
/*      */     } 
/*      */     
/* 1414 */     this.genAST = bool1;
/* 1415 */     this.saveText = bool2;
/*      */     
/* 1417 */     this.treeVariableMap = hashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBitsets(Vector paramVector, int paramInt) {
/* 1433 */     println("", -999);
/* 1434 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 1435 */       BitSet bitSet = (BitSet)paramVector.elementAt(b);
/*      */       
/* 1437 */       bitSet.growToInclude(paramInt);
/* 1438 */       genBitSet(bitSet, b);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genBitSet(BitSet paramBitSet, int paramInt) {
/* 1453 */     int i = this.defaultLine;
/*      */     try {
/* 1455 */       this.defaultLine = -999;
/*      */       
/* 1457 */       println("private static final long[] mk" + getBitsetName(paramInt) + "() {");
/*      */ 
/*      */       
/* 1460 */       int j = paramBitSet.lengthInLongWords();
/* 1461 */       if (j < 8) {
/* 1462 */         println("\tlong[] data = { " + paramBitSet.toStringOfWords() + "};");
/*      */       }
/*      */       else {
/*      */         
/* 1466 */         println("\tlong[] data = new long[" + j + "];");
/* 1467 */         long[] arrayOfLong = paramBitSet.toPackedArray(); int k;
/* 1468 */         for (k = 0; k < arrayOfLong.length; ) {
/* 1469 */           if (arrayOfLong[k] == 0L) {
/*      */             
/* 1471 */             k++;
/*      */             continue;
/*      */           } 
/* 1474 */           if (k + 1 == arrayOfLong.length || arrayOfLong[k] != arrayOfLong[k + 1]) {
/*      */             
/* 1476 */             println("\tdata[" + k + "]=" + arrayOfLong[k] + "L;");
/* 1477 */             k++;
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/* 1482 */           int m = k + 1;
/* 1483 */           while (m < arrayOfLong.length && arrayOfLong[m] == arrayOfLong[k]) {
/* 1484 */             m++;
/*      */           }
/*      */ 
/*      */           
/* 1488 */           println("\tfor (int i = " + k + "; i<=" + (m - 1) + "; i++) { data[i]=" + arrayOfLong[k] + "L; }");
/*      */           
/* 1490 */           k = m;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1495 */       println("\treturn data;");
/* 1496 */       println("}");
/*      */       
/* 1498 */       println("public static final BitSet " + getBitsetName(paramInt) + " = new BitSet(" + "mk" + getBitsetName(paramInt) + "()" + ");");
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */       
/* 1504 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genBlockFinish(JavaBlockFinishingInfo paramJavaBlockFinishingInfo, String paramString, int paramInt) {
/* 1515 */     int i = this.defaultLine;
/*      */     try {
/* 1517 */       this.defaultLine = paramInt;
/* 1518 */       if (paramJavaBlockFinishingInfo.needAnErrorClause && (paramJavaBlockFinishingInfo.generatedAnIf || paramJavaBlockFinishingInfo.generatedSwitch)) {
/*      */         
/* 1520 */         if (paramJavaBlockFinishingInfo.generatedAnIf) {
/* 1521 */           println("else {");
/*      */         } else {
/*      */           
/* 1524 */           println("{");
/*      */         } 
/* 1526 */         this.tabs++;
/* 1527 */         println(paramString);
/* 1528 */         this.tabs--;
/* 1529 */         println("}");
/*      */       } 
/*      */       
/* 1532 */       if (paramJavaBlockFinishingInfo.postscript != null) {
/* 1533 */         println(paramJavaBlockFinishingInfo.postscript);
/*      */       }
/*      */     } finally {
/* 1536 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBlockInitAction(AlternativeBlock paramAlternativeBlock) {
/* 1546 */     if (paramAlternativeBlock.initAction != null) {
/* 1547 */       printAction(processActionForSpecialSymbols(paramAlternativeBlock.initAction, paramAlternativeBlock.getLine(), this.currentRule, (ActionTransInfo)null), paramAlternativeBlock.getLine());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBlockPreamble(AlternativeBlock paramAlternativeBlock) {
/* 1558 */     if (paramAlternativeBlock instanceof RuleBlock) {
/* 1559 */       RuleBlock ruleBlock = (RuleBlock)paramAlternativeBlock;
/* 1560 */       if (ruleBlock.labeledElements != null) {
/* 1561 */         for (byte b = 0; b < ruleBlock.labeledElements.size(); b++) {
/* 1562 */           AlternativeElement alternativeElement = (AlternativeElement)ruleBlock.labeledElements.elementAt(b);
/* 1563 */           int i = this.defaultLine;
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genCases(BitSet paramBitSet, int paramInt) {
/* 1639 */     int i = this.defaultLine;
/*      */     try {
/* 1641 */       this.defaultLine = paramInt;
/* 1642 */       if (this.DEBUG_CODE_GENERATOR) System.out.println("genCases(" + paramBitSet + ")");
/*      */ 
/*      */       
/* 1645 */       int[] arrayOfInt = paramBitSet.toArray();
/*      */       
/* 1647 */       byte b1 = (this.grammar instanceof LexerGrammar) ? 4 : 1;
/* 1648 */       byte b2 = 1;
/* 1649 */       boolean bool = true;
/* 1650 */       for (byte b3 = 0; b3 < arrayOfInt.length; b3++) {
/* 1651 */         if (b2 == 1) {
/* 1652 */           print("");
/*      */         } else {
/*      */           
/* 1655 */           _print("  ");
/*      */         } 
/* 1657 */         _print("case " + getValueString(arrayOfInt[b3]) + ":");
/*      */         
/* 1659 */         if (b2 == b1) {
/* 1660 */           _println("");
/* 1661 */           bool = true;
/* 1662 */           b2 = 1;
/*      */         } else {
/*      */           
/* 1665 */           b2++;
/* 1666 */           bool = false;
/*      */         } 
/*      */       } 
/* 1669 */       if (!bool) {
/* 1670 */         _println("");
/*      */       }
/*      */     } finally {
/* 1673 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaBlockFinishingInfo genCommonBlock(AlternativeBlock paramAlternativeBlock, boolean paramBoolean) {
/* 1690 */     int i = this.defaultLine;
/*      */     try {
/* 1692 */       this.defaultLine = paramAlternativeBlock.getLine();
/* 1693 */       boolean bool1 = false;
/* 1694 */       boolean bool2 = false;
/* 1695 */       byte b1 = 0;
/* 1696 */       JavaBlockFinishingInfo javaBlockFinishingInfo = new JavaBlockFinishingInfo();
/* 1697 */       if (this.DEBUG_CODE_GENERATOR) System.out.println("genCommonBlock(" + paramAlternativeBlock + ")");
/*      */ 
/*      */       
/* 1700 */       boolean bool3 = this.genAST;
/* 1701 */       this.genAST = (this.genAST && paramAlternativeBlock.getAutoGen());
/*      */       
/* 1703 */       boolean bool4 = this.saveText;
/* 1704 */       this.saveText = (this.saveText && paramAlternativeBlock.getAutoGen());
/*      */ 
/*      */       
/* 1707 */       if (paramAlternativeBlock.not && this.analyzer.subruleCanBeInverted(paramAlternativeBlock, this.grammar instanceof LexerGrammar)) {
/*      */ 
/*      */ 
/*      */         
/* 1711 */         if (this.DEBUG_CODE_GENERATOR) System.out.println("special case: ~(subrule)"); 
/* 1712 */         Lookahead lookahead = this.analyzer.look(1, paramAlternativeBlock);
/*      */         
/* 1714 */         if (paramAlternativeBlock.getLabel() != null && this.syntacticPredLevel == 0) {
/* 1715 */           println(paramAlternativeBlock.getLabel() + " = " + this.lt1Value + ";");
/*      */         }
/*      */ 
/*      */         
/* 1719 */         genElementAST(paramAlternativeBlock);
/*      */         
/* 1721 */         String str1 = "";
/* 1722 */         if (this.grammar instanceof TreeWalkerGrammar) {
/* 1723 */           str1 = "_t,";
/*      */         }
/*      */ 
/*      */         
/* 1727 */         println("match(" + str1 + getBitsetName(markBitsetForGen(lookahead.fset)) + ");");
/*      */ 
/*      */         
/* 1730 */         if (this.grammar instanceof TreeWalkerGrammar) {
/* 1731 */           println("_t = _t.getNextSibling();");
/*      */         }
/* 1733 */         return javaBlockFinishingInfo;
/*      */       } 
/*      */ 
/*      */       
/* 1737 */       if (paramAlternativeBlock.getAlternatives().size() == 1) {
/* 1738 */         Alternative alternative = paramAlternativeBlock.getAlternativeAt(0);
/*      */         
/* 1740 */         if (alternative.synPred != null) {
/* 1741 */           this.antlrTool.warning("Syntactic predicate superfluous for single alternative", this.grammar.getFilename(), (paramAlternativeBlock.getAlternativeAt(0)).synPred.getLine(), (paramAlternativeBlock.getAlternativeAt(0)).synPred.getColumn());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1748 */         if (paramBoolean) {
/* 1749 */           if (alternative.semPred != null)
/*      */           {
/* 1751 */             genSemPred(alternative.semPred, paramAlternativeBlock.line);
/*      */           }
/* 1753 */           genAlt(alternative, paramAlternativeBlock);
/* 1754 */           return javaBlockFinishingInfo;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1767 */       byte b2 = 0; byte b3;
/* 1768 */       for (b3 = 0; b3 < paramAlternativeBlock.getAlternatives().size(); b3++) {
/* 1769 */         Alternative alternative = paramAlternativeBlock.getAlternativeAt(b3);
/* 1770 */         if (suitableForCaseExpression(alternative)) {
/* 1771 */           b2++;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1776 */       if (b2 >= this.makeSwitchThreshold) {
/*      */         
/* 1778 */         String str1 = lookaheadString(1);
/* 1779 */         bool2 = true;
/*      */         
/* 1781 */         if (this.grammar instanceof TreeWalkerGrammar) {
/* 1782 */           println("if (_t==null) _t=ASTNULL;");
/*      */         }
/* 1784 */         println("switch ( " + str1 + ") {");
/* 1785 */         for (byte b = 0; b < paramAlternativeBlock.alternatives.size(); b++) {
/* 1786 */           Alternative alternative = paramAlternativeBlock.getAlternativeAt(b);
/*      */ 
/*      */           
/* 1789 */           if (suitableForCaseExpression(alternative)) {
/*      */ 
/*      */             
/* 1792 */             Lookahead lookahead = alternative.cache[1];
/* 1793 */             if (lookahead.fset.degree() == 0 && !lookahead.containsEpsilon()) {
/* 1794 */               this.antlrTool.warning("Alternate omitted due to empty prediction set", this.grammar.getFilename(), alternative.head.getLine(), alternative.head.getColumn());
/*      */             
/*      */             }
/*      */             else {
/*      */               
/* 1799 */               genCases(lookahead.fset, alternative.head.getLine());
/* 1800 */               println("{", alternative.head.getLine());
/* 1801 */               this.tabs++;
/* 1802 */               genAlt(alternative, paramAlternativeBlock);
/* 1803 */               println("break;", -999);
/* 1804 */               this.tabs--;
/* 1805 */               println("}", -999);
/*      */             } 
/*      */           } 
/* 1808 */         }  println("default:");
/* 1809 */         this.tabs++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1825 */       b3 = (this.grammar instanceof LexerGrammar) ? this.grammar.maxk : 0;
/* 1826 */       for (byte b4 = b3; b4 >= 0; b4--) {
/* 1827 */         if (this.DEBUG_CODE_GENERATOR) System.out.println("checking depth " + b4); 
/* 1828 */         byte b = 0; while (true) { if (b < paramAlternativeBlock.alternatives.size()) {
/* 1829 */             Alternative alternative = paramAlternativeBlock.getAlternativeAt(b);
/* 1830 */             if (this.DEBUG_CODE_GENERATOR) System.out.println("genAlt: " + b);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1835 */             if (bool2 && suitableForCaseExpression(alternative)) {
/* 1836 */               if (this.DEBUG_CODE_GENERATOR) System.out.println("ignoring alt because it was in the switch");
/*      */             
/*      */             }
/*      */             else {
/*      */               
/* 1841 */               boolean bool = false;
/*      */               
/* 1843 */               if (this.grammar instanceof LexerGrammar)
/*      */               
/*      */               { 
/*      */                 
/* 1847 */                 int j = alternative.lookaheadDepth;
/* 1848 */                 if (j == Integer.MAX_VALUE)
/*      */                 {
/* 1850 */                   j = this.grammar.maxk;
/*      */                 }
/* 1852 */                 while (j >= 1 && alternative.cache[j].containsEpsilon())
/*      */                 {
/* 1854 */                   j--;
/*      */                 }
/*      */ 
/*      */                 
/* 1858 */                 if (j != b4)
/* 1859 */                 { if (this.DEBUG_CODE_GENERATOR) {
/* 1860 */                     System.out.println("ignoring alt because effectiveDepth!=altDepth;" + j + "!=" + b4);
/*      */                   } }
/*      */                 else
/* 1863 */                 { bool = lookaheadIsEmpty(alternative, j);
/* 1864 */                   String str1 = getLookaheadTestExpression(alternative, j);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1871 */                   j = this.defaultLine; }  } else { bool = lookaheadIsEmpty(alternative, this.grammar.maxk); String str1 = getLookaheadTestExpression(alternative, this.grammar.maxk); int j = this.defaultLine; }
/*      */             
/*      */             } 
/*      */           } else {
/*      */             break;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           b++; }
/*      */       
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1966 */       String str = "";
/* 1967 */       for (byte b5 = 1; b5 <= b1; b5++) {
/* 1968 */         str = str + "}";
/*      */       }
/*      */ 
/*      */       
/* 1972 */       this.genAST = bool3;
/*      */ 
/*      */       
/* 1975 */       this.saveText = bool4;
/*      */ 
/*      */       
/* 1978 */       if (bool2) {
/* 1979 */         this.tabs--;
/* 1980 */         javaBlockFinishingInfo.postscript = str + "}";
/* 1981 */         javaBlockFinishingInfo.generatedSwitch = true;
/* 1982 */         javaBlockFinishingInfo.generatedAnIf = bool1;
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1987 */         javaBlockFinishingInfo.postscript = str;
/* 1988 */         javaBlockFinishingInfo.generatedSwitch = false;
/* 1989 */         javaBlockFinishingInfo.generatedAnIf = bool1;
/*      */       } 
/*      */       
/* 1992 */       return javaBlockFinishingInfo;
/*      */     } finally {
/* 1994 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean suitableForCaseExpression(Alternative paramAlternative) {
/* 1999 */     return (paramAlternative.lookaheadDepth == 1 && paramAlternative.semPred == null && !paramAlternative.cache[1].containsEpsilon() && (paramAlternative.cache[1]).fset.degree() <= 127);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genElementAST(AlternativeElement paramAlternativeElement) {
/* 2008 */     int i = this.defaultLine;
/*      */     try {
/* 2010 */       this.defaultLine = paramAlternativeElement.getLine();
/*      */ 
/*      */       
/* 2013 */       if (this.grammar instanceof TreeWalkerGrammar && !this.grammar.buildAST) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2018 */         if (paramAlternativeElement.getLabel() == null) {
/* 2019 */           String str1 = this.lt1Value;
/*      */           
/* 2021 */           String str2 = "tmp" + this.astVarNumber + "_AST";
/* 2022 */           this.astVarNumber++;
/*      */           
/* 2024 */           mapTreeVariable(paramAlternativeElement, str2);
/*      */           
/* 2026 */           println(this.labeledElementASTType + " " + str2 + "_in = " + str1 + ";");
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/* 2031 */       if (this.grammar.buildAST && this.syntacticPredLevel == 0) {
/* 2032 */         String str1, str2; boolean bool1 = (this.genAST && (paramAlternativeElement.getLabel() != null || paramAlternativeElement.getAutoGenType() != 3)) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2043 */         if (paramAlternativeElement.getAutoGenType() != 3 && paramAlternativeElement instanceof TokenRefElement)
/*      */         {
/*      */           
/* 2046 */           bool1 = true;
/*      */         }
/*      */         
/* 2049 */         boolean bool2 = (this.grammar.hasSyntacticPredicate && bool1) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2056 */         if (paramAlternativeElement.getLabel() != null) {
/* 2057 */           str1 = paramAlternativeElement.getLabel();
/* 2058 */           str2 = paramAlternativeElement.getLabel();
/*      */         } else {
/*      */           
/* 2061 */           str1 = this.lt1Value;
/*      */           
/* 2063 */           str2 = "tmp" + this.astVarNumber;
/*      */           
/* 2065 */           this.astVarNumber++;
/*      */         } 
/*      */ 
/*      */         
/* 2069 */         if (bool1)
/*      */         {
/* 2071 */           if (paramAlternativeElement instanceof GrammarAtom) {
/* 2072 */             GrammarAtom grammarAtom = (GrammarAtom)paramAlternativeElement;
/* 2073 */             if (grammarAtom.getASTNodeType() != null) {
/* 2074 */               genASTDeclaration(paramAlternativeElement, str2, grammarAtom.getASTNodeType());
/*      */             }
/*      */             else {
/*      */               
/* 2078 */               genASTDeclaration(paramAlternativeElement, str2, this.labeledElementASTType);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 2083 */             genASTDeclaration(paramAlternativeElement, str2, this.labeledElementASTType);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2089 */         String str3 = str2 + "_AST";
/*      */ 
/*      */         
/* 2092 */         mapTreeVariable(paramAlternativeElement, str3);
/* 2093 */         if (this.grammar instanceof TreeWalkerGrammar)
/*      */         {
/* 2095 */           println(this.labeledElementASTType + " " + str3 + "_in = null;");
/*      */         }
/*      */ 
/*      */         
/* 2099 */         if (bool2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2106 */         if (paramAlternativeElement.getLabel() != null) {
/* 2107 */           if (paramAlternativeElement instanceof GrammarAtom) {
/* 2108 */             println(str3 + " = " + getASTCreateString((GrammarAtom)paramAlternativeElement, str1) + ";");
/*      */           } else {
/*      */             
/* 2111 */             println(str3 + " = " + getASTCreateString(str1) + ";");
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 2116 */         if (paramAlternativeElement.getLabel() == null && bool1) {
/* 2117 */           str1 = this.lt1Value;
/* 2118 */           if (paramAlternativeElement instanceof GrammarAtom) {
/* 2119 */             println(str3 + " = " + getASTCreateString((GrammarAtom)paramAlternativeElement, str1) + ";");
/*      */           } else {
/*      */             
/* 2122 */             println(str3 + " = " + getASTCreateString(str1) + ";");
/*      */           } 
/*      */           
/* 2125 */           if (this.grammar instanceof TreeWalkerGrammar)
/*      */           {
/* 2127 */             println(str3 + "_in = " + str1 + ";");
/*      */           }
/*      */         } 
/*      */         
/* 2131 */         if (this.genAST) {
/* 2132 */           switch (paramAlternativeElement.getAutoGenType()) {
/*      */             case 1:
/* 2134 */               println("astFactory.addASTChild(currentAST, " + str3 + ");");
/*      */               break;
/*      */             case 2:
/* 2137 */               println("astFactory.makeASTRoot(currentAST, " + str3 + ");");
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/*      */         }
/* 2143 */         if (bool2);
/*      */       }
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 2149 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorCatchForElement(AlternativeElement paramAlternativeElement) {
/* 2157 */     if (paramAlternativeElement.getLabel() == null)
/* 2158 */       return;  String str = paramAlternativeElement.enclosingRuleName;
/* 2159 */     if (this.grammar instanceof LexerGrammar) {
/* 2160 */       str = CodeGenerator.encodeLexerRuleName(paramAlternativeElement.enclosingRuleName);
/*      */     }
/* 2162 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 2163 */     if (ruleSymbol == null) {
/* 2164 */       this.antlrTool.panic("Enclosing rule not found!");
/*      */     }
/* 2166 */     ExceptionSpec exceptionSpec = ruleSymbol.block.findExceptionSpec(paramAlternativeElement.getLabel());
/* 2167 */     if (exceptionSpec != null) {
/* 2168 */       this.tabs--;
/* 2169 */       println("}", paramAlternativeElement.getLine());
/* 2170 */       genErrorHandler(exceptionSpec);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorHandler(ExceptionSpec paramExceptionSpec) {
/* 2177 */     for (byte b = 0; b < paramExceptionSpec.handlers.size(); b++) {
/* 2178 */       ExceptionHandler exceptionHandler = (ExceptionHandler)paramExceptionSpec.handlers.elementAt(b);
/* 2179 */       int i = this.defaultLine;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorTryForElement(AlternativeElement paramAlternativeElement) {
/* 2222 */     if (paramAlternativeElement.getLabel() == null)
/* 2223 */       return;  String str = paramAlternativeElement.enclosingRuleName;
/* 2224 */     if (this.grammar instanceof LexerGrammar) {
/* 2225 */       str = CodeGenerator.encodeLexerRuleName(paramAlternativeElement.enclosingRuleName);
/*      */     }
/* 2227 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 2228 */     if (ruleSymbol == null) {
/* 2229 */       this.antlrTool.panic("Enclosing rule not found!");
/*      */     }
/* 2231 */     ExceptionSpec exceptionSpec = ruleSymbol.block.findExceptionSpec(paramAlternativeElement.getLabel());
/* 2232 */     if (exceptionSpec != null) {
/* 2233 */       println("try { // for error handling", paramAlternativeElement.getLine());
/* 2234 */       this.tabs++;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement) {
/* 2239 */     genASTDeclaration(paramAlternativeElement, this.labeledElementASTType);
/*      */   }
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement, String paramString) {
/* 2243 */     genASTDeclaration(paramAlternativeElement, paramAlternativeElement.getLabel(), paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement, String paramString1, String paramString2) {
/* 2248 */     if (this.declaredASTVariables.contains(paramAlternativeElement)) {
/*      */       return;
/*      */     }
/*      */     
/* 2252 */     println(paramString2 + " " + paramString1 + "_AST = null;");
/*      */ 
/*      */     
/* 2255 */     this.declaredASTVariables.put(paramAlternativeElement, paramAlternativeElement);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genHeader() {
/* 2260 */     println("// $ANTLR " + Tool.version + ": " + "\"" + this.antlrTool.fileMinusPath(this.antlrTool.grammarFile) + "\"" + " -> " + "\"" + this.grammar.getClassName() + ".java\"$", -999);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genLiteralsTest() {
/* 2267 */     println("_ttype = testLiteralsTable(_ttype);");
/*      */   }
/*      */   
/*      */   private void genLiteralsTestForPartialToken() {
/* 2271 */     println("_ttype = testLiteralsTable(new String(text.getBuffer(),_begin,text.length()-_begin),_ttype);");
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genMatch(BitSet paramBitSet) {}
/*      */   
/*      */   protected void genMatch(GrammarAtom paramGrammarAtom) {
/* 2278 */     if (paramGrammarAtom instanceof StringLiteralElement) {
/* 2279 */       if (this.grammar instanceof LexerGrammar) {
/* 2280 */         genMatchUsingAtomText(paramGrammarAtom);
/*      */       } else {
/*      */         
/* 2283 */         genMatchUsingAtomTokenType(paramGrammarAtom);
/*      */       }
/*      */     
/* 2286 */     } else if (paramGrammarAtom instanceof CharLiteralElement) {
/* 2287 */       if (this.grammar instanceof LexerGrammar) {
/* 2288 */         genMatchUsingAtomText(paramGrammarAtom);
/*      */       } else {
/*      */         
/* 2291 */         this.antlrTool.error("cannot ref character literals in grammar: " + paramGrammarAtom);
/*      */       }
/*      */     
/* 2294 */     } else if (paramGrammarAtom instanceof TokenRefElement) {
/* 2295 */       genMatchUsingAtomText(paramGrammarAtom);
/*      */     }
/* 2297 */     else if (paramGrammarAtom instanceof WildcardElement) {
/* 2298 */       gen((WildcardElement)paramGrammarAtom);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void genMatchUsingAtomText(GrammarAtom paramGrammarAtom) {
/* 2303 */     int i = this.defaultLine;
/*      */     try {
/* 2305 */       this.defaultLine = paramGrammarAtom.getLine();
/*      */       
/* 2307 */       String str = "";
/* 2308 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 2309 */         str = "_t,";
/*      */       }
/*      */ 
/*      */       
/* 2313 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramGrammarAtom.getAutoGenType() == 3)) {
/* 2314 */         println("_saveIndex=text.length();");
/*      */       }
/*      */       
/* 2317 */       print(paramGrammarAtom.not ? "matchNot(" : "match(");
/* 2318 */       _print(str, -999);
/*      */ 
/*      */       
/* 2321 */       if (paramGrammarAtom.atomText.equals("EOF")) {
/*      */         
/* 2323 */         _print("Token.EOF_TYPE");
/*      */       } else {
/*      */         
/* 2326 */         _print(paramGrammarAtom.atomText);
/*      */       } 
/* 2328 */       _println(");");
/*      */       
/* 2330 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramGrammarAtom.getAutoGenType() == 3)) {
/* 2331 */         println("text.setLength(_saveIndex);");
/*      */       }
/*      */     } finally {
/* 2334 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genMatchUsingAtomTokenType(GrammarAtom paramGrammarAtom) {
/* 2340 */     String str1 = "";
/* 2341 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 2342 */       str1 = "_t,";
/*      */     }
/*      */ 
/*      */     
/* 2346 */     Object object = null;
/* 2347 */     String str2 = str1 + getValueString(paramGrammarAtom.getType());
/*      */ 
/*      */     
/* 2350 */     println((paramGrammarAtom.not ? "matchNot(" : "match(") + str2 + ");", paramGrammarAtom.getLine());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genNextToken() {
/* 2358 */     int i = this.defaultLine;
/*      */     try {
/* 2360 */       this.defaultLine = -999;
/*      */ 
/*      */       
/* 2363 */       boolean bool = false;
/* 2364 */       for (byte b1 = 0; b1 < this.grammar.rules.size(); b1++) {
/* 2365 */         RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.rules.elementAt(b1);
/* 2366 */         if (ruleSymbol1.isDefined() && ruleSymbol1.access.equals("public")) {
/* 2367 */           bool = true;
/*      */           break;
/*      */         } 
/*      */       } 
/* 2371 */       if (!bool) {
/* 2372 */         println("");
/* 2373 */         println("public Token nextToken() throws TokenStreamException {");
/* 2374 */         println("\ttry {uponEOF();}");
/* 2375 */         println("\tcatch(CharStreamIOException csioe) {");
/* 2376 */         println("\t\tthrow new TokenStreamIOException(csioe.io);");
/* 2377 */         println("\t}");
/* 2378 */         println("\tcatch(CharStreamException cse) {");
/* 2379 */         println("\t\tthrow new TokenStreamException(cse.getMessage());");
/* 2380 */         println("\t}");
/* 2381 */         println("\treturn new CommonToken(Token.EOF_TYPE, \"\");");
/* 2382 */         println("}");
/* 2383 */         println("");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2388 */       RuleBlock ruleBlock = MakeGrammar.createNextTokenRule(this.grammar, this.grammar.rules, "nextToken");
/*      */       
/* 2390 */       RuleSymbol ruleSymbol = new RuleSymbol("mnextToken");
/* 2391 */       ruleSymbol.setDefined();
/* 2392 */       ruleSymbol.setBlock(ruleBlock);
/* 2393 */       ruleSymbol.access = "private";
/* 2394 */       this.grammar.define(ruleSymbol);
/*      */       
/* 2396 */       boolean bool1 = this.grammar.theLLkAnalyzer.deterministic(ruleBlock);
/*      */ 
/*      */       
/* 2399 */       String str1 = null;
/* 2400 */       if (((LexerGrammar)this.grammar).filterMode) {
/* 2401 */         str1 = ((LexerGrammar)this.grammar).filterRule;
/*      */       }
/*      */       
/* 2404 */       println("");
/* 2405 */       println("public Token nextToken() throws TokenStreamException {");
/* 2406 */       this.tabs++;
/* 2407 */       println("Token theRetToken=null;");
/* 2408 */       _println("tryAgain:");
/* 2409 */       println("for (;;) {");
/* 2410 */       this.tabs++;
/* 2411 */       println("Token _token = null;");
/* 2412 */       println("int _ttype = Token.INVALID_TYPE;");
/* 2413 */       if (((LexerGrammar)this.grammar).filterMode) {
/* 2414 */         println("setCommitToPath(false);");
/* 2415 */         if (str1 != null) {
/*      */           
/* 2417 */           if (!this.grammar.isDefined(CodeGenerator.encodeLexerRuleName(str1))) {
/* 2418 */             this.grammar.antlrTool.error("Filter rule " + str1 + " does not exist in this lexer");
/*      */           } else {
/*      */             
/* 2421 */             RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.getSymbol(CodeGenerator.encodeLexerRuleName(str1));
/* 2422 */             if (!ruleSymbol1.isDefined()) {
/* 2423 */               this.grammar.antlrTool.error("Filter rule " + str1 + " does not exist in this lexer");
/*      */             }
/* 2425 */             else if (ruleSymbol1.access.equals("public")) {
/* 2426 */               this.grammar.antlrTool.error("Filter rule " + str1 + " must be protected");
/*      */             } 
/*      */           } 
/* 2429 */           println("int _m;");
/* 2430 */           println("_m = mark();");
/*      */         } 
/*      */       } 
/* 2433 */       println("resetText();");
/*      */       
/* 2435 */       println("try {   // for char stream error handling");
/* 2436 */       this.tabs++;
/*      */ 
/*      */       
/* 2439 */       println("try {   // for lexical error handling");
/* 2440 */       this.tabs++;
/*      */ 
/*      */       
/* 2443 */       for (byte b2 = 0; b2 < ruleBlock.getAlternatives().size(); b2++) {
/* 2444 */         Alternative alternative = ruleBlock.getAlternativeAt(b2);
/* 2445 */         if (alternative.cache[1].containsEpsilon()) {
/*      */           
/* 2447 */           RuleRefElement ruleRefElement = (RuleRefElement)alternative.head;
/* 2448 */           String str = CodeGenerator.decodeLexerRuleName(ruleRefElement.targetRule);
/* 2449 */           this.antlrTool.warning("public lexical rule " + str + " is optional (can match \"nothing\")");
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 2454 */       String str2 = System.getProperty("line.separator");
/* 2455 */       JavaBlockFinishingInfo javaBlockFinishingInfo = genCommonBlock(ruleBlock, false);
/* 2456 */       String str3 = "if (LA(1)==EOF_CHAR) {uponEOF(); _returnToken = makeToken(Token.EOF_TYPE);}";
/* 2457 */       str3 = str3 + str2 + "\t\t\t\t";
/* 2458 */       if (((LexerGrammar)this.grammar).filterMode) {
/* 2459 */         if (str1 == null) {
/* 2460 */           str3 = str3 + "else {consume(); continue tryAgain;}";
/*      */         } else {
/*      */           
/* 2463 */           str3 = str3 + "else {" + str2 + "\t\t\t\t\tcommit();" + str2 + "\t\t\t\t\ttry {m" + str1 + "(false);}" + str2 + "\t\t\t\t\tcatch(RecognitionException e) {" + str2 + "\t\t\t\t\t\t// catastrophic failure" + str2 + "\t\t\t\t\t\treportError(e);" + str2 + "\t\t\t\t\t\tconsume();" + str2 + "\t\t\t\t\t}" + str2 + "\t\t\t\t\tcontinue tryAgain;" + str2 + "\t\t\t\t}";
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 2476 */         str3 = str3 + "else {" + this.throwNoViable + "}";
/*      */       } 
/* 2478 */       genBlockFinish(javaBlockFinishingInfo, str3, ruleBlock.getLine());
/*      */ 
/*      */       
/* 2481 */       if (((LexerGrammar)this.grammar).filterMode && str1 != null) {
/* 2482 */         println("commit();");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2488 */       println("if ( _returnToken==null ) continue tryAgain; // found SKIP token");
/* 2489 */       println("_ttype = _returnToken.getType();");
/* 2490 */       if (((LexerGrammar)this.grammar).getTestLiterals()) {
/* 2491 */         genLiteralsTest();
/*      */       }
/*      */ 
/*      */       
/* 2495 */       println("_returnToken.setType(_ttype);");
/* 2496 */       println("return _returnToken;");
/*      */ 
/*      */       
/* 2499 */       this.tabs--;
/* 2500 */       println("}");
/* 2501 */       println("catch (RecognitionException e) {");
/* 2502 */       this.tabs++;
/* 2503 */       if (((LexerGrammar)this.grammar).filterMode) {
/* 2504 */         if (str1 == null) {
/* 2505 */           println("if ( !getCommitToPath() ) {consume(); continue tryAgain;}");
/*      */         } else {
/*      */           
/* 2508 */           println("if ( !getCommitToPath() ) {");
/* 2509 */           this.tabs++;
/* 2510 */           println("rewind(_m);");
/* 2511 */           println("resetText();");
/* 2512 */           println("try {m" + str1 + "(false);}");
/* 2513 */           println("catch(RecognitionException ee) {");
/* 2514 */           println("\t// horrendous failure: error in filter rule");
/* 2515 */           println("\treportError(ee);");
/* 2516 */           println("\tconsume();");
/* 2517 */           println("}");
/* 2518 */           println("continue tryAgain;");
/* 2519 */           this.tabs--;
/* 2520 */           println("}");
/*      */         } 
/*      */       }
/* 2523 */       if (ruleBlock.getDefaultErrorHandler()) {
/* 2524 */         println("reportError(e);");
/* 2525 */         println("consume();");
/*      */       }
/*      */       else {
/*      */         
/* 2529 */         println("throw new TokenStreamRecognitionException(e);");
/*      */       } 
/* 2531 */       this.tabs--;
/* 2532 */       println("}");
/*      */ 
/*      */       
/* 2535 */       this.tabs--;
/* 2536 */       println("}");
/* 2537 */       println("catch (CharStreamException cse) {");
/* 2538 */       println("\tif ( cse instanceof CharStreamIOException ) {");
/* 2539 */       println("\t\tthrow new TokenStreamIOException(((CharStreamIOException)cse).io);");
/* 2540 */       println("\t}");
/* 2541 */       println("\telse {");
/* 2542 */       println("\t\tthrow new TokenStreamException(cse.getMessage());");
/* 2543 */       println("\t}");
/* 2544 */       println("}");
/*      */ 
/*      */       
/* 2547 */       this.tabs--;
/* 2548 */       println("}");
/*      */ 
/*      */       
/* 2551 */       this.tabs--;
/* 2552 */       println("}");
/* 2553 */       println("");
/*      */     } finally {
/* 2555 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genRule(RuleSymbol paramRuleSymbol, boolean paramBoolean, int paramInt) {
/* 2576 */     this.tabs = 1;
/*      */     
/* 2578 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genRule(" + paramRuleSymbol.getId() + ")"); 
/* 2579 */     if (!paramRuleSymbol.isDefined()) {
/* 2580 */       this.antlrTool.error("undefined rule: " + paramRuleSymbol.getId());
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2585 */     RuleBlock ruleBlock = paramRuleSymbol.getBlock();
/*      */     
/* 2587 */     int i = this.defaultLine;
/*      */     try {
/* 2589 */       this.defaultLine = ruleBlock.getLine();
/* 2590 */       this.currentRule = ruleBlock;
/* 2591 */       this.currentASTResult = paramRuleSymbol.getId();
/*      */ 
/*      */       
/* 2594 */       this.declaredASTVariables.clear();
/*      */ 
/*      */       
/* 2597 */       boolean bool = this.genAST;
/* 2598 */       this.genAST = (this.genAST && ruleBlock.getAutoGen());
/*      */ 
/*      */       
/* 2601 */       this.saveText = ruleBlock.getAutoGen();
/*      */ 
/*      */       
/* 2604 */       if (paramRuleSymbol.comment != null) {
/* 2605 */         _println(paramRuleSymbol.comment);
/*      */       }
/*      */ 
/*      */       
/* 2609 */       print(paramRuleSymbol.access + " final ");
/*      */ 
/*      */       
/* 2612 */       if (ruleBlock.returnAction != null) {
/*      */         
/* 2614 */         _print(extractTypeOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + " ");
/*      */       }
/*      */       else {
/*      */         
/* 2618 */         _print("void ");
/*      */       } 
/*      */ 
/*      */       
/* 2622 */       _print(paramRuleSymbol.getId() + "(");
/*      */ 
/*      */       
/* 2625 */       _print(this.commonExtraParams);
/* 2626 */       if (this.commonExtraParams.length() != 0 && ruleBlock.argAction != null) {
/* 2627 */         _print(",");
/*      */       }
/*      */ 
/*      */       
/* 2631 */       if (ruleBlock.argAction != null) {
/*      */         
/* 2633 */         _println("");
/* 2634 */         this.tabs++;
/* 2635 */         println(ruleBlock.argAction);
/* 2636 */         this.tabs--;
/* 2637 */         print(")");
/*      */       }
/*      */       else {
/*      */         
/* 2641 */         _print(")");
/*      */       } 
/*      */ 
/*      */       
/* 2645 */       _print(" throws " + this.exceptionThrown);
/* 2646 */       if (this.grammar instanceof ParserGrammar) {
/* 2647 */         _print(", TokenStreamException");
/*      */       }
/* 2649 */       else if (this.grammar instanceof LexerGrammar) {
/* 2650 */         _print(", CharStreamException, TokenStreamException");
/*      */       } 
/*      */       
/* 2653 */       if (ruleBlock.throwsSpec != null) {
/* 2654 */         if (this.grammar instanceof LexerGrammar) {
/* 2655 */           this.antlrTool.error("user-defined throws spec not allowed (yet) for lexer rule " + ruleBlock.ruleName);
/*      */         } else {
/*      */           
/* 2658 */           _print(", " + ruleBlock.throwsSpec);
/*      */         } 
/*      */       }
/*      */       
/* 2662 */       _println(" {");
/* 2663 */       this.tabs++;
/*      */ 
/*      */       
/* 2666 */       if (ruleBlock.returnAction != null) {
/* 2667 */         println(ruleBlock.returnAction + ";");
/*      */       }
/*      */       
/* 2670 */       println(this.commonLocalVars);
/*      */       
/* 2672 */       if (this.grammar.traceRules) {
/* 2673 */         if (this.grammar instanceof TreeWalkerGrammar) {
/* 2674 */           println("traceIn(\"" + paramRuleSymbol.getId() + "\",_t);");
/*      */         } else {
/*      */           
/* 2677 */           println("traceIn(\"" + paramRuleSymbol.getId() + "\");");
/*      */         } 
/*      */       }
/*      */       
/* 2681 */       if (this.grammar instanceof LexerGrammar) {
/*      */ 
/*      */         
/* 2684 */         if (paramRuleSymbol.getId().equals("mEOF")) {
/* 2685 */           println("_ttype = Token.EOF_TYPE;");
/*      */         } else {
/* 2687 */           println("_ttype = " + paramRuleSymbol.getId().substring(1) + ";");
/* 2688 */         }  println("int _saveIndex;");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2698 */       if (this.grammar.debuggingOutput) {
/* 2699 */         if (this.grammar instanceof ParserGrammar) {
/* 2700 */           println("fireEnterRule(" + paramInt + ",0);");
/* 2701 */         } else if (this.grammar instanceof LexerGrammar) {
/* 2702 */           println("fireEnterRule(" + paramInt + ",_ttype);");
/*      */         } 
/*      */       }
/* 2705 */       if (this.grammar.debuggingOutput || this.grammar.traceRules) {
/* 2706 */         println("try { // debugging");
/* 2707 */         this.tabs++;
/*      */       } 
/*      */ 
/*      */       
/* 2711 */       if (this.grammar instanceof TreeWalkerGrammar)
/*      */       {
/* 2713 */         println(this.labeledElementASTType + " " + paramRuleSymbol.getId() + "_AST_in = (_t == ASTNULL) ? null : (" + this.labeledElementASTType + ")_t;", -999);
/*      */       }
/* 2715 */       if (this.grammar.buildAST) {
/*      */         
/* 2717 */         println("returnAST = null;");
/*      */ 
/*      */         
/* 2720 */         println("ASTPair currentAST = new ASTPair();");
/*      */         
/* 2722 */         println(this.labeledElementASTType + " " + paramRuleSymbol.getId() + "_AST = null;");
/*      */       } 
/*      */       
/* 2725 */       genBlockPreamble(ruleBlock);
/* 2726 */       genBlockInitAction(ruleBlock);
/* 2727 */       println("");
/*      */ 
/*      */       
/* 2730 */       ExceptionSpec exceptionSpec = ruleBlock.findExceptionSpec("");
/*      */ 
/*      */       
/* 2733 */       if (exceptionSpec != null || ruleBlock.getDefaultErrorHandler()) {
/* 2734 */         println("try {      // for error handling");
/* 2735 */         this.tabs++;
/*      */       } 
/*      */ 
/*      */       
/* 2739 */       if (ruleBlock.alternatives.size() == 1) {
/*      */         
/* 2741 */         Alternative alternative = ruleBlock.getAlternativeAt(0);
/* 2742 */         String str = alternative.semPred;
/* 2743 */         if (str != null)
/* 2744 */           genSemPred(str, this.currentRule.line); 
/* 2745 */         if (alternative.synPred != null) {
/* 2746 */           this.antlrTool.warning("Syntactic predicate ignored for single alternative", this.grammar.getFilename(), alternative.synPred.getLine(), alternative.synPred.getColumn());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2753 */         genAlt(alternative, ruleBlock);
/*      */       }
/*      */       else {
/*      */         
/* 2757 */         boolean bool1 = this.grammar.theLLkAnalyzer.deterministic(ruleBlock);
/*      */         
/* 2759 */         JavaBlockFinishingInfo javaBlockFinishingInfo = genCommonBlock(ruleBlock, false);
/* 2760 */         genBlockFinish(javaBlockFinishingInfo, this.throwNoViable, ruleBlock.getLine());
/*      */       } 
/*      */ 
/*      */       
/* 2764 */       if (exceptionSpec != null || ruleBlock.getDefaultErrorHandler()) {
/*      */         
/* 2766 */         this.tabs--;
/* 2767 */         println("}");
/*      */       } 
/*      */ 
/*      */       
/* 2771 */       if (exceptionSpec != null) {
/* 2772 */         genErrorHandler(exceptionSpec);
/*      */       }
/* 2774 */       else if (ruleBlock.getDefaultErrorHandler()) {
/*      */         
/* 2776 */         println("catch (" + this.exceptionThrown + " ex) {");
/* 2777 */         this.tabs++;
/*      */         
/* 2779 */         if (this.grammar.hasSyntacticPredicate) {
/* 2780 */           println("if (inputState.guessing==0) {");
/* 2781 */           this.tabs++;
/*      */         } 
/* 2783 */         println("reportError(ex);");
/* 2784 */         if (!(this.grammar instanceof TreeWalkerGrammar)) {
/*      */           
/* 2786 */           Lookahead lookahead = this.grammar.theLLkAnalyzer.FOLLOW(1, ruleBlock.endNode);
/* 2787 */           String str = getBitsetName(markBitsetForGen(lookahead.fset));
/* 2788 */           println("recover(ex," + str + ");");
/*      */         }
/*      */         else {
/*      */           
/* 2792 */           println("if (_t!=null) {_t = _t.getNextSibling();}");
/*      */         } 
/* 2794 */         if (this.grammar.hasSyntacticPredicate) {
/* 2795 */           this.tabs--;
/*      */           
/* 2797 */           println("} else {");
/* 2798 */           println("  throw ex;");
/* 2799 */           println("}");
/*      */         } 
/*      */         
/* 2802 */         this.tabs--;
/* 2803 */         println("}");
/*      */       } 
/*      */ 
/*      */       
/* 2807 */       if (this.grammar.buildAST) {
/* 2808 */         println("returnAST = " + paramRuleSymbol.getId() + "_AST;");
/*      */       }
/*      */ 
/*      */       
/* 2812 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 2813 */         println("_retTree = _t;");
/*      */       }
/*      */ 
/*      */       
/* 2817 */       if (ruleBlock.getTestLiterals()) {
/* 2818 */         if (paramRuleSymbol.access.equals("protected")) {
/* 2819 */           genLiteralsTestForPartialToken();
/*      */         } else {
/*      */           
/* 2822 */           genLiteralsTest();
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 2827 */       if (this.grammar instanceof LexerGrammar) {
/* 2828 */         println("if ( _createToken && _token==null && _ttype!=Token.SKIP ) {");
/* 2829 */         println("\t_token = makeToken(_ttype);");
/* 2830 */         println("\t_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));");
/* 2831 */         println("}");
/* 2832 */         println("_returnToken = _token;");
/*      */       } 
/*      */ 
/*      */       
/* 2836 */       if (ruleBlock.returnAction != null) {
/* 2837 */         println("return " + extractIdOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + ";");
/*      */       }
/*      */       
/* 2840 */       if (this.grammar.debuggingOutput || this.grammar.traceRules) {
/* 2841 */         this.tabs--;
/* 2842 */         println("} finally { // debugging");
/* 2843 */         this.tabs++;
/*      */ 
/*      */         
/* 2846 */         if (this.grammar.debuggingOutput)
/* 2847 */           if (this.grammar instanceof ParserGrammar) {
/* 2848 */             println("fireExitRule(" + paramInt + ",0);");
/* 2849 */           } else if (this.grammar instanceof LexerGrammar) {
/* 2850 */             println("fireExitRule(" + paramInt + ",_ttype);");
/*      */           }  
/* 2852 */         if (this.grammar.traceRules) {
/* 2853 */           if (this.grammar instanceof TreeWalkerGrammar) {
/* 2854 */             println("traceOut(\"" + paramRuleSymbol.getId() + "\",_t);");
/*      */           } else {
/*      */             
/* 2857 */             println("traceOut(\"" + paramRuleSymbol.getId() + "\");");
/*      */           } 
/*      */         }
/*      */         
/* 2861 */         this.tabs--;
/* 2862 */         println("}");
/*      */       } 
/*      */       
/* 2865 */       this.tabs--;
/* 2866 */       println("}");
/* 2867 */       println("");
/*      */ 
/*      */       
/* 2870 */       this.genAST = bool;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 2875 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void GenRuleInvocation(RuleRefElement paramRuleRefElement) {
/* 2880 */     int i = this.defaultLine;
/*      */     try {
/* 2882 */       this.defaultLine = paramRuleRefElement.getLine();
/*      */       
/* 2884 */       getPrintWriterManager().startSingleSourceLineMapping(paramRuleRefElement.getLine());
/* 2885 */       _print(paramRuleRefElement.targetRule + "(");
/* 2886 */       getPrintWriterManager().endMapping();
/*      */ 
/*      */       
/* 2889 */       if (this.grammar instanceof LexerGrammar) {
/*      */         
/* 2891 */         if (paramRuleRefElement.getLabel() != null) {
/* 2892 */           _print("true");
/*      */         } else {
/*      */           
/* 2895 */           _print("false");
/*      */         } 
/* 2897 */         if (this.commonExtraArgs.length() != 0 || paramRuleRefElement.args != null) {
/* 2898 */           _print(",");
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 2903 */       _print(this.commonExtraArgs);
/* 2904 */       if (this.commonExtraArgs.length() != 0 && paramRuleRefElement.args != null) {
/* 2905 */         _print(",");
/*      */       }
/*      */ 
/*      */       
/* 2909 */       RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/* 2910 */       if (paramRuleRefElement.args != null) {
/*      */         
/* 2912 */         ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 2913 */         String str = processActionForSpecialSymbols(paramRuleRefElement.args, 0, this.currentRule, actionTransInfo);
/* 2914 */         if (actionTransInfo.assignToRoot || actionTransInfo.refRuleRoot != null) {
/* 2915 */           this.antlrTool.error("Arguments of rule reference '" + paramRuleRefElement.targetRule + "' cannot set or ref #" + this.currentRule.getRuleName(), this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */         }
/*      */         
/* 2918 */         _print(str);
/*      */ 
/*      */         
/* 2921 */         if (ruleSymbol.block.argAction == null) {
/* 2922 */           this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' accepts no arguments", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */ 
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 2928 */       else if (ruleSymbol.block.argAction != null) {
/* 2929 */         this.antlrTool.warning("Missing parameters on reference to rule " + paramRuleRefElement.targetRule, this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       } 
/*      */       
/* 2932 */       _println(");");
/*      */ 
/*      */       
/* 2935 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 2936 */         println("_t = _retTree;");
/*      */       }
/*      */     } finally {
/* 2939 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genSemPred(String paramString, int paramInt) {
/* 2945 */     ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 2946 */     paramString = processActionForSpecialSymbols(paramString, paramInt, this.currentRule, actionTransInfo);
/*      */     
/* 2948 */     String str = this.charFormatter.escapeString(paramString);
/*      */ 
/*      */ 
/*      */     
/* 2952 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar)) {
/* 2953 */       paramString = "fireSemanticPredicateEvaluated(antlr.debug.SemanticPredicateEvent.VALIDATING," + addSemPred(str) + "," + paramString + ")";
/*      */     }
/* 2955 */     println("if (!(" + paramString + "))", paramInt);
/* 2956 */     println("  throw new SemanticException(\"" + str + "\");", paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genSemPredMap() {
/* 2963 */     Enumeration enumeration = this.semPreds.elements();
/* 2964 */     println("private String _semPredNames[] = {", -999);
/* 2965 */     while (enumeration.hasMoreElements())
/* 2966 */       println("\"" + enumeration.nextElement() + "\",", -999); 
/* 2967 */     println("};", -999);
/*      */   }
/*      */   
/*      */   protected void genSynPred(SynPredBlock paramSynPredBlock, String paramString) {
/* 2971 */     int i = this.defaultLine;
/*      */     try {
/* 2973 */       this.defaultLine = paramSynPredBlock.getLine();
/* 2974 */       if (this.DEBUG_CODE_GENERATOR) System.out.println("gen=>(" + paramSynPredBlock + ")");
/*      */ 
/*      */       
/* 2977 */       println("boolean synPredMatched" + paramSynPredBlock.ID + " = false;");
/*      */ 
/*      */       
/* 2980 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 2981 */         println("if (_t==null) _t=ASTNULL;");
/*      */       }
/*      */ 
/*      */       
/* 2985 */       println("if (" + paramString + ") {");
/* 2986 */       this.tabs++;
/*      */ 
/*      */       
/* 2989 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 2990 */         println("AST __t" + paramSynPredBlock.ID + " = _t;");
/*      */       } else {
/*      */         
/* 2993 */         println("int _m" + paramSynPredBlock.ID + " = mark();");
/*      */       } 
/*      */ 
/*      */       
/* 2997 */       println("synPredMatched" + paramSynPredBlock.ID + " = true;");
/* 2998 */       println("inputState.guessing++;");
/*      */ 
/*      */       
/* 3001 */       if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar))
/*      */       {
/* 3003 */         println("fireSyntacticPredicateStarted();");
/*      */       }
/*      */       
/* 3006 */       this.syntacticPredLevel++;
/* 3007 */       println("try {");
/* 3008 */       this.tabs++;
/* 3009 */       gen(paramSynPredBlock);
/* 3010 */       this.tabs--;
/*      */       
/* 3012 */       println("}");
/* 3013 */       println("catch (" + this.exceptionThrown + " pe) {");
/* 3014 */       this.tabs++;
/* 3015 */       println("synPredMatched" + paramSynPredBlock.ID + " = false;");
/*      */       
/* 3017 */       this.tabs--;
/* 3018 */       println("}");
/*      */ 
/*      */       
/* 3021 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 3022 */         println("_t = __t" + paramSynPredBlock.ID + ";");
/*      */       } else {
/*      */         
/* 3025 */         println("rewind(_m" + paramSynPredBlock.ID + ");");
/*      */       } 
/*      */       
/* 3028 */       _println("inputState.guessing--;");
/*      */ 
/*      */       
/* 3031 */       if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar)) {
/*      */         
/* 3033 */         println("if (synPredMatched" + paramSynPredBlock.ID + ")");
/* 3034 */         println("  fireSyntacticPredicateSucceeded();");
/* 3035 */         println("else");
/* 3036 */         println("  fireSyntacticPredicateFailed();");
/*      */       } 
/*      */       
/* 3039 */       this.syntacticPredLevel--;
/* 3040 */       this.tabs--;
/*      */ 
/*      */       
/* 3043 */       println("}");
/*      */ 
/*      */       
/* 3046 */       println("if ( synPredMatched" + paramSynPredBlock.ID + " ) {");
/*      */     } finally {
/* 3048 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genTokenStrings() {
/* 3061 */     int i = this.defaultLine;
/*      */     try {
/* 3063 */       this.defaultLine = -999;
/*      */ 
/*      */       
/* 3066 */       println("");
/* 3067 */       println("public static final String[] _tokenNames = {");
/* 3068 */       this.tabs++;
/*      */ 
/*      */ 
/*      */       
/* 3072 */       Vector vector = this.grammar.tokenManager.getVocabulary();
/* 3073 */       for (byte b = 0; b < vector.size(); b++) {
/* 3074 */         String str = (String)vector.elementAt(b);
/* 3075 */         if (str == null) {
/* 3076 */           str = "<" + String.valueOf(b) + ">";
/*      */         }
/* 3078 */         if (!str.startsWith("\"") && !str.startsWith("<")) {
/* 3079 */           TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/* 3080 */           if (tokenSymbol != null && tokenSymbol.getParaphrase() != null) {
/* 3081 */             str = StringUtils.stripFrontBack(tokenSymbol.getParaphrase(), "\"", "\"");
/*      */           }
/*      */         } 
/* 3084 */         print(this.charFormatter.literalString(str));
/* 3085 */         if (b != vector.size() - 1) {
/* 3086 */           _print(",");
/*      */         }
/* 3088 */         _println("");
/*      */       } 
/*      */ 
/*      */       
/* 3092 */       this.tabs--;
/* 3093 */       println("};");
/*      */     } finally {
/* 3095 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genTokenASTNodeMap() {
/* 3103 */     int i = this.defaultLine;
/*      */     try {
/* 3105 */       this.defaultLine = -999;
/* 3106 */       println("");
/* 3107 */       println("protected void buildTokenTypeASTClassMap() {");
/*      */ 
/*      */       
/* 3110 */       this.tabs++;
/* 3111 */       boolean bool = false;
/* 3112 */       byte b1 = 0;
/*      */       
/* 3114 */       Vector vector = this.grammar.tokenManager.getVocabulary();
/* 3115 */       for (byte b2 = 0; b2 < vector.size(); b2++) {
/* 3116 */         String str = (String)vector.elementAt(b2);
/* 3117 */         if (str != null) {
/* 3118 */           TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/* 3119 */           if (tokenSymbol != null && tokenSymbol.getASTNodeType() != null) {
/* 3120 */             b1++;
/* 3121 */             if (!bool) {
/*      */               
/* 3123 */               println("tokenTypeToASTClassMap = new Hashtable();");
/* 3124 */               bool = true;
/*      */             } 
/* 3126 */             println("tokenTypeToASTClassMap.put(new Integer(" + tokenSymbol.getTokenType() + "), " + tokenSymbol.getASTNodeType() + ".class);");
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 3132 */       if (b1 == 0) {
/* 3133 */         println("tokenTypeToASTClassMap=null;");
/*      */       }
/* 3135 */       this.tabs--;
/* 3136 */       println("};");
/*      */     } finally {
/* 3138 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genTokenTypes(TokenManager paramTokenManager) throws IOException {
/* 3144 */     int i = this.defaultLine;
/*      */     try {
/* 3146 */       this.defaultLine = -999;
/*      */ 
/*      */ 
/*      */       
/* 3150 */       this.currentOutput = getPrintWriterManager().setupOutput(this.antlrTool, paramTokenManager.getName() + TokenTypesFileSuffix);
/*      */       
/* 3152 */       this.tabs = 0;
/*      */ 
/*      */       
/* 3155 */       genHeader();
/*      */       
/*      */       try {
/* 3158 */         this.defaultLine = this.behavior.getHeaderActionLine("");
/* 3159 */         println(this.behavior.getHeaderAction(""));
/*      */       } finally {
/* 3161 */         this.defaultLine = -999;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3166 */       println("public interface " + paramTokenManager.getName() + TokenTypesFileSuffix + " {");
/* 3167 */       this.tabs++;
/*      */ 
/*      */       
/* 3170 */       Vector vector = paramTokenManager.getVocabulary();
/*      */ 
/*      */       
/* 3173 */       println("int EOF = 1;");
/* 3174 */       println("int NULL_TREE_LOOKAHEAD = 3;");
/*      */       
/* 3176 */       for (byte b = 4; b < vector.size(); b++) {
/* 3177 */         String str = (String)vector.elementAt(b);
/* 3178 */         if (str != null) {
/* 3179 */           if (str.startsWith("\"")) {
/*      */             
/* 3181 */             StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)paramTokenManager.getTokenSymbol(str);
/* 3182 */             if (stringLiteralSymbol == null) {
/* 3183 */               this.antlrTool.panic("String literal " + str + " not in symbol table");
/*      */             }
/* 3185 */             else if (stringLiteralSymbol.label != null) {
/* 3186 */               println("int " + stringLiteralSymbol.label + " = " + b + ";");
/*      */             } else {
/*      */               
/* 3189 */               String str1 = mangleLiteral(str);
/* 3190 */               if (str1 != null) {
/*      */                 
/* 3192 */                 println("int " + str1 + " = " + b + ";");
/*      */                 
/* 3194 */                 stringLiteralSymbol.label = str1;
/*      */               } else {
/*      */                 
/* 3197 */                 println("// " + str + " = " + b);
/*      */               }
/*      */             
/*      */             } 
/* 3201 */           } else if (!str.startsWith("<")) {
/* 3202 */             println("int " + str + " = " + b + ";");
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 3208 */       this.tabs--;
/* 3209 */       println("}");
/*      */ 
/*      */       
/* 3212 */       getPrintWriterManager().finishOutput();
/* 3213 */       exitIfError();
/*      */     } finally {
/* 3215 */       this.defaultLine = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(Vector paramVector) {
/* 3223 */     if (paramVector.size() == 0) {
/* 3224 */       return "";
/*      */     }
/* 3226 */     StringBuffer stringBuffer = new StringBuffer();
/* 3227 */     stringBuffer.append("(" + this.labeledElementASTType + ")astFactory.make( (new ASTArray(" + paramVector.size() + "))");
/*      */ 
/*      */     
/* 3230 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 3231 */       stringBuffer.append(".add(" + paramVector.elementAt(b) + ")");
/*      */     }
/* 3233 */     stringBuffer.append(")");
/* 3234 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(GrammarAtom paramGrammarAtom, String paramString) {
/* 3243 */     if (paramGrammarAtom != null && paramGrammarAtom.getASTNodeType() != null)
/*      */     {
/* 3245 */       return "(" + paramGrammarAtom.getASTNodeType() + ")" + "astFactory.create(" + paramString + ",\"" + paramGrammarAtom.getASTNodeType() + "\")";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3250 */     return getASTCreateString(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(String paramString) {
/* 3264 */     if (paramString == null) {
/* 3265 */       paramString = "";
/*      */     }
/* 3267 */     byte b = 0; int i;
/* 3268 */     for (i = 0; i < paramString.length(); i++) {
/* 3269 */       if (paramString.charAt(i) == ',') {
/* 3270 */         b++;
/*      */       }
/*      */     } 
/*      */     
/* 3274 */     if (b < 2) {
/* 3275 */       i = paramString.indexOf(',');
/* 3276 */       int j = paramString.lastIndexOf(',');
/* 3277 */       String str = paramString;
/* 3278 */       if (b > 0) {
/* 3279 */         str = paramString.substring(0, i);
/*      */       }
/*      */       
/* 3282 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/* 3283 */       if (tokenSymbol != null) {
/* 3284 */         String str1 = tokenSymbol.getASTNodeType();
/*      */         
/* 3286 */         String str2 = "";
/* 3287 */         if (b == 0)
/*      */         {
/* 3289 */           str2 = ",\"\"";
/*      */         }
/* 3291 */         if (str1 != null) {
/* 3292 */           return "(" + str1 + ")" + "astFactory.create(" + paramString + str2 + ",\"" + str1 + "\")";
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3298 */       if (this.labeledElementASTType.equals("AST")) {
/* 3299 */         return "astFactory.create(" + paramString + ")";
/*      */       }
/* 3301 */       return "(" + this.labeledElementASTType + ")" + "astFactory.create(" + paramString + ")";
/*      */     } 
/*      */ 
/*      */     
/* 3305 */     return "(" + this.labeledElementASTType + ")astFactory.create(" + paramString + ")";
/*      */   }
/*      */   
/*      */   protected String getLookaheadTestExpression(Lookahead[] paramArrayOfLookahead, int paramInt) {
/* 3309 */     StringBuffer stringBuffer = new StringBuffer(100);
/* 3310 */     boolean bool = true;
/*      */     
/* 3312 */     stringBuffer.append("(");
/* 3313 */     for (byte b = 1; b <= paramInt; b++) {
/* 3314 */       BitSet bitSet = (paramArrayOfLookahead[b]).fset;
/* 3315 */       if (!bool) {
/* 3316 */         stringBuffer.append(") && (");
/*      */       }
/* 3318 */       bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3323 */       if (paramArrayOfLookahead[b].containsEpsilon()) {
/* 3324 */         stringBuffer.append("true");
/*      */       } else {
/*      */         
/* 3327 */         stringBuffer.append(getLookaheadTestTerm(b, bitSet));
/*      */       } 
/*      */     } 
/* 3330 */     stringBuffer.append(")");
/*      */     
/* 3332 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLookaheadTestExpression(Alternative paramAlternative, int paramInt) {
/* 3340 */     int i = paramAlternative.lookaheadDepth;
/* 3341 */     if (i == Integer.MAX_VALUE)
/*      */     {
/*      */       
/* 3344 */       i = this.grammar.maxk;
/*      */     }
/*      */     
/* 3347 */     if (paramInt == 0)
/*      */     {
/*      */       
/* 3350 */       return "( true )";
/*      */     }
/*      */     
/* 3353 */     return "(" + getLookaheadTestExpression(paramAlternative.cache, i) + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLookaheadTestTerm(int paramInt, BitSet paramBitSet) {
/* 3366 */     String str = lookaheadString(paramInt);
/*      */ 
/*      */     
/* 3369 */     int[] arrayOfInt = paramBitSet.toArray();
/* 3370 */     if (elementsAreRange(arrayOfInt)) {
/* 3371 */       return getRangeExpression(paramInt, arrayOfInt);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3376 */     int i = paramBitSet.degree();
/* 3377 */     if (i == 0) {
/* 3378 */       return "true";
/*      */     }
/*      */     
/* 3381 */     if (i >= this.bitsetTestThreshold) {
/* 3382 */       int j = markBitsetForGen(paramBitSet);
/* 3383 */       return getBitsetName(j) + ".member(" + str + ")";
/*      */     } 
/*      */ 
/*      */     
/* 3387 */     StringBuffer stringBuffer = new StringBuffer();
/* 3388 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */       
/* 3390 */       String str1 = getValueString(arrayOfInt[b]);
/*      */ 
/*      */       
/* 3393 */       if (b > 0) stringBuffer.append("||"); 
/* 3394 */       stringBuffer.append(str);
/* 3395 */       stringBuffer.append("==");
/* 3396 */       stringBuffer.append(str1);
/*      */     } 
/* 3398 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRangeExpression(int paramInt, int[] paramArrayOfint) {
/* 3407 */     if (!elementsAreRange(paramArrayOfint)) {
/* 3408 */       this.antlrTool.panic("getRangeExpression called with non-range");
/*      */     }
/* 3410 */     int i = paramArrayOfint[0];
/* 3411 */     int j = paramArrayOfint[paramArrayOfint.length - 1];
/* 3412 */     return "(" + lookaheadString(paramInt) + " >= " + getValueString(i) + " && " + lookaheadString(paramInt) + " <= " + getValueString(j) + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getValueString(int paramInt) {
/*      */     String str;
/* 3422 */     if (this.grammar instanceof LexerGrammar) {
/* 3423 */       str = this.charFormatter.literalChar(paramInt);
/*      */     } else {
/*      */       
/* 3426 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbolAt(paramInt);
/* 3427 */       if (tokenSymbol == null) {
/* 3428 */         return "" + paramInt;
/*      */       }
/*      */       
/* 3431 */       String str1 = tokenSymbol.getId();
/* 3432 */       if (tokenSymbol instanceof StringLiteralSymbol) {
/*      */ 
/*      */ 
/*      */         
/* 3436 */         StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)tokenSymbol;
/* 3437 */         String str2 = stringLiteralSymbol.getLabel();
/* 3438 */         if (str2 != null) {
/* 3439 */           str = str2;
/*      */         } else {
/*      */           
/* 3442 */           str = mangleLiteral(str1);
/* 3443 */           if (str == null) {
/* 3444 */             str = String.valueOf(paramInt);
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         
/* 3449 */         str = str1;
/*      */       } 
/*      */     } 
/* 3452 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean lookaheadIsEmpty(Alternative paramAlternative, int paramInt) {
/* 3457 */     int i = paramAlternative.lookaheadDepth;
/* 3458 */     if (i == Integer.MAX_VALUE) {
/* 3459 */       i = this.grammar.maxk;
/*      */     }
/* 3461 */     for (byte b = 1; b <= i && b <= paramInt; b++) {
/* 3462 */       BitSet bitSet = (paramAlternative.cache[b]).fset;
/* 3463 */       if (bitSet.degree() != 0) {
/* 3464 */         return false;
/*      */       }
/*      */     } 
/* 3467 */     return true;
/*      */   }
/*      */   
/*      */   private String lookaheadString(int paramInt) {
/* 3471 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3472 */       return "_t.getType()";
/*      */     }
/* 3474 */     return "LA(" + paramInt + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String mangleLiteral(String paramString) {
/* 3484 */     String str = this.antlrTool.literalsPrefix;
/* 3485 */     for (byte b = 1; b < paramString.length() - 1; b++) {
/* 3486 */       if (!Character.isLetter(paramString.charAt(b)) && paramString.charAt(b) != '_')
/*      */       {
/* 3488 */         return null;
/*      */       }
/* 3490 */       str = str + paramString.charAt(b);
/*      */     } 
/* 3492 */     if (this.antlrTool.upperCaseMangledLiterals) {
/* 3493 */       str = str.toUpperCase();
/*      */     }
/* 3495 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String mapTreeId(String paramString, ActionTransInfo paramActionTransInfo) {
/* 3506 */     if (this.currentRule == null) return paramString;
/*      */     
/* 3508 */     boolean bool = false;
/* 3509 */     String str1 = paramString;
/* 3510 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3511 */       if (!this.grammar.buildAST) {
/* 3512 */         bool = true;
/*      */       
/*      */       }
/* 3515 */       else if (str1.length() > 3 && str1.lastIndexOf("_in") == str1.length() - 3) {
/*      */         
/* 3517 */         str1 = str1.substring(0, str1.length() - 3);
/* 3518 */         bool = true;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3524 */     for (byte b = 0; b < this.currentRule.labeledElements.size(); b++) {
/* 3525 */       AlternativeElement alternativeElement = (AlternativeElement)this.currentRule.labeledElements.elementAt(b);
/* 3526 */       if (alternativeElement.getLabel().equals(str1)) {
/* 3527 */         return bool ? str1 : (str1 + "_AST");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3534 */     String str2 = (String)this.treeVariableMap.get(str1);
/* 3535 */     if (str2 != null) {
/* 3536 */       if (str2 == NONUNIQUE) {
/*      */         
/* 3538 */         this.antlrTool.error("Ambiguous reference to AST element " + str1 + " in rule " + this.currentRule.getRuleName());
/*      */ 
/*      */         
/* 3541 */         return null;
/*      */       } 
/* 3543 */       if (str2.equals(this.currentRule.getRuleName())) {
/*      */ 
/*      */         
/* 3546 */         this.antlrTool.error("Ambiguous reference to AST element " + str1 + " in rule " + this.currentRule.getRuleName());
/*      */         
/* 3548 */         return null;
/*      */       } 
/*      */       
/* 3551 */       return bool ? (str2 + "_in") : str2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3557 */     if (str1.equals(this.currentRule.getRuleName())) {
/* 3558 */       String str = bool ? (str1 + "_AST_in") : (str1 + "_AST");
/* 3559 */       if (paramActionTransInfo != null && 
/* 3560 */         !bool) {
/* 3561 */         paramActionTransInfo.refRuleRoot = str;
/*      */       }
/*      */       
/* 3564 */       return str;
/*      */     } 
/*      */ 
/*      */     
/* 3568 */     return str1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void mapTreeVariable(AlternativeElement paramAlternativeElement, String paramString) {
/* 3577 */     if (paramAlternativeElement instanceof TreeElement) {
/* 3578 */       mapTreeVariable(((TreeElement)paramAlternativeElement).root, paramString);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3583 */     String str = null;
/*      */ 
/*      */     
/* 3586 */     if (paramAlternativeElement.getLabel() == null) {
/* 3587 */       if (paramAlternativeElement instanceof TokenRefElement) {
/*      */         
/* 3589 */         str = ((TokenRefElement)paramAlternativeElement).atomText;
/*      */       }
/* 3591 */       else if (paramAlternativeElement instanceof RuleRefElement) {
/*      */         
/* 3593 */         str = ((RuleRefElement)paramAlternativeElement).targetRule;
/*      */       } 
/*      */     }
/*      */     
/* 3597 */     if (str != null) {
/* 3598 */       if (this.treeVariableMap.get(str) != null) {
/*      */         
/* 3600 */         this.treeVariableMap.remove(str);
/* 3601 */         this.treeVariableMap.put(str, NONUNIQUE);
/*      */       } else {
/*      */         
/* 3604 */         this.treeVariableMap.put(str, paramString);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String processActionForSpecialSymbols(String paramString, int paramInt, RuleBlock paramRuleBlock, ActionTransInfo paramActionTransInfo) {
/* 3617 */     if (paramString == null || paramString.length() == 0) return null;
/*      */ 
/*      */ 
/*      */     
/* 3621 */     if (this.grammar == null) {
/* 3622 */       return paramString;
/*      */     }
/*      */     
/* 3625 */     if ((this.grammar.buildAST && paramString.indexOf('#') != -1) || this.grammar instanceof TreeWalkerGrammar || ((this.grammar instanceof LexerGrammar || this.grammar instanceof ParserGrammar) && paramString.indexOf('$') != -1)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3631 */       ActionLexer actionLexer = new ActionLexer(paramString, paramRuleBlock, this, paramActionTransInfo);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3637 */       actionLexer.setLineOffset(paramInt);
/* 3638 */       actionLexer.setFilename(this.grammar.getFilename());
/* 3639 */       actionLexer.setTool(this.antlrTool);
/*      */       
/*      */       try {
/* 3642 */         actionLexer.mACTION(true);
/* 3643 */         paramString = actionLexer.getTokenObject().getText();
/*      */ 
/*      */       
/*      */       }
/* 3647 */       catch (RecognitionException recognitionException) {
/* 3648 */         actionLexer.reportError(recognitionException);
/* 3649 */         return paramString;
/*      */       }
/* 3651 */       catch (TokenStreamException tokenStreamException) {
/* 3652 */         this.antlrTool.panic("Error reading action:" + paramString);
/* 3653 */         return paramString;
/*      */       }
/* 3655 */       catch (CharStreamException charStreamException) {
/* 3656 */         this.antlrTool.panic("Error reading action:" + paramString);
/* 3657 */         return paramString;
/*      */       } 
/*      */     } 
/* 3660 */     return paramString;
/*      */   }
/*      */   
/*      */   private void setupGrammarParameters(Grammar paramGrammar) {
/* 3664 */     if (paramGrammar instanceof ParserGrammar) {
/* 3665 */       this.labeledElementASTType = "AST";
/* 3666 */       if (paramGrammar.hasOption("ASTLabelType")) {
/* 3667 */         Token token = paramGrammar.getOption("ASTLabelType");
/* 3668 */         if (token != null) {
/* 3669 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3670 */           if (str != null) {
/* 3671 */             this.labeledElementASTType = str;
/*      */           }
/*      */         } 
/*      */       } 
/* 3675 */       this.labeledElementType = "Token ";
/* 3676 */       this.labeledElementInit = "null";
/* 3677 */       this.commonExtraArgs = "";
/* 3678 */       this.commonExtraParams = "";
/* 3679 */       this.commonLocalVars = "";
/* 3680 */       this.lt1Value = "LT(1)";
/* 3681 */       this.exceptionThrown = "RecognitionException";
/* 3682 */       this.throwNoViable = "throw new NoViableAltException(LT(1), getFilename());";
/*      */     }
/* 3684 */     else if (paramGrammar instanceof LexerGrammar) {
/* 3685 */       this.labeledElementType = "char ";
/* 3686 */       this.labeledElementInit = "'\\0'";
/* 3687 */       this.commonExtraArgs = "";
/* 3688 */       this.commonExtraParams = "boolean _createToken";
/* 3689 */       this.commonLocalVars = "int _ttype; Token _token=null; int _begin=text.length();";
/* 3690 */       this.lt1Value = "LA(1)";
/* 3691 */       this.exceptionThrown = "RecognitionException";
/* 3692 */       this.throwNoViable = "throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());";
/*      */     }
/* 3694 */     else if (paramGrammar instanceof TreeWalkerGrammar) {
/* 3695 */       this.labeledElementASTType = "AST";
/* 3696 */       this.labeledElementType = "AST";
/* 3697 */       if (paramGrammar.hasOption("ASTLabelType")) {
/* 3698 */         Token token = paramGrammar.getOption("ASTLabelType");
/* 3699 */         if (token != null) {
/* 3700 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3701 */           if (str != null) {
/* 3702 */             this.labeledElementASTType = str;
/* 3703 */             this.labeledElementType = str;
/*      */           } 
/*      */         } 
/*      */       } 
/* 3707 */       if (!paramGrammar.hasOption("ASTLabelType")) {
/* 3708 */         paramGrammar.setOption("ASTLabelType", new Token(6, "AST"));
/*      */       }
/* 3710 */       this.labeledElementInit = "null";
/* 3711 */       this.commonExtraArgs = "_t";
/* 3712 */       this.commonExtraParams = "AST _t";
/* 3713 */       this.commonLocalVars = "";
/* 3714 */       this.lt1Value = "(" + this.labeledElementASTType + ")_t";
/* 3715 */       this.exceptionThrown = "RecognitionException";
/* 3716 */       this.throwNoViable = "throw new NoViableAltException(_t);";
/*      */     } else {
/*      */       
/* 3719 */       this.antlrTool.panic("Unknown grammar type");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaCodeGeneratorPrintWriterManager getPrintWriterManager() {
/* 3728 */     if (this.printWriterManager == null)
/* 3729 */       this.printWriterManager = new DefaultJavaCodeGeneratorPrintWriterManager(); 
/* 3730 */     return this.printWriterManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPrintWriterManager(JavaCodeGeneratorPrintWriterManager paramJavaCodeGeneratorPrintWriterManager) {
/* 3738 */     this.printWriterManager = paramJavaCodeGeneratorPrintWriterManager;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTool(Tool paramTool) {
/* 3743 */     super.setTool(paramTool);
/*      */   }
/*      */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\JavaCodeGenerator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */