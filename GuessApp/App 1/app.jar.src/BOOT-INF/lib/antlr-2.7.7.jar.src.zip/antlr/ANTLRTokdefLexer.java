/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.impl.BitSet;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ANTLRTokdefLexer
/*     */   extends CharScanner
/*     */   implements ANTLRTokdefParserTokenTypes, TokenStream
/*     */ {
/*     */   public ANTLRTokdefLexer(InputStream paramInputStream) {
/*  30 */     this(new ByteBuffer(paramInputStream));
/*     */   }
/*     */   public ANTLRTokdefLexer(Reader paramReader) {
/*  33 */     this(new CharBuffer(paramReader));
/*     */   }
/*     */   public ANTLRTokdefLexer(InputBuffer paramInputBuffer) {
/*  36 */     this(new LexerSharedInputState(paramInputBuffer));
/*     */   }
/*     */   public ANTLRTokdefLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  39 */     super(paramLexerSharedInputState);
/*  40 */     this.caseSensitiveLiterals = true;
/*  41 */     setCaseSensitive(true);
/*  42 */     this.literals = new Hashtable();
/*     */   }
/*     */   
/*     */   public Token nextToken() throws TokenStreamException {
/*  46 */     Token token = null;
/*     */     
/*     */     while (true) {
/*  49 */       Object object = null;
/*  50 */       int i = 0;
/*  51 */       resetText();
/*     */       
/*     */       try {
/*  54 */         switch (LA(1)) { case '\t': case '\n':
/*     */           case '\r':
/*     */           case ' ':
/*  57 */             mWS(true);
/*  58 */             token = this._returnToken;
/*     */             break;
/*     */ 
/*     */           
/*     */           case '(':
/*  63 */             mLPAREN(true);
/*  64 */             token = this._returnToken;
/*     */             break;
/*     */ 
/*     */           
/*     */           case ')':
/*  69 */             mRPAREN(true);
/*  70 */             token = this._returnToken;
/*     */             break;
/*     */ 
/*     */           
/*     */           case '=':
/*  75 */             mASSIGN(true);
/*  76 */             token = this._returnToken;
/*     */             break;
/*     */ 
/*     */           
/*     */           case '"':
/*  81 */             mSTRING(true);
/*  82 */             token = this._returnToken; break;
/*     */           case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k':
/*     */           case 'l':
/*     */           case 'm':
/*     */           case 'n':
/*     */           case 'o':
/*     */           case 'p':
/*     */           case 'q':
/*     */           case 'r':
/*     */           case 's':
/*     */           case 't':
/*     */           case 'u':
/*     */           case 'v':
/*     */           case 'w':
/*     */           case 'x':
/*     */           case 'y':
/*     */           case 'z':
/*  99 */             mID(true);
/* 100 */             token = this._returnToken; break;
/*     */           case '0': case '1': case '2': case '3': case '4':
/*     */           case '5':
/*     */           case '6':
/*     */           case '7':
/*     */           case '8':
/*     */           case '9':
/* 107 */             mINT(true);
/* 108 */             token = this._returnToken;
/*     */             break;
/*     */           
/*     */           default:
/* 112 */             if (LA(1) == '/' && LA(2) == '/') {
/* 113 */               mSL_COMMENT(true);
/* 114 */               token = this._returnToken; break;
/*     */             } 
/* 116 */             if (LA(1) == '/' && LA(2) == '*') {
/* 117 */               mML_COMMENT(true);
/* 118 */               token = this._returnToken;
/*     */               break;
/*     */             } 
/* 121 */             if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); break; }
/* 122 */              throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*     */ 
/*     */         
/* 125 */         if (this._returnToken == null)
/* 126 */           continue;  i = this._returnToken.getType();
/* 127 */         this._returnToken.setType(i);
/* 128 */         return this._returnToken;
/*     */       }
/* 130 */       catch (RecognitionException recognitionException) {
/* 131 */         throw new TokenStreamRecognitionException(recognitionException);
/*     */       
/*     */       }
/* 134 */       catch (CharStreamException charStreamException) {
/* 135 */         if (charStreamException instanceof CharStreamIOException) {
/* 136 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*     */         }
/*     */         
/* 139 */         throw new TokenStreamException(charStreamException.getMessage());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void mWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 146 */     Token token = null; int i = this.text.length();
/* 147 */     byte b = 10;
/*     */ 
/*     */ 
/*     */     
/* 151 */     switch (LA(1)) {
/*     */       
/*     */       case ' ':
/* 154 */         match(' ');
/*     */         break;
/*     */ 
/*     */       
/*     */       case '\t':
/* 159 */         match('\t');
/*     */         break;
/*     */ 
/*     */       
/*     */       case '\r':
/* 164 */         match('\r');
/*     */         
/* 166 */         if (LA(1) == '\n') {
/* 167 */           match('\n');
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 173 */         newline();
/*     */         break;
/*     */ 
/*     */       
/*     */       case '\n':
/* 178 */         match('\n');
/* 179 */         newline();
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 184 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */     } 
/*     */ 
/*     */     
/* 188 */     b = -1;
/* 189 */     if (paramBoolean && token == null && b != -1) {
/* 190 */       token = makeToken(b);
/* 191 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 193 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   public final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 197 */     Token token = null; int i = this.text.length();
/* 198 */     byte b = 11;
/*     */ 
/*     */     
/* 201 */     match("//");
/*     */ 
/*     */ 
/*     */     
/* 205 */     while (_tokenSet_0.member(LA(1)))
/*     */     {
/* 207 */       match(_tokenSet_0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     switch (LA(1)) {
/*     */       
/*     */       case '\n':
/* 220 */         match('\n');
/*     */         break;
/*     */ 
/*     */       
/*     */       case '\r':
/* 225 */         match('\r');
/*     */         
/* 227 */         if (LA(1) == '\n') {
/* 228 */           match('\n');
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 238 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */     } 
/*     */ 
/*     */     
/* 242 */     b = -1; newline();
/* 243 */     if (paramBoolean && token == null && b != -1) {
/* 244 */       token = makeToken(b);
/* 245 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 247 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   public final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 251 */     Token token = null; int i = this.text.length();
/* 252 */     byte b = 12;
/*     */ 
/*     */     
/* 255 */     match("/*");
/*     */ 
/*     */     
/*     */     while (true) {
/* 259 */       if (LA(1) == '*' && _tokenSet_1.member(LA(2))) {
/* 260 */         match('*');
/* 261 */         matchNot('/'); continue;
/*     */       } 
/* 263 */       if (LA(1) == '\n') {
/* 264 */         match('\n');
/* 265 */         newline(); continue;
/*     */       } 
/* 267 */       if (_tokenSet_2.member(LA(1))) {
/* 268 */         matchNot('*');
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*     */       break;
/*     */     } 
/*     */     
/* 276 */     match("*/");
/* 277 */     b = -1;
/* 278 */     if (paramBoolean && token == null && b != -1) {
/* 279 */       token = makeToken(b);
/* 280 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 282 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   public final void mLPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 286 */     Token token = null; int i = this.text.length();
/* 287 */     byte b = 7;
/*     */ 
/*     */     
/* 290 */     match('(');
/* 291 */     if (paramBoolean && token == null && b != -1) {
/* 292 */       token = makeToken(b);
/* 293 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 295 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   public final void mRPAREN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 299 */     Token token = null; int i = this.text.length();
/* 300 */     byte b = 8;
/*     */ 
/*     */     
/* 303 */     match(')');
/* 304 */     if (paramBoolean && token == null && b != -1) {
/* 305 */       token = makeToken(b);
/* 306 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 308 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   public final void mASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 312 */     Token token = null; int i = this.text.length();
/* 313 */     byte b = 6;
/*     */ 
/*     */     
/* 316 */     match('=');
/* 317 */     if (paramBoolean && token == null && b != -1) {
/* 318 */       token = makeToken(b);
/* 319 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 321 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   public final void mSTRING(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 325 */     Token token = null; int i = this.text.length();
/* 326 */     byte b = 5;
/*     */ 
/*     */     
/* 329 */     match('"');
/*     */ 
/*     */     
/*     */     while (true) {
/* 333 */       while (LA(1) == '\\') {
/* 334 */         mESC(false);
/*     */       }
/* 336 */       if (_tokenSet_3.member(LA(1))) {
/* 337 */         matchNot('"');
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*     */       break;
/*     */     } 
/*     */     
/* 345 */     match('"');
/* 346 */     if (paramBoolean && token == null && b != -1) {
/* 347 */       token = makeToken(b);
/* 348 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 350 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   protected final void mESC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 354 */     Token token = null; int i = this.text.length();
/* 355 */     byte b = 13;
/*     */ 
/*     */     
/* 358 */     match('\\');
/*     */     
/* 360 */     switch (LA(1)) {
/*     */       
/*     */       case 'n':
/* 363 */         match('n');
/*     */         break;
/*     */ 
/*     */       
/*     */       case 'r':
/* 368 */         match('r');
/*     */         break;
/*     */ 
/*     */       
/*     */       case 't':
/* 373 */         match('t');
/*     */         break;
/*     */ 
/*     */       
/*     */       case 'b':
/* 378 */         match('b');
/*     */         break;
/*     */ 
/*     */       
/*     */       case 'f':
/* 383 */         match('f');
/*     */         break;
/*     */ 
/*     */       
/*     */       case '"':
/* 388 */         match('"');
/*     */         break;
/*     */ 
/*     */       
/*     */       case '\'':
/* 393 */         match('\'');
/*     */         break;
/*     */ 
/*     */       
/*     */       case '\\':
/* 398 */         match('\\');
/*     */         break;
/*     */       case '0':
/*     */       case '1':
/*     */       case '2':
/*     */       case '3':
/* 404 */         matchRange('0', '3');
/*     */ 
/*     */         
/* 407 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 408 */           mDIGIT(false);
/*     */           
/* 410 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 411 */             mDIGIT(false); break;
/*     */           } 
/* 413 */           if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*     */             break;
/*     */           }
/* 416 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 421 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*     */           break;
/*     */         }
/* 424 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case '4':
/*     */       case '5':
/*     */       case '6':
/*     */       case '7':
/* 433 */         matchRange('4', '7');
/*     */ 
/*     */         
/* 436 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 437 */           mDIGIT(false); break;
/*     */         } 
/* 439 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*     */           break;
/*     */         }
/* 442 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 'u':
/* 450 */         match('u');
/* 451 */         mXDIGIT(false);
/* 452 */         mXDIGIT(false);
/* 453 */         mXDIGIT(false);
/* 454 */         mXDIGIT(false);
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 459 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */     } 
/*     */ 
/*     */     
/* 463 */     if (paramBoolean && token == null && b != -1) {
/* 464 */       token = makeToken(b);
/* 465 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 467 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   protected final void mDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 471 */     Token token = null; int i = this.text.length();
/* 472 */     byte b = 14;
/*     */ 
/*     */     
/* 475 */     matchRange('0', '9');
/* 476 */     if (paramBoolean && token == null && b != -1) {
/* 477 */       token = makeToken(b);
/* 478 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 480 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   protected final void mXDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 484 */     Token token = null; int i = this.text.length();
/* 485 */     byte b = 15;
/*     */ 
/*     */     
/* 488 */     switch (LA(1)) { case '0': case '1': case '2': case '3': case '4': case '5':
/*     */       case '6':
/*     */       case '7':
/*     */       case '8':
/*     */       case '9':
/* 493 */         matchRange('0', '9'); break;
/*     */       case 'a': case 'b':
/*     */       case 'c':
/*     */       case 'd':
/*     */       case 'e':
/*     */       case 'f':
/* 499 */         matchRange('a', 'f'); break;
/*     */       case 'A': case 'B':
/*     */       case 'C':
/*     */       case 'D':
/*     */       case 'E':
/*     */       case 'F':
/* 505 */         matchRange('A', 'F');
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 510 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*     */ 
/*     */     
/* 513 */     if (paramBoolean && token == null && b != -1) {
/* 514 */       token = makeToken(b);
/* 515 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 517 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   public final void mID(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 521 */     Token token = null; int i = this.text.length();
/* 522 */     byte b = 4;
/*     */ 
/*     */ 
/*     */     
/* 526 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*     */       case 's':
/*     */       case 't':
/*     */       case 'u':
/*     */       case 'v':
/*     */       case 'w':
/*     */       case 'x':
/*     */       case 'y':
/*     */       case 'z':
/* 535 */         matchRange('a', 'z'); break;
/*     */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*     */       case 'R':
/*     */       case 'S':
/*     */       case 'T':
/*     */       case 'U':
/*     */       case 'V':
/*     */       case 'W':
/*     */       case 'X':
/*     */       case 'Y':
/*     */       case 'Z':
/* 546 */         matchRange('A', 'Z');
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 551 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 558 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*     */         case 's':
/*     */         case 't':
/*     */         case 'u':
/*     */         case 'v':
/*     */         case 'w':
/*     */         case 'x':
/*     */         case 'y':
/*     */         case 'z':
/* 567 */           matchRange('a', 'z'); continue;
/*     */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*     */         case 'R':
/*     */         case 'S':
/*     */         case 'T':
/*     */         case 'U':
/*     */         case 'V':
/*     */         case 'W':
/*     */         case 'X':
/*     */         case 'Y':
/*     */         case 'Z':
/* 578 */           matchRange('A', 'Z');
/*     */           continue;
/*     */ 
/*     */         
/*     */         case '_':
/* 583 */           match('_'); continue;
/*     */         case '0': case '1': case '2': case '3': case '4':
/*     */         case '5':
/*     */         case '6':
/*     */         case '7':
/*     */         case '8':
/*     */         case '9':
/* 590 */           matchRange('0', '9');
/*     */           continue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       break;
/*     */     } 
/* 600 */     if (paramBoolean && token == null && b != -1) {
/* 601 */       token = makeToken(b);
/* 602 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 604 */     this._returnToken = token;
/*     */   }
/*     */   
/*     */   public final void mINT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 608 */     Token token = null; int i = this.text.length();
/* 609 */     byte b1 = 9;
/*     */ 
/*     */ 
/*     */     
/* 613 */     byte b2 = 0;
/*     */     
/*     */     while (true) {
/* 616 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 617 */         mDIGIT(false);
/*     */       } else {
/*     */         
/* 620 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*     */       } 
/*     */       
/* 623 */       b2++;
/*     */     } 
/*     */     
/* 626 */     if (paramBoolean && token == null && b1 != -1) {
/* 627 */       token = makeToken(b1);
/* 628 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*     */     } 
/* 630 */     this._returnToken = token;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final long[] mk_tokenSet_0() {
/* 635 */     long[] arrayOfLong = new long[8];
/* 636 */     arrayOfLong[0] = -9224L;
/* 637 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 638 */      return arrayOfLong;
/*     */   }
/* 640 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*     */   private static final long[] mk_tokenSet_1() {
/* 642 */     long[] arrayOfLong = new long[8];
/* 643 */     arrayOfLong[0] = -140737488355336L;
/* 644 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 645 */      return arrayOfLong;
/*     */   }
/* 647 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*     */   private static final long[] mk_tokenSet_2() {
/* 649 */     long[] arrayOfLong = new long[8];
/* 650 */     arrayOfLong[0] = -4398046512136L;
/* 651 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 652 */      return arrayOfLong;
/*     */   }
/* 654 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*     */   private static final long[] mk_tokenSet_3() {
/* 656 */     long[] arrayOfLong = new long[8];
/* 657 */     arrayOfLong[0] = -17179869192L;
/* 658 */     arrayOfLong[1] = -268435457L;
/* 659 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 660 */      return arrayOfLong;
/*     */   }
/* 662 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ANTLRTokdefLexer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */