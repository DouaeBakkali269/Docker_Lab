package antlr.debug;

public interface InputBufferListener extends ListenerBase {
  void inputBufferConsume(InputBufferEvent paramInputBufferEvent);
  
  void inputBufferLA(InputBufferEvent paramInputBufferEvent);
  
  void inputBufferMark(InputBufferEvent paramInputBufferEvent);
  
  void inputBufferRewind(InputBufferEvent paramInputBufferEvent);
}


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\InputBufferListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */