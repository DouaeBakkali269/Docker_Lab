package antlr.debug;

public interface ParserListener extends SemanticPredicateListener, ParserMatchListener, MessageListener, ParserTokenListener, TraceListener, SyntacticPredicateListener {}


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\ParserListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */