/*    */ package antlr.debug.misc;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ import java.util.NoSuchElementException;
/*    */ import javax.swing.event.TreeModelListener;
/*    */ import javax.swing.tree.TreeModel;
/*    */ import javax.swing.tree.TreePath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JTreeASTModel
/*    */   implements TreeModel
/*    */ {
/* 18 */   AST root = null;
/*    */   
/*    */   public JTreeASTModel(AST paramAST) {
/* 21 */     if (paramAST == null) {
/* 22 */       throw new IllegalArgumentException("root is null");
/*    */     }
/* 24 */     this.root = paramAST;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addTreeModelListener(TreeModelListener paramTreeModelListener) {}
/*    */   
/*    */   public Object getChild(Object paramObject, int paramInt) {
/* 31 */     if (paramObject == null) {
/* 32 */       return null;
/*    */     }
/* 34 */     AST aST1 = (AST)paramObject;
/* 35 */     AST aST2 = aST1.getFirstChild();
/* 36 */     if (aST2 == null) {
/* 37 */       throw new ArrayIndexOutOfBoundsException("node has no children");
/*    */     }
/* 39 */     byte b = 0;
/* 40 */     while (aST2 != null && b < paramInt) {
/* 41 */       aST2 = aST2.getNextSibling();
/* 42 */       b++;
/*    */     } 
/* 44 */     return aST2;
/*    */   }
/*    */   
/*    */   public int getChildCount(Object paramObject) {
/* 48 */     if (paramObject == null) {
/* 49 */       throw new IllegalArgumentException("root is null");
/*    */     }
/* 51 */     AST aST1 = (AST)paramObject;
/* 52 */     AST aST2 = aST1.getFirstChild();
/* 53 */     byte b = 0;
/* 54 */     while (aST2 != null) {
/* 55 */       aST2 = aST2.getNextSibling();
/* 56 */       b++;
/*    */     } 
/* 58 */     return b;
/*    */   }
/*    */   
/*    */   public int getIndexOfChild(Object paramObject1, Object paramObject2) {
/* 62 */     if (paramObject1 == null || paramObject2 == null) {
/* 63 */       throw new IllegalArgumentException("root or child is null");
/*    */     }
/* 65 */     AST aST1 = (AST)paramObject1;
/* 66 */     AST aST2 = aST1.getFirstChild();
/* 67 */     if (aST2 == null) {
/* 68 */       throw new ArrayIndexOutOfBoundsException("node has no children");
/*    */     }
/* 70 */     byte b = 0;
/* 71 */     while (aST2 != null && aST2 != paramObject2) {
/* 72 */       aST2 = aST2.getNextSibling();
/* 73 */       b++;
/*    */     } 
/* 75 */     if (aST2 == paramObject2) {
/* 76 */       return b;
/*    */     }
/* 78 */     throw new NoSuchElementException("node is not a child");
/*    */   }
/*    */   
/*    */   public Object getRoot() {
/* 82 */     return this.root;
/*    */   }
/*    */   
/*    */   public boolean isLeaf(Object paramObject) {
/* 86 */     if (paramObject == null) {
/* 87 */       throw new IllegalArgumentException("node is null");
/*    */     }
/* 89 */     AST aST = (AST)paramObject;
/* 90 */     return (aST.getFirstChild() == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeTreeModelListener(TreeModelListener paramTreeModelListener) {}
/*    */   
/*    */   public void valueForPathChanged(TreePath paramTreePath, Object paramObject) {
/* 97 */     System.out.println("heh, who is calling this mystery method?");
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\misc\JTreeASTModel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */