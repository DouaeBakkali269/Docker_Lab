/*    */ package antlr.debug;
/*    */ 
/*    */ public class SyntacticPredicateEvent
/*    */   extends GuessingEvent
/*    */ {
/*    */   public SyntacticPredicateEvent(Object paramObject) {
/*  7 */     super(paramObject);
/*    */   }
/*    */   public SyntacticPredicateEvent(Object paramObject, int paramInt) {
/* 10 */     super(paramObject, paramInt);
/*    */   }
/*    */   
/*    */   void setValues(int paramInt1, int paramInt2) {
/* 14 */     super.setValues(paramInt1, paramInt2);
/*    */   }
/*    */   public String toString() {
/* 17 */     return "SyntacticPredicateEvent [" + getGuessing() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\SyntacticPredicateEvent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */