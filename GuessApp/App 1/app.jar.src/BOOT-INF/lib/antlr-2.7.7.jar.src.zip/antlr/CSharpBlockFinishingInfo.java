/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CSharpBlockFinishingInfo
/*    */ {
/*    */   String postscript;
/*    */   boolean generatedSwitch;
/*    */   boolean generatedAnIf;
/*    */   boolean needAnErrorClause;
/*    */   
/*    */   public CSharpBlockFinishingInfo() {
/* 29 */     this.postscript = null;
/* 30 */     this.generatedSwitch = false;
/* 31 */     this.needAnErrorClause = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public CSharpBlockFinishingInfo(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 36 */     this.postscript = paramString;
/* 37 */     this.generatedSwitch = paramBoolean1;
/* 38 */     this.generatedAnIf = paramBoolean2;
/* 39 */     this.needAnErrorClause = paramBoolean3;
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\CSharpBlockFinishingInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */