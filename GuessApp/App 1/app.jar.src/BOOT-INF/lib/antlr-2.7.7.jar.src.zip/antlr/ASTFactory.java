/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.AST;
/*     */ import antlr.collections.impl.ASTArray;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTFactory
/*     */ {
/*  32 */   protected String theASTNodeType = null;
/*  33 */   protected Class theASTNodeTypeClass = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   protected Hashtable tokenTypeToASTClassMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTFactory(Hashtable paramHashtable) {
/*  61 */     setTokenTypeToASTClassMap(paramHashtable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTokenTypeASTNodeType(int paramInt, String paramString) throws IllegalArgumentException {
/*  83 */     if (this.tokenTypeToASTClassMap == null) {
/*  84 */       this.tokenTypeToASTClassMap = new Hashtable();
/*     */     }
/*  86 */     if (paramString == null) {
/*  87 */       this.tokenTypeToASTClassMap.remove(new Integer(paramInt));
/*     */       return;
/*     */     } 
/*  90 */     Class clazz = null;
/*     */     try {
/*  92 */       clazz = Utils.loadClass(paramString);
/*  93 */       this.tokenTypeToASTClassMap.put(new Integer(paramInt), clazz);
/*     */     }
/*  95 */     catch (Exception exception) {
/*  96 */       throw new IllegalArgumentException("Invalid class, " + paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getASTNodeType(int paramInt) {
/* 106 */     if (this.tokenTypeToASTClassMap != null) {
/* 107 */       Class clazz = (Class)this.tokenTypeToASTClassMap.get(new Integer(paramInt));
/* 108 */       if (clazz != null) {
/* 109 */         return clazz;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 114 */     if (this.theASTNodeTypeClass != null) {
/* 115 */       return this.theASTNodeTypeClass;
/*     */     }
/*     */ 
/*     */     
/* 119 */     return CommonAST.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addASTChild(ASTPair paramASTPair, AST paramAST) {
/* 124 */     if (paramAST != null) {
/* 125 */       if (paramASTPair.root == null) {
/*     */         
/* 127 */         paramASTPair.root = paramAST;
/*     */       
/*     */       }
/* 130 */       else if (paramASTPair.child == null) {
/*     */         
/* 132 */         paramASTPair.root.setFirstChild(paramAST);
/*     */       } else {
/*     */         
/* 135 */         paramASTPair.child.setNextSibling(paramAST);
/*     */       } 
/*     */ 
/*     */       
/* 139 */       paramASTPair.child = paramAST;
/* 140 */       paramASTPair.advanceChildToEnd();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST create() {
/* 148 */     return create(0);
/*     */   }
/*     */   
/*     */   public AST create(int paramInt) {
/* 152 */     Class clazz = getASTNodeType(paramInt);
/* 153 */     AST aST = create(clazz);
/* 154 */     if (aST != null) {
/* 155 */       aST.initialize(paramInt, "");
/*     */     }
/* 157 */     return aST;
/*     */   }
/*     */   
/*     */   public AST create(int paramInt, String paramString) {
/* 161 */     AST aST = create(paramInt);
/* 162 */     if (aST != null) {
/* 163 */       aST.initialize(paramInt, paramString);
/*     */     }
/* 165 */     return aST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST create(int paramInt, String paramString1, String paramString2) {
/* 174 */     AST aST = create(paramString2);
/* 175 */     if (aST != null) {
/* 176 */       aST.initialize(paramInt, paramString1);
/*     */     }
/* 178 */     return aST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST create(AST paramAST) {
/* 185 */     if (paramAST == null) return null; 
/* 186 */     AST aST = create(paramAST.getType());
/* 187 */     if (aST != null) {
/* 188 */       aST.initialize(paramAST);
/*     */     }
/* 190 */     return aST;
/*     */   }
/*     */   
/*     */   public AST create(Token paramToken) {
/* 194 */     AST aST = create(paramToken.getType());
/* 195 */     if (aST != null) {
/* 196 */       aST.initialize(paramToken);
/*     */     }
/* 198 */     return aST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST create(Token paramToken, String paramString) {
/* 210 */     return createUsingCtor(paramToken, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST create(String paramString) {
/* 218 */     Class clazz = null;
/*     */     try {
/* 220 */       clazz = Utils.loadClass(paramString);
/*     */     }
/* 222 */     catch (Exception exception) {
/* 223 */       throw new IllegalArgumentException("Invalid class, " + paramString);
/*     */     } 
/* 225 */     return create(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AST createUsingCtor(Token paramToken, String paramString) {
/* 232 */     Class clazz = null;
/* 233 */     AST aST = null;
/*     */     try {
/* 235 */       clazz = Utils.loadClass(paramString);
/* 236 */       Class[] arrayOfClass = { Token.class };
/*     */       try {
/* 238 */         Constructor constructor = clazz.getConstructor(arrayOfClass);
/* 239 */         aST = constructor.newInstance(new Object[] { paramToken });
/*     */       }
/* 241 */       catch (NoSuchMethodException noSuchMethodException) {
/*     */ 
/*     */         
/* 244 */         aST = create(clazz);
/* 245 */         if (aST != null) {
/* 246 */           aST.initialize(paramToken);
/*     */         }
/*     */       }
/*     */     
/* 250 */     } catch (Exception exception) {
/* 251 */       throw new IllegalArgumentException("Invalid class or can't make instance, " + paramString);
/*     */     } 
/* 253 */     return aST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AST create(Class paramClass) {
/* 260 */     AST aST = null;
/*     */     try {
/* 262 */       aST = paramClass.newInstance();
/*     */     }
/* 264 */     catch (Exception exception) {
/* 265 */       error("Can't create AST Node " + paramClass.getName());
/* 266 */       return null;
/*     */     } 
/* 268 */     return aST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST dup(AST paramAST) {
/* 280 */     if (paramAST == null) {
/* 281 */       return null;
/*     */     }
/* 283 */     AST aST = create(paramAST.getClass());
/* 284 */     aST.initialize(paramAST);
/* 285 */     return aST;
/*     */   }
/*     */ 
/*     */   
/*     */   public AST dupList(AST paramAST) {
/* 290 */     AST aST1 = dupTree(paramAST);
/* 291 */     AST aST2 = aST1;
/* 292 */     while (paramAST != null) {
/* 293 */       paramAST = paramAST.getNextSibling();
/* 294 */       aST2.setNextSibling(dupTree(paramAST));
/* 295 */       aST2 = aST2.getNextSibling();
/*     */     } 
/* 297 */     return aST1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST dupTree(AST paramAST) {
/* 304 */     AST aST = dup(paramAST);
/*     */     
/* 306 */     if (paramAST != null) {
/* 307 */       aST.setFirstChild(dupList(paramAST.getFirstChild()));
/*     */     }
/* 309 */     return aST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST make(AST[] paramArrayOfAST) {
/* 319 */     if (paramArrayOfAST == null || paramArrayOfAST.length == 0) return null; 
/* 320 */     AST aST1 = paramArrayOfAST[0];
/* 321 */     AST aST2 = null;
/* 322 */     if (aST1 != null) {
/* 323 */       aST1.setFirstChild(null);
/*     */     }
/*     */     
/* 326 */     for (byte b = 1; b < paramArrayOfAST.length; b++) {
/* 327 */       if (paramArrayOfAST[b] != null) {
/* 328 */         if (aST1 == null) {
/*     */           
/* 330 */           aST1 = aST2 = paramArrayOfAST[b];
/*     */         }
/* 332 */         else if (aST2 == null) {
/* 333 */           aST1.setFirstChild(paramArrayOfAST[b]);
/* 334 */           aST2 = aST1.getFirstChild();
/*     */         } else {
/*     */           
/* 337 */           aST2.setNextSibling(paramArrayOfAST[b]);
/* 338 */           aST2 = aST2.getNextSibling();
/*     */         } 
/*     */         
/* 341 */         while (aST2.getNextSibling() != null)
/* 342 */           aST2 = aST2.getNextSibling(); 
/*     */       } 
/*     */     } 
/* 345 */     return aST1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AST make(ASTArray paramASTArray) {
/* 352 */     return make(paramASTArray.array);
/*     */   }
/*     */ 
/*     */   
/*     */   public void makeASTRoot(ASTPair paramASTPair, AST paramAST) {
/* 357 */     if (paramAST != null) {
/*     */       
/* 359 */       paramAST.addChild(paramASTPair.root);
/*     */       
/* 361 */       paramASTPair.child = paramASTPair.root;
/* 362 */       paramASTPair.advanceChildToEnd();
/*     */       
/* 364 */       paramASTPair.root = paramAST;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setASTNodeClass(Class paramClass) {
/* 369 */     if (paramClass != null) {
/* 370 */       this.theASTNodeTypeClass = paramClass;
/* 371 */       this.theASTNodeType = paramClass.getName();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setASTNodeClass(String paramString) {
/* 376 */     this.theASTNodeType = paramString;
/*     */     try {
/* 378 */       this.theASTNodeTypeClass = Utils.loadClass(paramString);
/*     */     }
/* 380 */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */       
/* 384 */       error("Can't find/access AST Node type" + paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setASTNodeType(String paramString) {
/* 392 */     setASTNodeClass(paramString);
/*     */   }
/*     */   
/*     */   public Hashtable getTokenTypeToASTClassMap() {
/* 396 */     return this.tokenTypeToASTClassMap;
/*     */   }
/*     */   
/*     */   public void setTokenTypeToASTClassMap(Hashtable paramHashtable) {
/* 400 */     this.tokenTypeToASTClassMap = paramHashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String paramString) {
/* 408 */     System.err.println(paramString);
/*     */   }
/*     */   
/*     */   public ASTFactory() {}
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ASTFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */