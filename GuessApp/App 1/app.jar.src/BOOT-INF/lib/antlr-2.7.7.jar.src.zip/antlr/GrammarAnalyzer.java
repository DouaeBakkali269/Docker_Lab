package antlr;

public interface GrammarAnalyzer {
  public static final int NONDETERMINISTIC = 2147483647;
  
  public static final int LOOKAHEAD_DEPTH_INIT = -1;
}


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\GrammarAnalyzer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */