/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OneOrMoreBlock
/*    */   extends BlockWithImpliedExitPath
/*    */ {
/*    */   public OneOrMoreBlock(Grammar paramGrammar) {
/* 13 */     super(paramGrammar);
/*    */   }
/*    */   
/*    */   public OneOrMoreBlock(Grammar paramGrammar, Token paramToken) {
/* 17 */     super(paramGrammar, paramToken);
/*    */   }
/*    */   
/*    */   public void generate() {
/* 21 */     this.grammar.generator.gen(this);
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 25 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 29 */     return super.toString() + "+";
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\OneOrMoreBlock.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */