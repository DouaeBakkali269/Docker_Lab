/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeParserSharedInputState
/*    */ {
/* 18 */   public int guessing = 0;
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\TreeParserSharedInputState.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */