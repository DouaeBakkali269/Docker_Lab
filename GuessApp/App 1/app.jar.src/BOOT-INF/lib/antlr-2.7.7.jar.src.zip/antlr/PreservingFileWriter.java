/*     */ package antlr;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreservingFileWriter
/*     */   extends FileWriter
/*     */ {
/*     */   protected File target_file;
/*     */   protected File tmp_file;
/*     */   
/*     */   public PreservingFileWriter(String paramString) throws IOException {
/*  24 */     super(paramString + ".antlr.tmp");
/*     */ 
/*     */     
/*  27 */     this.target_file = new File(paramString);
/*     */     
/*  29 */     String str = this.target_file.getParent();
/*  30 */     if (str != null) {
/*     */       
/*  32 */       File file = new File(str);
/*     */       
/*  34 */       if (!file.exists())
/*  35 */         throw new IOException("destination directory of '" + paramString + "' doesn't exist"); 
/*  36 */       if (!file.canWrite())
/*  37 */         throw new IOException("destination directory of '" + paramString + "' isn't writeable"); 
/*     */     } 
/*  39 */     if (this.target_file.exists() && !this.target_file.canWrite()) {
/*  40 */       throw new IOException("cannot write to '" + paramString + "'");
/*     */     }
/*     */     
/*  43 */     this.tmp_file = new File(paramString + ".antlr.tmp");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  56 */     BufferedReader bufferedReader = null;
/*  57 */     BufferedWriter bufferedWriter = null;
/*     */ 
/*     */     
/*     */     try {
/*  61 */       super.close();
/*     */       
/*  63 */       char[] arrayOfChar = new char[1024];
/*     */ 
/*     */ 
/*     */       
/*  67 */       if (this.target_file.length() == this.tmp_file.length()) {
/*     */ 
/*     */ 
/*     */         
/*  71 */         char[] arrayOfChar1 = new char[1024];
/*     */         
/*  73 */         bufferedReader = new BufferedReader(new FileReader(this.tmp_file));
/*  74 */         BufferedReader bufferedReader1 = new BufferedReader(new FileReader(this.target_file));
/*     */         
/*  76 */         boolean bool = true;
/*     */         
/*  78 */         while (bool) {
/*     */           
/*  80 */           int i = bufferedReader.read(arrayOfChar, 0, 1024);
/*  81 */           int j = bufferedReader1.read(arrayOfChar1, 0, 1024);
/*  82 */           if (i != j) {
/*     */             
/*  84 */             bool = false;
/*     */             break;
/*     */           } 
/*  87 */           if (i == -1)
/*     */             break; 
/*  89 */           for (byte b = 0; b < i; b++) {
/*     */             
/*  91 */             if (arrayOfChar[b] != arrayOfChar1[b]) {
/*     */               
/*  93 */               bool = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*  99 */         bufferedReader.close();
/* 100 */         bufferedReader1.close();
/*     */         
/* 102 */         bufferedReader = bufferedReader1 = null;
/*     */         
/* 104 */         if (bool) {
/*     */           return;
/*     */         }
/*     */       } 
/* 108 */       bufferedReader = new BufferedReader(new FileReader(this.tmp_file));
/* 109 */       bufferedWriter = new BufferedWriter(new FileWriter(this.target_file));
/*     */ 
/*     */       
/*     */       while (true) {
/* 113 */         int i = bufferedReader.read(arrayOfChar, 0, 1024);
/* 114 */         if (i == -1)
/*     */           break; 
/* 116 */         bufferedWriter.write(arrayOfChar, 0, i);
/*     */       } 
/*     */     } finally {
/*     */       
/* 120 */       if (bufferedReader != null) {
/*     */         try {
/* 122 */           bufferedReader.close();
/* 123 */         } catch (IOException iOException) {}
/*     */       }
/* 125 */       if (bufferedWriter != null) {
/*     */         try {
/* 127 */           bufferedWriter.close();
/* 128 */         } catch (IOException iOException) {}
/*     */       }
/*     */       
/* 131 */       if (this.tmp_file != null && this.tmp_file.exists()) {
/*     */         
/* 133 */         this.tmp_file.delete();
/* 134 */         this.tmp_file = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\PreservingFileWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */