/*    */ package antlr;
/*    */ 
/*    */ import antlr.collections.impl.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExceptionSpec
/*    */ {
/*    */   protected Token label;
/*    */   protected Vector handlers;
/*    */   
/*    */   public ExceptionSpec(Token paramToken) {
/* 22 */     this.label = paramToken;
/* 23 */     this.handlers = new Vector();
/*    */   }
/*    */   
/*    */   public void addHandler(ExceptionHandler paramExceptionHandler) {
/* 27 */     this.handlers.appendElement(paramExceptionHandler);
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ExceptionSpec.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */