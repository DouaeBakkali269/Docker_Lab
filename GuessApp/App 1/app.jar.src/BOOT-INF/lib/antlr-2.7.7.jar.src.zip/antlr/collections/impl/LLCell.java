/*    */ package antlr.collections.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LLCell
/*    */ {
/*    */   Object data;
/*    */   LLCell next;
/*    */   
/*    */   public LLCell(Object paramObject) {
/* 23 */     this.data = paramObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\impl\LLCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */