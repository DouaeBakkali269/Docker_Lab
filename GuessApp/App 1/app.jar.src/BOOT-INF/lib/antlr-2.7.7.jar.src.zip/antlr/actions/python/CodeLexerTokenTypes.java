package antlr.actions.python;

public interface CodeLexerTokenTypes {
  public static final int EOF = 1;
  
  public static final int NULL_TREE_LOOKAHEAD = 3;
  
  public static final int ACTION = 4;
  
  public static final int STUFF = 5;
  
  public static final int COMMENT = 6;
  
  public static final int SL_COMMENT = 7;
  
  public static final int IGNWS = 8;
  
  public static final int ML_COMMENT = 9;
}


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\actions\python\CodeLexerTokenTypes.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */