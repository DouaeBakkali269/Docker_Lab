/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class GrammarSymbol
/*    */ {
/*    */   protected String id;
/*    */   
/*    */   public GrammarSymbol() {}
/*    */   
/*    */   public GrammarSymbol(String paramString) {
/* 20 */     this.id = paramString;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 24 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(String paramString) {
/* 28 */     this.id = paramString;
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\GrammarSymbol.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */