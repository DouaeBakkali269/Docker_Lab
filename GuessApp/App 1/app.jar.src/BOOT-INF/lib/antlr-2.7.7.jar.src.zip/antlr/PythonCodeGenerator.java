/*      */ package antlr;
/*      */ 
/*      */ import antlr.actions.python.ActionLexer;
/*      */ import antlr.actions.python.CodeLexer;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PythonCodeGenerator
/*      */   extends CodeGenerator
/*      */ {
/*   22 */   protected int syntacticPredLevel = 0;
/*      */   
/*      */   protected boolean genAST = false;
/*      */   
/*      */   protected boolean saveText = false;
/*      */   
/*      */   String labeledElementType;
/*      */   
/*      */   String labeledElementASTType;
/*      */   
/*      */   String labeledElementInit;
/*      */   
/*      */   String commonExtraArgs;
/*      */   
/*      */   String commonExtraParams;
/*      */   
/*      */   String commonLocalVars;
/*      */   
/*      */   String lt1Value;
/*      */   
/*      */   String exceptionThrown;
/*      */   
/*      */   String throwNoViable;
/*      */   
/*      */   public static final String initHeaderAction = "__init__";
/*      */   
/*      */   public static final String mainHeaderAction = "__main__";
/*      */   
/*      */   String lexerClassName;
/*      */   
/*      */   String parserClassName;
/*      */   
/*      */   String treeWalkerClassName;
/*      */   
/*      */   RuleBlock currentRule;
/*      */   
/*      */   String currentASTResult;
/*   59 */   Hashtable treeVariableMap = new Hashtable();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   64 */   Hashtable declaredASTVariables = new Hashtable();
/*      */ 
/*      */   
/*   67 */   int astVarNumber = 1;
/*      */ 
/*      */   
/*   70 */   protected static final String NONUNIQUE = new String();
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int caseSizeThreshold = 127;
/*      */ 
/*      */ 
/*      */   
/*      */   private Vector semPreds;
/*      */ 
/*      */ 
/*      */   
/*      */   protected void printTabs() {
/*   83 */     for (byte b = 0; b < this.tabs; b++)
/*      */     {
/*   85 */       this.currentOutput.print("    ");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public PythonCodeGenerator() {
/*   91 */     this.charFormatter = new PythonCharFormatter();
/*   92 */     this.DEBUG_CODE_GENERATOR = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int addSemPred(String paramString) {
/*  101 */     this.semPreds.appendElement(paramString);
/*  102 */     return this.semPreds.size() - 1;
/*      */   }
/*      */   
/*      */   public void exitIfError() {
/*  106 */     if (this.antlrTool.hasError()) {
/*  107 */       this.antlrTool.fatalError("Exiting due to errors.");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void checkCurrentOutputStream() {
/*      */     try {
/*  114 */       if (this.currentOutput == null) {
/*  115 */         throw new NullPointerException();
/*      */       }
/*  117 */     } catch (Exception exception) {
/*      */       
/*  119 */       Utils.error("current output is not set");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String extractIdOfAction(String paramString, int paramInt1, int paramInt2) {
/*  132 */     paramString = removeAssignmentFromDeclaration(paramString);
/*      */ 
/*      */     
/*  135 */     paramString = paramString.trim();
/*      */     
/*  137 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String extractTypeOfAction(String paramString, int paramInt1, int paramInt2) {
/*  149 */     return "";
/*      */   }
/*      */ 
/*      */   
/*      */   protected void flushTokens() {
/*      */     try {
/*  155 */       boolean bool = false;
/*      */       
/*  157 */       checkCurrentOutputStream();
/*      */       
/*  159 */       println("");
/*  160 */       println("### import antlr.Token ");
/*  161 */       println("from antlr import Token");
/*  162 */       println("### >>>The Known Token Types <<<");
/*      */ 
/*      */ 
/*      */       
/*  166 */       PrintWriter printWriter = this.currentOutput;
/*      */ 
/*      */       
/*  169 */       Enumeration enumeration = this.behavior.tokenManagers.elements();
/*      */ 
/*      */       
/*  172 */       while (enumeration.hasMoreElements())
/*      */       {
/*  174 */         TokenManager tokenManager = enumeration.nextElement();
/*      */ 
/*      */         
/*  177 */         if (!tokenManager.isReadOnly()) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  182 */           if (!bool) {
/*  183 */             genTokenTypes(tokenManager);
/*  184 */             bool = true;
/*      */           } 
/*      */ 
/*      */           
/*  188 */           this.currentOutput = printWriter;
/*      */ 
/*      */           
/*  191 */           genTokenInterchange(tokenManager);
/*  192 */           this.currentOutput = printWriter;
/*      */         } 
/*      */         
/*  195 */         exitIfError();
/*      */       }
/*      */     
/*  198 */     } catch (Exception exception) {
/*  199 */       exitIfError();
/*      */     } 
/*  201 */     checkCurrentOutputStream();
/*  202 */     println("");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen() {
/*      */     try {
/*  211 */       Enumeration enumeration = this.behavior.grammars.elements();
/*  212 */       while (enumeration.hasMoreElements()) {
/*  213 */         Grammar grammar = enumeration.nextElement();
/*      */         
/*  215 */         grammar.setGrammarAnalyzer(this.analyzer);
/*  216 */         grammar.setCodeGenerator(this);
/*  217 */         this.analyzer.setGrammar(grammar);
/*      */         
/*  219 */         setupGrammarParameters(grammar);
/*  220 */         grammar.generate();
/*      */ 
/*      */         
/*  223 */         exitIfError();
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  228 */     catch (IOException iOException) {
/*  229 */       this.antlrTool.reportException(iOException, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ActionElement paramActionElement) {
/*  237 */     if (paramActionElement.isSemPred) {
/*  238 */       genSemPred(paramActionElement.actionText, paramActionElement.line);
/*      */     }
/*      */     else {
/*      */       
/*  242 */       if (this.grammar.hasSyntacticPredicate) {
/*  243 */         println("if not self.inputState.guessing:");
/*  244 */         this.tabs++;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  249 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/*  250 */       String str = processActionForSpecialSymbols(paramActionElement.actionText, paramActionElement.getLine(), this.currentRule, actionTransInfo);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  255 */       if (actionTransInfo.refRuleRoot != null)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  260 */         println(actionTransInfo.refRuleRoot + " = currentAST.root");
/*      */       }
/*      */ 
/*      */       
/*  264 */       printAction(str);
/*      */       
/*  266 */       if (actionTransInfo.assignToRoot) {
/*      */         
/*  268 */         println("currentAST.root = " + actionTransInfo.refRuleRoot + "");
/*      */         
/*  270 */         println("if (" + actionTransInfo.refRuleRoot + " != None) and (" + actionTransInfo.refRuleRoot + ".getFirstChild() != None):");
/*  271 */         this.tabs++;
/*  272 */         println("currentAST.child = " + actionTransInfo.refRuleRoot + ".getFirstChild()");
/*  273 */         this.tabs--;
/*  274 */         println("else:");
/*  275 */         this.tabs++;
/*  276 */         println("currentAST.child = " + actionTransInfo.refRuleRoot);
/*  277 */         this.tabs--;
/*  278 */         println("currentAST.advanceChildToEnd()");
/*      */       } 
/*      */       
/*  281 */       if (this.grammar.hasSyntacticPredicate) {
/*  282 */         this.tabs--;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(AlternativeBlock paramAlternativeBlock) {
/*  291 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("gen(" + paramAlternativeBlock + ")"); 
/*  292 */     genBlockPreamble(paramAlternativeBlock);
/*  293 */     genBlockInitAction(paramAlternativeBlock);
/*      */ 
/*      */     
/*  296 */     String str = this.currentASTResult;
/*  297 */     if (paramAlternativeBlock.getLabel() != null) {
/*  298 */       this.currentASTResult = paramAlternativeBlock.getLabel();
/*      */     }
/*      */     
/*  301 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramAlternativeBlock);
/*      */ 
/*      */     
/*  304 */     int i = this.tabs;
/*  305 */     PythonBlockFinishingInfo pythonBlockFinishingInfo = genCommonBlock(paramAlternativeBlock, true);
/*  306 */     genBlockFinish(pythonBlockFinishingInfo, this.throwNoViable);
/*  307 */     this.tabs = i;
/*      */ 
/*      */ 
/*      */     
/*  311 */     this.currentASTResult = str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(BlockEndElement paramBlockEndElement) {
/*  320 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genRuleEnd(" + paramBlockEndElement + ")");
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(CharLiteralElement paramCharLiteralElement) {
/*  327 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genChar(" + paramCharLiteralElement + ")");
/*      */     
/*  329 */     if (paramCharLiteralElement.getLabel() != null) {
/*  330 */       println(paramCharLiteralElement.getLabel() + " = " + this.lt1Value);
/*      */     }
/*      */     
/*  333 */     boolean bool = this.saveText;
/*  334 */     this.saveText = (this.saveText && paramCharLiteralElement.getAutoGenType() == 1);
/*  335 */     genMatch(paramCharLiteralElement);
/*  336 */     this.saveText = bool;
/*      */   }
/*      */ 
/*      */   
/*      */   String toString(boolean paramBoolean) {
/*      */     String str;
/*  342 */     if (paramBoolean) {
/*  343 */       str = "True";
/*      */     } else {
/*  345 */       str = "False";
/*  346 */     }  return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(CharRangeElement paramCharRangeElement) {
/*  354 */     if (paramCharRangeElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  355 */       println(paramCharRangeElement.getLabel() + " = " + this.lt1Value);
/*      */     }
/*  357 */     boolean bool = (this.grammar instanceof LexerGrammar && (!this.saveText || paramCharRangeElement.getAutoGenType() == 3)) ? true : false;
/*      */ 
/*      */ 
/*      */     
/*  361 */     if (bool) {
/*  362 */       println("_saveIndex = self.text.length()");
/*      */     }
/*      */     
/*  365 */     println("self.matchRange(u" + paramCharRangeElement.beginText + ", u" + paramCharRangeElement.endText + ")");
/*      */     
/*  367 */     if (bool) {
/*  368 */       println("self.text.setLength(_saveIndex)");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(LexerGrammar paramLexerGrammar) throws IOException {
/*  376 */     if (paramLexerGrammar.debuggingOutput) {
/*  377 */       this.semPreds = new Vector();
/*      */     }
/*  379 */     setGrammar(paramLexerGrammar);
/*  380 */     if (!(this.grammar instanceof LexerGrammar)) {
/*  381 */       this.antlrTool.panic("Internal error generating lexer");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  386 */     setupOutput(this.grammar.getClassName());
/*      */     
/*  388 */     this.genAST = false;
/*  389 */     this.saveText = true;
/*      */     
/*  391 */     this.tabs = 0;
/*      */ 
/*      */     
/*  394 */     genHeader();
/*      */ 
/*      */     
/*  397 */     println("### import antlr and other modules ..");
/*  398 */     println("import sys");
/*  399 */     println("import antlr");
/*  400 */     println("");
/*  401 */     println("version = sys.version.split()[0]");
/*  402 */     println("if version < '2.2.1':");
/*  403 */     this.tabs++;
/*  404 */     println("False = 0");
/*  405 */     this.tabs--;
/*  406 */     println("if version < '2.3':");
/*  407 */     this.tabs++;
/*  408 */     println("True = not False");
/*  409 */     this.tabs--;
/*      */     
/*  411 */     println("### header action >>> ");
/*  412 */     printActionCode(this.behavior.getHeaderAction(""), 0);
/*  413 */     println("### header action <<< ");
/*      */ 
/*      */     
/*  416 */     println("### preamble action >>> ");
/*  417 */     printActionCode(this.grammar.preambleAction.getText(), 0);
/*  418 */     println("### preamble action <<< ");
/*      */ 
/*      */     
/*  421 */     String str1 = null;
/*  422 */     if (this.grammar.superClass != null) {
/*  423 */       str1 = this.grammar.superClass;
/*      */     } else {
/*      */       
/*  426 */       str1 = "antlr." + this.grammar.getSuperClass();
/*      */     } 
/*      */ 
/*      */     
/*  430 */     String str2 = "";
/*  431 */     Token token = (Token)this.grammar.options.get("classHeaderPrefix");
/*  432 */     if (token != null) {
/*  433 */       String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/*  434 */       if (str != null) {
/*  435 */         str2 = str;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  440 */     println("### >>>The Literals<<<");
/*  441 */     println("literals = {}");
/*  442 */     Enumeration enumeration = this.grammar.tokenManager.getTokenSymbolKeys();
/*  443 */     while (enumeration.hasMoreElements()) {
/*  444 */       String str = enumeration.nextElement();
/*  445 */       if (str.charAt(0) != '"') {
/*      */         continue;
/*      */       }
/*  448 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/*  449 */       if (tokenSymbol instanceof StringLiteralSymbol) {
/*  450 */         StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)tokenSymbol;
/*  451 */         println("literals[u" + stringLiteralSymbol.getId() + "] = " + stringLiteralSymbol.getTokenType());
/*      */       } 
/*      */     } 
/*  454 */     println("");
/*  455 */     flushTokens();
/*      */ 
/*      */     
/*  458 */     genJavadocComment(this.grammar);
/*      */ 
/*      */     
/*  461 */     println("class " + this.lexerClassName + "(" + str1 + ") :");
/*  462 */     this.tabs++;
/*      */     
/*  464 */     printGrammarAction(this.grammar);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  470 */     println("def __init__(self, *argv, **kwargs) :");
/*  471 */     this.tabs++;
/*  472 */     println(str1 + ".__init__(self, *argv, **kwargs)");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  477 */     println("self.caseSensitiveLiterals = " + toString(paramLexerGrammar.caseSensitiveLiterals));
/*  478 */     println("self.setCaseSensitive(" + toString(paramLexerGrammar.caseSensitive) + ")");
/*  479 */     println("self.literals = literals");
/*      */ 
/*      */ 
/*      */     
/*  483 */     if (this.grammar.debuggingOutput) {
/*  484 */       println("ruleNames[] = [");
/*  485 */       Enumeration enumeration2 = this.grammar.rules.elements();
/*  486 */       boolean bool = false;
/*  487 */       this.tabs++;
/*  488 */       while (enumeration2.hasMoreElements()) {
/*  489 */         GrammarSymbol grammarSymbol = enumeration2.nextElement();
/*  490 */         if (grammarSymbol instanceof RuleSymbol)
/*  491 */           println("\"" + ((RuleSymbol)grammarSymbol).getId() + "\","); 
/*      */       } 
/*  493 */       this.tabs--;
/*  494 */       println("]");
/*      */     } 
/*      */     
/*  497 */     genHeaderInit(this.grammar);
/*      */     
/*  499 */     this.tabs--;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  508 */     genNextToken();
/*  509 */     println("");
/*      */ 
/*      */     
/*  512 */     Enumeration enumeration1 = this.grammar.rules.elements();
/*  513 */     byte b = 0;
/*  514 */     while (enumeration1.hasMoreElements()) {
/*  515 */       RuleSymbol ruleSymbol = enumeration1.nextElement();
/*      */       
/*  517 */       if (!ruleSymbol.getId().equals("mnextToken")) {
/*  518 */         genRule(ruleSymbol, false, b++);
/*      */       }
/*  520 */       exitIfError();
/*      */     } 
/*      */ 
/*      */     
/*  524 */     if (this.grammar.debuggingOutput) {
/*  525 */       genSemPredMap();
/*      */     }
/*      */     
/*  528 */     genBitsets(this.bitsetsUsed, ((LexerGrammar)this.grammar).charVocabulary.size());
/*  529 */     println("");
/*      */     
/*  531 */     genHeaderMain(this.grammar);
/*      */ 
/*      */     
/*  534 */     this.currentOutput.close();
/*  535 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genHeaderMain(Grammar paramGrammar) {
/*  540 */     String str1 = paramGrammar.getClassName() + "." + "__main__";
/*  541 */     String str2 = this.behavior.getHeaderAction(str1);
/*      */     
/*  543 */     if (isEmpty(str2)) {
/*  544 */       str2 = this.behavior.getHeaderAction("__main__");
/*      */     }
/*  546 */     if (isEmpty(str2)) {
/*  547 */       if (paramGrammar instanceof LexerGrammar) {
/*  548 */         int i = this.tabs;
/*  549 */         this.tabs = 0;
/*  550 */         println("### __main__ header action >>> ");
/*  551 */         genLexerTest();
/*  552 */         this.tabs = 0;
/*  553 */         println("### __main__ header action <<< ");
/*  554 */         this.tabs = i;
/*      */       } 
/*      */     } else {
/*  557 */       int i = this.tabs;
/*  558 */       this.tabs = 0;
/*  559 */       println("");
/*  560 */       println("### __main__ header action >>> ");
/*  561 */       printMainFunc(str2);
/*  562 */       this.tabs = 0;
/*  563 */       println("### __main__ header action <<< ");
/*  564 */       this.tabs = i;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genHeaderInit(Grammar paramGrammar) {
/*  570 */     String str1 = paramGrammar.getClassName() + "." + "__init__";
/*  571 */     String str2 = this.behavior.getHeaderAction(str1);
/*      */     
/*  573 */     if (isEmpty(str2)) {
/*  574 */       str2 = this.behavior.getHeaderAction("__init__");
/*      */     }
/*  576 */     if (!isEmpty(str2)) {
/*      */ 
/*      */       
/*  579 */       int i = this.tabs;
/*  580 */       println("### __init__ header action >>> ");
/*  581 */       printActionCode(str2, 0);
/*  582 */       this.tabs = i;
/*  583 */       println("### __init__ header action <<< ");
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void printMainFunc(String paramString) {
/*  588 */     int i = this.tabs;
/*  589 */     this.tabs = 0;
/*  590 */     println("if __name__ == '__main__':");
/*  591 */     this.tabs++;
/*  592 */     printActionCode(paramString, 0);
/*  593 */     this.tabs--;
/*  594 */     this.tabs = i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(OneOrMoreBlock paramOneOrMoreBlock) {
/*      */     String str1;
/*  604 */     int i = this.tabs;
/*      */     
/*  606 */     genBlockPreamble(paramOneOrMoreBlock);
/*      */     
/*  608 */     if (paramOneOrMoreBlock.getLabel() != null) {
/*      */       
/*  610 */       str1 = "_cnt_" + paramOneOrMoreBlock.getLabel();
/*      */     } else {
/*      */       
/*  613 */       str1 = "_cnt" + paramOneOrMoreBlock.ID;
/*      */     } 
/*  615 */     println("" + str1 + "= 0");
/*  616 */     println("while True:");
/*      */     
/*  618 */     i = ++this.tabs;
/*      */ 
/*      */     
/*  621 */     genBlockInitAction(paramOneOrMoreBlock);
/*      */ 
/*      */     
/*  624 */     String str2 = this.currentASTResult;
/*  625 */     if (paramOneOrMoreBlock.getLabel() != null) {
/*  626 */       this.currentASTResult = paramOneOrMoreBlock.getLabel();
/*      */     }
/*      */     
/*  629 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramOneOrMoreBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  641 */     boolean bool1 = false;
/*  642 */     int j = this.grammar.maxk;
/*      */     
/*  644 */     if (!paramOneOrMoreBlock.greedy && paramOneOrMoreBlock.exitLookaheadDepth <= this.grammar.maxk && paramOneOrMoreBlock.exitCache[paramOneOrMoreBlock.exitLookaheadDepth].containsEpsilon()) {
/*      */ 
/*      */ 
/*      */       
/*  648 */       bool1 = true;
/*  649 */       j = paramOneOrMoreBlock.exitLookaheadDepth;
/*      */ 
/*      */     
/*      */     }
/*  653 */     else if (!paramOneOrMoreBlock.greedy && paramOneOrMoreBlock.exitLookaheadDepth == Integer.MAX_VALUE) {
/*      */       
/*  655 */       bool1 = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  661 */     if (bool1) {
/*      */       
/*  663 */       println("### nongreedy (...)+ loop; exit depth is " + paramOneOrMoreBlock.exitLookaheadDepth);
/*      */       
/*  665 */       String str = getLookaheadTestExpression(paramOneOrMoreBlock.exitCache, j);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  670 */       println("### nongreedy exit test");
/*  671 */       println("if " + str1 + " >= 1 and " + str + ":");
/*  672 */       this.tabs++;
/*  673 */       println("break");
/*  674 */       this.tabs--;
/*      */     } 
/*      */ 
/*      */     
/*  678 */     int k = this.tabs;
/*  679 */     PythonBlockFinishingInfo pythonBlockFinishingInfo = genCommonBlock(paramOneOrMoreBlock, false);
/*  680 */     genBlockFinish(pythonBlockFinishingInfo, "break");
/*  681 */     this.tabs = k;
/*      */ 
/*      */ 
/*      */     
/*  685 */     this.tabs = i;
/*  686 */     println(str1 + " += 1");
/*  687 */     this.tabs = i;
/*  688 */     this.tabs--;
/*  689 */     println("if " + str1 + " < 1:");
/*  690 */     this.tabs++;
/*  691 */     println(this.throwNoViable);
/*  692 */     this.tabs--;
/*      */     
/*  694 */     this.currentASTResult = str2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ParserGrammar paramParserGrammar) throws IOException {
/*  703 */     if (paramParserGrammar.debuggingOutput) {
/*  704 */       this.semPreds = new Vector();
/*      */     }
/*  706 */     setGrammar(paramParserGrammar);
/*  707 */     if (!(this.grammar instanceof ParserGrammar)) {
/*  708 */       this.antlrTool.panic("Internal error generating parser");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  713 */     setupOutput(this.grammar.getClassName());
/*      */     
/*  715 */     this.genAST = this.grammar.buildAST;
/*      */     
/*  717 */     this.tabs = 0;
/*      */ 
/*      */     
/*  720 */     genHeader();
/*      */ 
/*      */     
/*  723 */     println("### import antlr and other modules ..");
/*  724 */     println("import sys");
/*  725 */     println("import antlr");
/*  726 */     println("");
/*  727 */     println("version = sys.version.split()[0]");
/*  728 */     println("if version < '2.2.1':");
/*  729 */     this.tabs++;
/*  730 */     println("False = 0");
/*  731 */     this.tabs--;
/*  732 */     println("if version < '2.3':");
/*  733 */     this.tabs++;
/*  734 */     println("True = not False");
/*  735 */     this.tabs--;
/*      */     
/*  737 */     println("### header action >>> ");
/*  738 */     printActionCode(this.behavior.getHeaderAction(""), 0);
/*  739 */     println("### header action <<< ");
/*      */     
/*  741 */     println("### preamble action>>>");
/*      */     
/*  743 */     printActionCode(this.grammar.preambleAction.getText(), 0);
/*  744 */     println("### preamble action <<<");
/*      */     
/*  746 */     flushTokens();
/*      */ 
/*      */     
/*  749 */     String str1 = null;
/*  750 */     if (this.grammar.superClass != null) {
/*  751 */       str1 = this.grammar.superClass;
/*      */     } else {
/*  753 */       str1 = "antlr." + this.grammar.getSuperClass();
/*      */     } 
/*      */     
/*  756 */     genJavadocComment(this.grammar);
/*      */ 
/*      */     
/*  759 */     String str2 = "";
/*  760 */     Token token = (Token)this.grammar.options.get("classHeaderPrefix");
/*  761 */     if (token != null) {
/*  762 */       String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/*  763 */       if (str != null) {
/*  764 */         str2 = str;
/*      */       }
/*      */     } 
/*      */     
/*  768 */     print("class " + this.parserClassName + "(" + str1);
/*  769 */     println("):");
/*  770 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/*  774 */     if (this.grammar.debuggingOutput) {
/*  775 */       println("_ruleNames = [");
/*      */       
/*  777 */       Enumeration enumeration1 = this.grammar.rules.elements();
/*  778 */       boolean bool = false;
/*  779 */       this.tabs++;
/*  780 */       while (enumeration1.hasMoreElements()) {
/*  781 */         GrammarSymbol grammarSymbol = enumeration1.nextElement();
/*  782 */         if (grammarSymbol instanceof RuleSymbol)
/*  783 */           println("\"" + ((RuleSymbol)grammarSymbol).getId() + "\","); 
/*      */       } 
/*  785 */       this.tabs--;
/*  786 */       println("]");
/*      */     } 
/*      */ 
/*      */     
/*  790 */     printGrammarAction(this.grammar);
/*      */ 
/*      */     
/*  793 */     println("");
/*  794 */     println("def __init__(self, *args, **kwargs):");
/*  795 */     this.tabs++;
/*  796 */     println(str1 + ".__init__(self, *args, **kwargs)");
/*  797 */     println("self.tokenNames = _tokenNames");
/*      */ 
/*      */     
/*  800 */     if (this.grammar.debuggingOutput) {
/*  801 */       println("self.ruleNames  = _ruleNames");
/*  802 */       println("self.semPredNames = _semPredNames");
/*  803 */       println("self.setupDebugging(self.tokenBuf)");
/*      */     } 
/*  805 */     if (this.grammar.buildAST) {
/*  806 */       println("self.buildTokenTypeASTClassMap()");
/*  807 */       println("self.astFactory = antlr.ASTFactory(self.getTokenTypeToASTClassMap())");
/*  808 */       if (this.labeledElementASTType != null)
/*      */       {
/*  810 */         println("self.astFactory.setASTNodeClass(" + this.labeledElementASTType + ")");
/*      */       }
/*      */     } 
/*      */     
/*  814 */     genHeaderInit(this.grammar);
/*  815 */     println("");
/*      */ 
/*      */     
/*  818 */     Enumeration enumeration = this.grammar.rules.elements();
/*  819 */     byte b = 0;
/*  820 */     while (enumeration.hasMoreElements()) {
/*  821 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/*  822 */       if (grammarSymbol instanceof RuleSymbol) {
/*  823 */         RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/*  824 */         genRule(ruleSymbol, (ruleSymbol.references.size() == 0), b++);
/*      */       } 
/*  826 */       exitIfError();
/*      */     } 
/*      */ 
/*      */     
/*  830 */     if (this.grammar.buildAST) {
/*  831 */       genTokenASTNodeMap();
/*      */     }
/*      */ 
/*      */     
/*  835 */     genTokenStrings();
/*      */ 
/*      */     
/*  838 */     genBitsets(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType());
/*      */ 
/*      */     
/*  841 */     if (this.grammar.debuggingOutput) {
/*  842 */       genSemPredMap();
/*      */     }
/*      */     
/*  845 */     println("");
/*      */     
/*  847 */     this.tabs = 0;
/*  848 */     genHeaderMain(this.grammar);
/*      */     
/*  850 */     this.currentOutput.close();
/*  851 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(RuleRefElement paramRuleRefElement) {
/*  858 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genRR(" + paramRuleRefElement + ")"); 
/*  859 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/*  860 */     if (ruleSymbol == null || !ruleSymbol.isDefined()) {
/*      */       
/*  862 */       this.antlrTool.error("Rule '" + paramRuleRefElement.targetRule + "' is not defined", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       return;
/*      */     } 
/*  865 */     if (!(ruleSymbol instanceof RuleSymbol)) {
/*      */       
/*  867 */       this.antlrTool.error("'" + paramRuleRefElement.targetRule + "' does not name a grammar rule", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       
/*      */       return;
/*      */     } 
/*  871 */     genErrorTryForElement(paramRuleRefElement);
/*      */ 
/*      */ 
/*      */     
/*  875 */     if (this.grammar instanceof TreeWalkerGrammar && paramRuleRefElement.getLabel() != null && this.syntacticPredLevel == 0)
/*      */     {
/*      */       
/*  878 */       println(paramRuleRefElement.getLabel() + " = antlr.ifelse(_t == antlr.ASTNULL, None, " + this.lt1Value + ")");
/*      */     }
/*      */ 
/*      */     
/*  882 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramRuleRefElement.getAutoGenType() == 3)) {
/*  883 */       println("_saveIndex = self.text.length()");
/*      */     }
/*      */ 
/*      */     
/*  887 */     printTabs();
/*  888 */     if (paramRuleRefElement.idAssign != null) {
/*      */       
/*  890 */       if (ruleSymbol.block.returnAction == null) {
/*  891 */         this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' has no return type", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       }
/*  893 */       _print(paramRuleRefElement.idAssign + "=");
/*      */ 
/*      */     
/*      */     }
/*  897 */     else if (!(this.grammar instanceof LexerGrammar) && this.syntacticPredLevel == 0 && ruleSymbol.block.returnAction != null) {
/*  898 */       this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' returns a value", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  903 */     GenRuleInvocation(paramRuleRefElement);
/*      */ 
/*      */     
/*  906 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramRuleRefElement.getAutoGenType() == 3)) {
/*  907 */       println("self.text.setLength(_saveIndex)");
/*      */     }
/*      */ 
/*      */     
/*  911 */     if (this.syntacticPredLevel == 0) {
/*  912 */       boolean bool = (this.grammar.hasSyntacticPredicate && ((this.grammar.buildAST && paramRuleRefElement.getLabel() != null) || (this.genAST && paramRuleRefElement.getAutoGenType() == 1))) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  918 */       if (bool);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  923 */       if (this.grammar.buildAST && paramRuleRefElement.getLabel() != null)
/*      */       {
/*  925 */         println(paramRuleRefElement.getLabel() + "_AST = self.returnAST");
/*      */       }
/*  927 */       if (this.genAST) {
/*  928 */         switch (paramRuleRefElement.getAutoGenType()) {
/*      */           case 1:
/*  930 */             println("self.addASTChild(currentAST, self.returnAST)");
/*      */             break;
/*      */           case 2:
/*  933 */             this.antlrTool.error("Internal: encountered ^ after rule reference");
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  941 */       if (this.grammar instanceof LexerGrammar && paramRuleRefElement.getLabel() != null) {
/*  942 */         println(paramRuleRefElement.getLabel() + " = self._returnToken");
/*      */       }
/*      */       
/*  945 */       if (bool);
/*      */     } 
/*      */     
/*  948 */     genErrorCatchForElement(paramRuleRefElement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(StringLiteralElement paramStringLiteralElement) {
/*  955 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genString(" + paramStringLiteralElement + ")");
/*      */ 
/*      */     
/*  958 */     if (paramStringLiteralElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  959 */       println(paramStringLiteralElement.getLabel() + " = " + this.lt1Value + "");
/*      */     }
/*      */ 
/*      */     
/*  963 */     genElementAST(paramStringLiteralElement);
/*      */ 
/*      */     
/*  966 */     boolean bool = this.saveText;
/*  967 */     this.saveText = (this.saveText && paramStringLiteralElement.getAutoGenType() == 1);
/*      */ 
/*      */     
/*  970 */     genMatch(paramStringLiteralElement);
/*      */     
/*  972 */     this.saveText = bool;
/*      */ 
/*      */     
/*  975 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*  976 */       println("_t = _t.getNextSibling()");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TokenRangeElement paramTokenRangeElement) {
/*  984 */     genErrorTryForElement(paramTokenRangeElement);
/*  985 */     if (paramTokenRangeElement.getLabel() != null && this.syntacticPredLevel == 0) {
/*  986 */       println(paramTokenRangeElement.getLabel() + " = " + this.lt1Value);
/*      */     }
/*      */ 
/*      */     
/*  990 */     genElementAST(paramTokenRangeElement);
/*      */ 
/*      */     
/*  993 */     println("self.matchRange(u" + paramTokenRangeElement.beginText + ", u" + paramTokenRangeElement.endText + ")");
/*  994 */     genErrorCatchForElement(paramTokenRangeElement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TokenRefElement paramTokenRefElement) {
/* 1001 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genTokenRef(" + paramTokenRefElement + ")"); 
/* 1002 */     if (this.grammar instanceof LexerGrammar) {
/* 1003 */       this.antlrTool.panic("Token reference found in lexer");
/*      */     }
/* 1005 */     genErrorTryForElement(paramTokenRefElement);
/*      */     
/* 1007 */     if (paramTokenRefElement.getLabel() != null && this.syntacticPredLevel == 0) {
/* 1008 */       println(paramTokenRefElement.getLabel() + " = " + this.lt1Value + "");
/*      */     }
/*      */ 
/*      */     
/* 1012 */     genElementAST(paramTokenRefElement);
/*      */     
/* 1014 */     genMatch(paramTokenRefElement);
/* 1015 */     genErrorCatchForElement(paramTokenRefElement);
/*      */ 
/*      */     
/* 1018 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 1019 */       println("_t = _t.getNextSibling()");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void gen(TreeElement paramTreeElement) {
/* 1025 */     println("_t" + paramTreeElement.ID + " = _t");
/*      */ 
/*      */     
/* 1028 */     if (paramTreeElement.root.getLabel() != null) {
/* 1029 */       println(paramTreeElement.root.getLabel() + " = antlr.ifelse(_t == antlr.ASTNULL, None, _t)");
/*      */     }
/*      */ 
/*      */     
/* 1033 */     if (paramTreeElement.root.getAutoGenType() == 3) {
/* 1034 */       this.antlrTool.error("Suffixing a root node with '!' is not implemented", this.grammar.getFilename(), paramTreeElement.getLine(), paramTreeElement.getColumn());
/*      */       
/* 1036 */       paramTreeElement.root.setAutoGenType(1);
/*      */     } 
/* 1038 */     if (paramTreeElement.root.getAutoGenType() == 2) {
/* 1039 */       this.antlrTool.warning("Suffixing a root node with '^' is redundant; already a root", this.grammar.getFilename(), paramTreeElement.getLine(), paramTreeElement.getColumn());
/*      */       
/* 1041 */       paramTreeElement.root.setAutoGenType(1);
/*      */     } 
/*      */ 
/*      */     
/* 1045 */     genElementAST(paramTreeElement.root);
/* 1046 */     if (this.grammar.buildAST) {
/*      */       
/* 1048 */       println("_currentAST" + paramTreeElement.ID + " = currentAST.copy()");
/*      */       
/* 1050 */       println("currentAST.root = currentAST.child");
/* 1051 */       println("currentAST.child = None");
/*      */     } 
/*      */ 
/*      */     
/* 1055 */     if (paramTreeElement.root instanceof WildcardElement) {
/* 1056 */       println("if not _t: raise antlr.MismatchedTokenException()");
/*      */     } else {
/*      */       
/* 1059 */       genMatch(paramTreeElement.root);
/*      */     } 
/*      */     
/* 1062 */     println("_t = _t.getFirstChild()");
/*      */ 
/*      */     
/* 1065 */     for (byte b = 0; b < paramTreeElement.getAlternatives().size(); b++) {
/* 1066 */       Alternative alternative = paramTreeElement.getAlternativeAt(b);
/* 1067 */       AlternativeElement alternativeElement = alternative.head;
/* 1068 */       while (alternativeElement != null) {
/* 1069 */         alternativeElement.generate();
/* 1070 */         alternativeElement = alternativeElement.next;
/*      */       } 
/*      */     } 
/*      */     
/* 1074 */     if (this.grammar.buildAST)
/*      */     {
/*      */       
/* 1077 */       println("currentAST = _currentAST" + paramTreeElement.ID + "");
/*      */     }
/*      */     
/* 1080 */     println("_t = _t" + paramTreeElement.ID + "");
/*      */     
/* 1082 */     println("_t = _t.getNextSibling()");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException {
/* 1090 */     setGrammar(paramTreeWalkerGrammar);
/* 1091 */     if (!(this.grammar instanceof TreeWalkerGrammar)) {
/* 1092 */       this.antlrTool.panic("Internal error generating tree-walker");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1097 */     setupOutput(this.grammar.getClassName());
/*      */     
/* 1099 */     this.genAST = this.grammar.buildAST;
/* 1100 */     this.tabs = 0;
/*      */ 
/*      */     
/* 1103 */     genHeader();
/*      */ 
/*      */     
/* 1106 */     println("### import antlr and other modules ..");
/* 1107 */     println("import sys");
/* 1108 */     println("import antlr");
/* 1109 */     println("");
/* 1110 */     println("version = sys.version.split()[0]");
/* 1111 */     println("if version < '2.2.1':");
/* 1112 */     this.tabs++;
/* 1113 */     println("False = 0");
/* 1114 */     this.tabs--;
/* 1115 */     println("if version < '2.3':");
/* 1116 */     this.tabs++;
/* 1117 */     println("True = not False");
/* 1118 */     this.tabs--;
/*      */     
/* 1120 */     println("### header action >>> ");
/* 1121 */     printActionCode(this.behavior.getHeaderAction(""), 0);
/* 1122 */     println("### header action <<< ");
/*      */     
/* 1124 */     flushTokens();
/*      */     
/* 1126 */     println("### user code>>>");
/*      */     
/* 1128 */     printActionCode(this.grammar.preambleAction.getText(), 0);
/* 1129 */     println("### user code<<<");
/*      */ 
/*      */     
/* 1132 */     String str1 = null;
/* 1133 */     if (this.grammar.superClass != null) {
/* 1134 */       str1 = this.grammar.superClass;
/*      */     } else {
/*      */       
/* 1137 */       str1 = "antlr." + this.grammar.getSuperClass();
/*      */     } 
/* 1139 */     println("");
/*      */ 
/*      */     
/* 1142 */     String str2 = "";
/* 1143 */     Token token = (Token)this.grammar.options.get("classHeaderPrefix");
/* 1144 */     if (token != null) {
/* 1145 */       String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 1146 */       if (str != null) {
/* 1147 */         str2 = str;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1152 */     genJavadocComment(this.grammar);
/*      */     
/* 1154 */     println("class " + this.treeWalkerClassName + "(" + str1 + "):");
/* 1155 */     this.tabs++;
/*      */ 
/*      */     
/* 1158 */     println("");
/* 1159 */     println("# ctor ..");
/* 1160 */     println("def __init__(self, *args, **kwargs):");
/* 1161 */     this.tabs++;
/* 1162 */     println(str1 + ".__init__(self, *args, **kwargs)");
/* 1163 */     println("self.tokenNames = _tokenNames");
/* 1164 */     genHeaderInit(this.grammar);
/* 1165 */     this.tabs--;
/* 1166 */     println("");
/*      */ 
/*      */     
/* 1169 */     printGrammarAction(this.grammar);
/*      */ 
/*      */     
/* 1172 */     Enumeration enumeration = this.grammar.rules.elements();
/* 1173 */     byte b = 0;
/* 1174 */     String str3 = "";
/* 1175 */     while (enumeration.hasMoreElements()) {
/* 1176 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/* 1177 */       if (grammarSymbol instanceof RuleSymbol) {
/* 1178 */         RuleSymbol ruleSymbol = (RuleSymbol)grammarSymbol;
/* 1179 */         genRule(ruleSymbol, (ruleSymbol.references.size() == 0), b++);
/*      */       } 
/* 1181 */       exitIfError();
/*      */     } 
/*      */ 
/*      */     
/* 1185 */     genTokenStrings();
/*      */ 
/*      */     
/* 1188 */     genBitsets(this.bitsetsUsed, this.grammar.tokenManager.maxTokenType());
/*      */     
/* 1190 */     this.tabs = 0;
/* 1191 */     genHeaderMain(this.grammar);
/*      */     
/* 1193 */     this.currentOutput.close();
/* 1194 */     this.currentOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(WildcardElement paramWildcardElement) {
/* 1202 */     if (paramWildcardElement.getLabel() != null && this.syntacticPredLevel == 0) {
/* 1203 */       println(paramWildcardElement.getLabel() + " = " + this.lt1Value + "");
/*      */     }
/*      */ 
/*      */     
/* 1207 */     genElementAST(paramWildcardElement);
/*      */     
/* 1209 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 1210 */       println("if not _t:");
/* 1211 */       this.tabs++;
/* 1212 */       println("raise antlr.MismatchedTokenException()");
/* 1213 */       this.tabs--;
/*      */     }
/* 1215 */     else if (this.grammar instanceof LexerGrammar) {
/* 1216 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramWildcardElement.getAutoGenType() == 3))
/*      */       {
/* 1218 */         println("_saveIndex = self.text.length()");
/*      */       }
/* 1220 */       println("self.matchNot(antlr.EOF_CHAR)");
/* 1221 */       if (this.grammar instanceof LexerGrammar && (!this.saveText || paramWildcardElement.getAutoGenType() == 3))
/*      */       {
/* 1223 */         println("self.text.setLength(_saveIndex)");
/*      */       }
/*      */     } else {
/*      */       
/* 1227 */       println("self.matchNot(" + getValueString(1, false) + ")");
/*      */     } 
/*      */ 
/*      */     
/* 1231 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 1232 */       println("_t = _t.getNextSibling()");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void gen(ZeroOrMoreBlock paramZeroOrMoreBlock) {
/* 1241 */     int i = this.tabs;
/* 1242 */     genBlockPreamble(paramZeroOrMoreBlock);
/*      */     
/* 1244 */     println("while True:");
/*      */     
/* 1246 */     i = ++this.tabs;
/*      */ 
/*      */     
/* 1249 */     genBlockInitAction(paramZeroOrMoreBlock);
/*      */ 
/*      */     
/* 1252 */     String str = this.currentASTResult;
/* 1253 */     if (paramZeroOrMoreBlock.getLabel() != null) {
/* 1254 */       this.currentASTResult = paramZeroOrMoreBlock.getLabel();
/*      */     }
/*      */     
/* 1257 */     boolean bool = this.grammar.theLLkAnalyzer.deterministic(paramZeroOrMoreBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1269 */     boolean bool1 = false;
/* 1270 */     int j = this.grammar.maxk;
/*      */     
/* 1272 */     if (!paramZeroOrMoreBlock.greedy && paramZeroOrMoreBlock.exitLookaheadDepth <= this.grammar.maxk && paramZeroOrMoreBlock.exitCache[paramZeroOrMoreBlock.exitLookaheadDepth].containsEpsilon()) {
/*      */ 
/*      */       
/* 1275 */       bool1 = true;
/* 1276 */       j = paramZeroOrMoreBlock.exitLookaheadDepth;
/*      */     }
/* 1278 */     else if (!paramZeroOrMoreBlock.greedy && paramZeroOrMoreBlock.exitLookaheadDepth == Integer.MAX_VALUE) {
/*      */       
/* 1280 */       bool1 = true;
/*      */     } 
/* 1282 */     if (bool1) {
/* 1283 */       if (this.DEBUG_CODE_GENERATOR) {
/* 1284 */         System.out.println("nongreedy (...)* loop; exit depth is " + paramZeroOrMoreBlock.exitLookaheadDepth);
/*      */       }
/*      */       
/* 1287 */       String str1 = getLookaheadTestExpression(paramZeroOrMoreBlock.exitCache, j);
/*      */ 
/*      */       
/* 1290 */       println("###  nongreedy exit test");
/* 1291 */       println("if (" + str1 + "):");
/* 1292 */       this.tabs++;
/* 1293 */       println("break");
/* 1294 */       this.tabs--;
/*      */     } 
/*      */ 
/*      */     
/* 1298 */     int k = this.tabs;
/* 1299 */     PythonBlockFinishingInfo pythonBlockFinishingInfo = genCommonBlock(paramZeroOrMoreBlock, false);
/* 1300 */     genBlockFinish(pythonBlockFinishingInfo, "break");
/* 1301 */     this.tabs = k;
/*      */     
/* 1303 */     this.tabs = i;
/* 1304 */     this.tabs--;
/*      */ 
/*      */     
/* 1307 */     this.currentASTResult = str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genAlt(Alternative paramAlternative, AlternativeBlock paramAlternativeBlock) {
/* 1316 */     boolean bool1 = this.genAST;
/* 1317 */     this.genAST = (this.genAST && paramAlternative.getAutoGen());
/*      */     
/* 1319 */     boolean bool2 = this.saveText;
/* 1320 */     this.saveText = (this.saveText && paramAlternative.getAutoGen());
/*      */ 
/*      */     
/* 1323 */     Hashtable hashtable = this.treeVariableMap;
/* 1324 */     this.treeVariableMap = new Hashtable();
/*      */ 
/*      */     
/* 1327 */     if (paramAlternative.exceptionSpec != null) {
/* 1328 */       println("try:");
/* 1329 */       this.tabs++;
/*      */     } 
/*      */     
/* 1332 */     println("pass");
/* 1333 */     AlternativeElement alternativeElement = paramAlternative.head;
/* 1334 */     while (!(alternativeElement instanceof BlockEndElement)) {
/* 1335 */       alternativeElement.generate();
/* 1336 */       alternativeElement = alternativeElement.next;
/*      */     } 
/*      */     
/* 1339 */     if (this.genAST) {
/* 1340 */       if (paramAlternativeBlock instanceof RuleBlock) {
/*      */         
/* 1342 */         RuleBlock ruleBlock = (RuleBlock)paramAlternativeBlock;
/* 1343 */         if (this.grammar.hasSyntacticPredicate);
/*      */         
/* 1345 */         println(ruleBlock.getRuleName() + "_AST = currentAST.root");
/* 1346 */         if (this.grammar.hasSyntacticPredicate);
/*      */       
/*      */       }
/* 1349 */       else if (paramAlternativeBlock.getLabel() != null) {
/* 1350 */         this.antlrTool.warning("Labeled subrules not yet supported", this.grammar.getFilename(), paramAlternativeBlock.getLine(), paramAlternativeBlock.getColumn());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1356 */     if (paramAlternative.exceptionSpec != null) {
/* 1357 */       this.tabs--;
/* 1358 */       genErrorHandler(paramAlternative.exceptionSpec);
/*      */     } 
/*      */     
/* 1361 */     this.genAST = bool1;
/* 1362 */     this.saveText = bool2;
/*      */     
/* 1364 */     this.treeVariableMap = hashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBitsets(Vector paramVector, int paramInt) {
/* 1380 */     println("");
/* 1381 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 1382 */       BitSet bitSet = (BitSet)paramVector.elementAt(b);
/*      */       
/* 1384 */       bitSet.growToInclude(paramInt);
/* 1385 */       genBitSet(bitSet, b);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genBitSet(BitSet paramBitSet, int paramInt) {
/* 1400 */     int i = this.tabs;
/*      */ 
/*      */     
/* 1403 */     this.tabs = 0;
/*      */     
/* 1405 */     println("");
/* 1406 */     println("### generate bit set");
/* 1407 */     println("def mk" + getBitsetName(paramInt) + "(): ");
/*      */     
/* 1409 */     this.tabs++;
/* 1410 */     int j = paramBitSet.lengthInLongWords();
/* 1411 */     if (j < 8) {
/*      */       
/* 1413 */       println("### var1");
/* 1414 */       println("data = [ " + paramBitSet.toStringOfWords() + "]");
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1419 */       println("data = [0L] * " + j + " ### init list");
/*      */       
/* 1421 */       long[] arrayOfLong = paramBitSet.toPackedArray();
/*      */       int k;
/* 1423 */       for (k = 0; k < arrayOfLong.length; ) {
/*      */         
/* 1425 */         if (arrayOfLong[k] == 0L) {
/*      */ 
/*      */           
/* 1428 */           k++;
/*      */           
/*      */           continue;
/*      */         } 
/* 1432 */         if (k + 1 == arrayOfLong.length || arrayOfLong[k] != arrayOfLong[k + 1]) {
/*      */ 
/*      */           
/* 1435 */           println("data[" + k + "] =" + arrayOfLong[k] + "L");
/* 1436 */           k++;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         int m;
/* 1442 */         for (m = k + 1; m < arrayOfLong.length && arrayOfLong[m] == arrayOfLong[k]; m++);
/*      */ 
/*      */         
/* 1445 */         long l = arrayOfLong[k];
/*      */         
/* 1447 */         println("for x in xrange(" + k + ", " + m + "):");
/* 1448 */         this.tabs++;
/* 1449 */         println("data[x] = " + l + "L");
/* 1450 */         this.tabs--;
/* 1451 */         k = m;
/*      */       } 
/*      */     } 
/*      */     
/* 1455 */     println("return data");
/* 1456 */     this.tabs--;
/*      */ 
/*      */     
/* 1459 */     println(getBitsetName(paramInt) + " = antlr.BitSet(mk" + getBitsetName(paramInt) + "())");
/*      */ 
/*      */ 
/*      */     
/* 1463 */     this.tabs = i;
/*      */   }
/*      */ 
/*      */   
/*      */   private void genBlockFinish(PythonBlockFinishingInfo paramPythonBlockFinishingInfo, String paramString) {
/* 1468 */     if (paramPythonBlockFinishingInfo.needAnErrorClause && (paramPythonBlockFinishingInfo.generatedAnIf || paramPythonBlockFinishingInfo.generatedSwitch)) {
/*      */       
/* 1470 */       if (paramPythonBlockFinishingInfo.generatedAnIf)
/*      */       {
/* 1472 */         println("else:");
/*      */       }
/* 1474 */       this.tabs++;
/* 1475 */       println(paramString);
/* 1476 */       this.tabs--;
/*      */     } 
/*      */     
/* 1479 */     if (paramPythonBlockFinishingInfo.postscript != null) {
/* 1480 */       println(paramPythonBlockFinishingInfo.postscript);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void genBlockFinish1(PythonBlockFinishingInfo paramPythonBlockFinishingInfo, String paramString) {
/* 1487 */     if (paramPythonBlockFinishingInfo.needAnErrorClause && (paramPythonBlockFinishingInfo.generatedAnIf || paramPythonBlockFinishingInfo.generatedSwitch)) {
/*      */ 
/*      */       
/* 1490 */       if (paramPythonBlockFinishingInfo.generatedAnIf)
/*      */       {
/*      */         
/* 1493 */         println("else:");
/*      */       }
/* 1495 */       this.tabs++;
/* 1496 */       println(paramString);
/* 1497 */       this.tabs--;
/* 1498 */       if (paramPythonBlockFinishingInfo.generatedAnIf);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1505 */     if (paramPythonBlockFinishingInfo.postscript != null) {
/* 1506 */       println(paramPythonBlockFinishingInfo.postscript);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBlockInitAction(AlternativeBlock paramAlternativeBlock) {
/* 1516 */     if (paramAlternativeBlock.initAction != null) {
/* 1517 */       printAction(processActionForSpecialSymbols(paramAlternativeBlock.initAction, paramAlternativeBlock.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genBlockPreamble(AlternativeBlock paramAlternativeBlock) {
/* 1528 */     if (paramAlternativeBlock instanceof RuleBlock) {
/* 1529 */       RuleBlock ruleBlock = (RuleBlock)paramAlternativeBlock;
/* 1530 */       if (ruleBlock.labeledElements != null) {
/* 1531 */         for (byte b = 0; b < ruleBlock.labeledElements.size(); b++) {
/* 1532 */           AlternativeElement alternativeElement = (AlternativeElement)ruleBlock.labeledElements.elementAt(b);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1539 */           if (alternativeElement instanceof RuleRefElement || (alternativeElement instanceof AlternativeBlock && !(alternativeElement instanceof RuleBlock) && !(alternativeElement instanceof SynPredBlock))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1546 */             if (!(alternativeElement instanceof RuleRefElement) && ((AlternativeBlock)alternativeElement).not && this.analyzer.subruleCanBeInverted((AlternativeBlock)alternativeElement, this.grammar instanceof LexerGrammar)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1554 */               println(alternativeElement.getLabel() + " = " + this.labeledElementInit);
/* 1555 */               if (this.grammar.buildAST) {
/* 1556 */                 genASTDeclaration(alternativeElement);
/*      */               }
/*      */             } else {
/*      */               
/* 1560 */               if (this.grammar.buildAST)
/*      */               {
/*      */ 
/*      */                 
/* 1564 */                 genASTDeclaration(alternativeElement);
/*      */               }
/* 1566 */               if (this.grammar instanceof LexerGrammar) {
/* 1567 */                 println(alternativeElement.getLabel() + " = None");
/*      */               }
/* 1569 */               if (this.grammar instanceof TreeWalkerGrammar)
/*      */               {
/*      */                 
/* 1572 */                 println(alternativeElement.getLabel() + " = " + this.labeledElementInit);
/*      */               }
/*      */             }
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1579 */             println(alternativeElement.getLabel() + " = " + this.labeledElementInit);
/*      */ 
/*      */ 
/*      */             
/* 1583 */             if (this.grammar.buildAST) {
/* 1584 */               if (alternativeElement instanceof GrammarAtom && ((GrammarAtom)alternativeElement).getASTNodeType() != null) {
/*      */                 
/* 1586 */                 GrammarAtom grammarAtom = (GrammarAtom)alternativeElement;
/* 1587 */                 genASTDeclaration(alternativeElement, grammarAtom.getASTNodeType());
/*      */               } else {
/*      */                 
/* 1590 */                 genASTDeclaration(alternativeElement);
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genCases(BitSet paramBitSet) {
/* 1603 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("genCases(" + paramBitSet + ")");
/*      */ 
/*      */     
/* 1606 */     int[] arrayOfInt = paramBitSet.toArray();
/*      */     
/* 1608 */     boolean bool1 = (this.grammar instanceof LexerGrammar) ? true : true;
/* 1609 */     boolean bool2 = true;
/* 1610 */     boolean bool3 = true;
/* 1611 */     print("elif la1 and la1 in ");
/*      */     
/* 1613 */     if (this.grammar instanceof LexerGrammar) {
/*      */       
/* 1615 */       _print("u'");
/* 1616 */       for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/* 1617 */         _print(getValueString(arrayOfInt[b1], false));
/*      */       }
/* 1619 */       _print("':\n");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1624 */     _print("[");
/* 1625 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/* 1626 */       _print(getValueString(arrayOfInt[b], false));
/* 1627 */       if (b + 1 < arrayOfInt.length)
/* 1628 */         _print(","); 
/*      */     } 
/* 1630 */     _print("]:\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PythonBlockFinishingInfo genCommonBlock(AlternativeBlock paramAlternativeBlock, boolean paramBoolean) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield tabs : I
/*      */     //   4: istore_3
/*      */     //   5: iconst_0
/*      */     //   6: istore #4
/*      */     //   8: iconst_0
/*      */     //   9: istore #5
/*      */     //   11: iconst_0
/*      */     //   12: istore #6
/*      */     //   14: new antlr/PythonBlockFinishingInfo
/*      */     //   17: dup
/*      */     //   18: invokespecial <init> : ()V
/*      */     //   21: astore #7
/*      */     //   23: aload_0
/*      */     //   24: getfield genAST : Z
/*      */     //   27: istore #8
/*      */     //   29: aload_0
/*      */     //   30: aload_0
/*      */     //   31: getfield genAST : Z
/*      */     //   34: ifeq -> 48
/*      */     //   37: aload_1
/*      */     //   38: invokevirtual getAutoGen : ()Z
/*      */     //   41: ifeq -> 48
/*      */     //   44: iconst_1
/*      */     //   45: goto -> 49
/*      */     //   48: iconst_0
/*      */     //   49: putfield genAST : Z
/*      */     //   52: aload_0
/*      */     //   53: getfield saveText : Z
/*      */     //   56: istore #9
/*      */     //   58: aload_0
/*      */     //   59: aload_0
/*      */     //   60: getfield saveText : Z
/*      */     //   63: ifeq -> 77
/*      */     //   66: aload_1
/*      */     //   67: invokevirtual getAutoGen : ()Z
/*      */     //   70: ifeq -> 77
/*      */     //   73: iconst_1
/*      */     //   74: goto -> 78
/*      */     //   77: iconst_0
/*      */     //   78: putfield saveText : Z
/*      */     //   81: aload_1
/*      */     //   82: getfield not : Z
/*      */     //   85: ifeq -> 274
/*      */     //   88: aload_0
/*      */     //   89: getfield analyzer : Lantlr/LLkGrammarAnalyzer;
/*      */     //   92: aload_1
/*      */     //   93: aload_0
/*      */     //   94: getfield grammar : Lantlr/Grammar;
/*      */     //   97: instanceof antlr/LexerGrammar
/*      */     //   100: invokeinterface subruleCanBeInverted : (Lantlr/AlternativeBlock;Z)Z
/*      */     //   105: ifeq -> 274
/*      */     //   108: aload_0
/*      */     //   109: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   112: ifeq -> 124
/*      */     //   115: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   118: ldc_w 'special case: ~(subrule)'
/*      */     //   121: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   124: aload_0
/*      */     //   125: getfield analyzer : Lantlr/LLkGrammarAnalyzer;
/*      */     //   128: iconst_1
/*      */     //   129: aload_1
/*      */     //   130: invokeinterface look : (ILantlr/AlternativeBlock;)Lantlr/Lookahead;
/*      */     //   135: astore #10
/*      */     //   137: aload_1
/*      */     //   138: invokevirtual getLabel : ()Ljava/lang/String;
/*      */     //   141: ifnull -> 184
/*      */     //   144: aload_0
/*      */     //   145: getfield syntacticPredLevel : I
/*      */     //   148: ifne -> 184
/*      */     //   151: aload_0
/*      */     //   152: new java/lang/StringBuffer
/*      */     //   155: dup
/*      */     //   156: invokespecial <init> : ()V
/*      */     //   159: aload_1
/*      */     //   160: invokevirtual getLabel : ()Ljava/lang/String;
/*      */     //   163: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   166: ldc ' = '
/*      */     //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   171: aload_0
/*      */     //   172: getfield lt1Value : Ljava/lang/String;
/*      */     //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   178: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   181: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   184: aload_0
/*      */     //   185: aload_1
/*      */     //   186: invokespecial genElementAST : (Lantlr/AlternativeElement;)V
/*      */     //   189: ldc ''
/*      */     //   191: astore #11
/*      */     //   193: aload_0
/*      */     //   194: getfield grammar : Lantlr/Grammar;
/*      */     //   197: instanceof antlr/TreeWalkerGrammar
/*      */     //   200: ifeq -> 208
/*      */     //   203: ldc_w '_t, '
/*      */     //   206: astore #11
/*      */     //   208: aload_0
/*      */     //   209: new java/lang/StringBuffer
/*      */     //   212: dup
/*      */     //   213: invokespecial <init> : ()V
/*      */     //   216: ldc_w 'self.match('
/*      */     //   219: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   222: aload #11
/*      */     //   224: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   227: aload_0
/*      */     //   228: aload_0
/*      */     //   229: aload #10
/*      */     //   231: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   234: invokevirtual markBitsetForGen : (Lantlr/collections/impl/BitSet;)I
/*      */     //   237: invokevirtual getBitsetName : (I)Ljava/lang/String;
/*      */     //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   243: ldc ')'
/*      */     //   245: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   248: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   251: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   254: aload_0
/*      */     //   255: getfield grammar : Lantlr/Grammar;
/*      */     //   258: instanceof antlr/TreeWalkerGrammar
/*      */     //   261: ifeq -> 271
/*      */     //   264: aload_0
/*      */     //   265: ldc_w '_t = _t.getNextSibling()'
/*      */     //   268: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   271: aload #7
/*      */     //   273: areturn
/*      */     //   274: aload_1
/*      */     //   275: invokevirtual getAlternatives : ()Lantlr/collections/impl/Vector;
/*      */     //   278: invokevirtual size : ()I
/*      */     //   281: iconst_1
/*      */     //   282: if_icmpne -> 374
/*      */     //   285: aload_1
/*      */     //   286: iconst_0
/*      */     //   287: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   290: astore #10
/*      */     //   292: aload #10
/*      */     //   294: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   297: ifnull -> 339
/*      */     //   300: aload_0
/*      */     //   301: getfield antlrTool : Lantlr/Tool;
/*      */     //   304: ldc_w 'Syntactic predicate superfluous for single alternative'
/*      */     //   307: aload_0
/*      */     //   308: getfield grammar : Lantlr/Grammar;
/*      */     //   311: invokevirtual getFilename : ()Ljava/lang/String;
/*      */     //   314: aload_1
/*      */     //   315: iconst_0
/*      */     //   316: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   319: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   322: invokevirtual getLine : ()I
/*      */     //   325: aload_1
/*      */     //   326: iconst_0
/*      */     //   327: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   330: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   333: invokevirtual getColumn : ()I
/*      */     //   336: invokevirtual warning : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   339: iload_2
/*      */     //   340: ifeq -> 374
/*      */     //   343: aload #10
/*      */     //   345: getfield semPred : Ljava/lang/String;
/*      */     //   348: ifnull -> 364
/*      */     //   351: aload_0
/*      */     //   352: aload #10
/*      */     //   354: getfield semPred : Ljava/lang/String;
/*      */     //   357: aload_1
/*      */     //   358: getfield line : I
/*      */     //   361: invokevirtual genSemPred : (Ljava/lang/String;I)V
/*      */     //   364: aload_0
/*      */     //   365: aload #10
/*      */     //   367: aload_1
/*      */     //   368: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   371: aload #7
/*      */     //   373: areturn
/*      */     //   374: iconst_0
/*      */     //   375: istore #10
/*      */     //   377: iconst_0
/*      */     //   378: istore #11
/*      */     //   380: iload #11
/*      */     //   382: aload_1
/*      */     //   383: invokevirtual getAlternatives : ()Lantlr/collections/impl/Vector;
/*      */     //   386: invokevirtual size : ()I
/*      */     //   389: if_icmpge -> 417
/*      */     //   392: aload_1
/*      */     //   393: iload #11
/*      */     //   395: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   398: astore #12
/*      */     //   400: aload #12
/*      */     //   402: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   405: ifeq -> 411
/*      */     //   408: iinc #10, 1
/*      */     //   411: iinc #11, 1
/*      */     //   414: goto -> 380
/*      */     //   417: iload #10
/*      */     //   419: aload_0
/*      */     //   420: getfield makeSwitchThreshold : I
/*      */     //   423: if_icmplt -> 695
/*      */     //   426: aload_0
/*      */     //   427: iconst_1
/*      */     //   428: invokespecial lookaheadString : (I)Ljava/lang/String;
/*      */     //   431: astore #11
/*      */     //   433: iconst_1
/*      */     //   434: istore #5
/*      */     //   436: aload_0
/*      */     //   437: getfield grammar : Lantlr/Grammar;
/*      */     //   440: instanceof antlr/TreeWalkerGrammar
/*      */     //   443: ifeq -> 480
/*      */     //   446: aload_0
/*      */     //   447: ldc_w 'if not _t:'
/*      */     //   450: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   453: aload_0
/*      */     //   454: dup
/*      */     //   455: getfield tabs : I
/*      */     //   458: iconst_1
/*      */     //   459: iadd
/*      */     //   460: putfield tabs : I
/*      */     //   463: aload_0
/*      */     //   464: ldc_w '_t = antlr.ASTNULL'
/*      */     //   467: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   470: aload_0
/*      */     //   471: dup
/*      */     //   472: getfield tabs : I
/*      */     //   475: iconst_1
/*      */     //   476: isub
/*      */     //   477: putfield tabs : I
/*      */     //   480: aload_0
/*      */     //   481: new java/lang/StringBuffer
/*      */     //   484: dup
/*      */     //   485: invokespecial <init> : ()V
/*      */     //   488: ldc_w 'la1 = '
/*      */     //   491: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   494: aload #11
/*      */     //   496: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   499: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   502: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   505: aload_0
/*      */     //   506: ldc_w 'if False:'
/*      */     //   509: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   512: aload_0
/*      */     //   513: dup
/*      */     //   514: getfield tabs : I
/*      */     //   517: iconst_1
/*      */     //   518: iadd
/*      */     //   519: putfield tabs : I
/*      */     //   522: aload_0
/*      */     //   523: ldc_w 'pass'
/*      */     //   526: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   529: aload_0
/*      */     //   530: dup
/*      */     //   531: getfield tabs : I
/*      */     //   534: iconst_1
/*      */     //   535: isub
/*      */     //   536: putfield tabs : I
/*      */     //   539: iconst_0
/*      */     //   540: istore #12
/*      */     //   542: iload #12
/*      */     //   544: aload_1
/*      */     //   545: getfield alternatives : Lantlr/collections/impl/Vector;
/*      */     //   548: invokevirtual size : ()I
/*      */     //   551: if_icmpge -> 679
/*      */     //   554: aload_1
/*      */     //   555: iload #12
/*      */     //   557: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   560: astore #13
/*      */     //   562: aload #13
/*      */     //   564: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   567: ifne -> 573
/*      */     //   570: goto -> 673
/*      */     //   573: aload #13
/*      */     //   575: getfield cache : [Lantlr/Lookahead;
/*      */     //   578: iconst_1
/*      */     //   579: aaload
/*      */     //   580: astore #14
/*      */     //   582: aload #14
/*      */     //   584: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   587: invokevirtual degree : ()I
/*      */     //   590: ifne -> 637
/*      */     //   593: aload #14
/*      */     //   595: invokevirtual containsEpsilon : ()Z
/*      */     //   598: ifne -> 637
/*      */     //   601: aload_0
/*      */     //   602: getfield antlrTool : Lantlr/Tool;
/*      */     //   605: ldc_w 'Alternate omitted due to empty prediction set'
/*      */     //   608: aload_0
/*      */     //   609: getfield grammar : Lantlr/Grammar;
/*      */     //   612: invokevirtual getFilename : ()Ljava/lang/String;
/*      */     //   615: aload #13
/*      */     //   617: getfield head : Lantlr/AlternativeElement;
/*      */     //   620: invokevirtual getLine : ()I
/*      */     //   623: aload #13
/*      */     //   625: getfield head : Lantlr/AlternativeElement;
/*      */     //   628: invokevirtual getColumn : ()I
/*      */     //   631: invokevirtual warning : (Ljava/lang/String;Ljava/lang/String;II)V
/*      */     //   634: goto -> 673
/*      */     //   637: aload_0
/*      */     //   638: aload #14
/*      */     //   640: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   643: invokevirtual genCases : (Lantlr/collections/impl/BitSet;)V
/*      */     //   646: aload_0
/*      */     //   647: dup
/*      */     //   648: getfield tabs : I
/*      */     //   651: iconst_1
/*      */     //   652: iadd
/*      */     //   653: putfield tabs : I
/*      */     //   656: aload_0
/*      */     //   657: aload #13
/*      */     //   659: aload_1
/*      */     //   660: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   663: aload_0
/*      */     //   664: dup
/*      */     //   665: getfield tabs : I
/*      */     //   668: iconst_1
/*      */     //   669: isub
/*      */     //   670: putfield tabs : I
/*      */     //   673: iinc #12, 1
/*      */     //   676: goto -> 542
/*      */     //   679: aload_0
/*      */     //   680: ldc 'else:'
/*      */     //   682: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   685: aload_0
/*      */     //   686: dup
/*      */     //   687: getfield tabs : I
/*      */     //   690: iconst_1
/*      */     //   691: iadd
/*      */     //   692: putfield tabs : I
/*      */     //   695: aload_0
/*      */     //   696: getfield grammar : Lantlr/Grammar;
/*      */     //   699: instanceof antlr/LexerGrammar
/*      */     //   702: ifeq -> 715
/*      */     //   705: aload_0
/*      */     //   706: getfield grammar : Lantlr/Grammar;
/*      */     //   709: getfield maxk : I
/*      */     //   712: goto -> 716
/*      */     //   715: iconst_0
/*      */     //   716: istore #11
/*      */     //   718: iload #11
/*      */     //   720: istore #12
/*      */     //   722: iload #12
/*      */     //   724: iflt -> 1534
/*      */     //   727: iconst_0
/*      */     //   728: istore #13
/*      */     //   730: iload #13
/*      */     //   732: aload_1
/*      */     //   733: getfield alternatives : Lantlr/collections/impl/Vector;
/*      */     //   736: invokevirtual size : ()I
/*      */     //   739: if_icmpge -> 1528
/*      */     //   742: aload_1
/*      */     //   743: iload #13
/*      */     //   745: invokevirtual getAlternativeAt : (I)Lantlr/Alternative;
/*      */     //   748: astore #14
/*      */     //   750: aload_0
/*      */     //   751: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   754: ifeq -> 784
/*      */     //   757: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   760: new java/lang/StringBuffer
/*      */     //   763: dup
/*      */     //   764: invokespecial <init> : ()V
/*      */     //   767: ldc_w 'genAlt: '
/*      */     //   770: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   773: iload #13
/*      */     //   775: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   778: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   781: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   784: iload #5
/*      */     //   786: ifeq -> 816
/*      */     //   789: aload #14
/*      */     //   791: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   794: ifeq -> 816
/*      */     //   797: aload_0
/*      */     //   798: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   801: ifeq -> 1522
/*      */     //   804: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   807: ldc_w 'ignoring alt because it was in the switch'
/*      */     //   810: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   813: goto -> 1522
/*      */     //   816: iconst_0
/*      */     //   817: istore #16
/*      */     //   819: aload_0
/*      */     //   820: getfield grammar : Lantlr/Grammar;
/*      */     //   823: instanceof antlr/LexerGrammar
/*      */     //   826: ifeq -> 956
/*      */     //   829: aload #14
/*      */     //   831: getfield lookaheadDepth : I
/*      */     //   834: istore #17
/*      */     //   836: iload #17
/*      */     //   838: ldc 2147483647
/*      */     //   840: if_icmpne -> 852
/*      */     //   843: aload_0
/*      */     //   844: getfield grammar : Lantlr/Grammar;
/*      */     //   847: getfield maxk : I
/*      */     //   850: istore #17
/*      */     //   852: iload #17
/*      */     //   854: iconst_1
/*      */     //   855: if_icmplt -> 878
/*      */     //   858: aload #14
/*      */     //   860: getfield cache : [Lantlr/Lookahead;
/*      */     //   863: iload #17
/*      */     //   865: aaload
/*      */     //   866: invokevirtual containsEpsilon : ()Z
/*      */     //   869: ifeq -> 878
/*      */     //   872: iinc #17, -1
/*      */     //   875: goto -> 852
/*      */     //   878: iload #17
/*      */     //   880: iload #12
/*      */     //   882: if_icmpeq -> 933
/*      */     //   885: aload_0
/*      */     //   886: getfield DEBUG_CODE_GENERATOR : Z
/*      */     //   889: ifeq -> 1522
/*      */     //   892: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*      */     //   895: new java/lang/StringBuffer
/*      */     //   898: dup
/*      */     //   899: invokespecial <init> : ()V
/*      */     //   902: ldc_w 'ignoring alt because effectiveDepth!=altDepth'
/*      */     //   905: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   908: iload #17
/*      */     //   910: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   913: ldc_w '!='
/*      */     //   916: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   919: iload #12
/*      */     //   921: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   924: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   927: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   930: goto -> 1522
/*      */     //   933: aload_0
/*      */     //   934: aload #14
/*      */     //   936: iload #17
/*      */     //   938: invokevirtual lookaheadIsEmpty : (Lantlr/Alternative;I)Z
/*      */     //   941: istore #16
/*      */     //   943: aload_0
/*      */     //   944: aload #14
/*      */     //   946: iload #17
/*      */     //   948: invokevirtual getLookaheadTestExpression : (Lantlr/Alternative;I)Ljava/lang/String;
/*      */     //   951: astore #15
/*      */     //   953: goto -> 986
/*      */     //   956: aload_0
/*      */     //   957: aload #14
/*      */     //   959: aload_0
/*      */     //   960: getfield grammar : Lantlr/Grammar;
/*      */     //   963: getfield maxk : I
/*      */     //   966: invokevirtual lookaheadIsEmpty : (Lantlr/Alternative;I)Z
/*      */     //   969: istore #16
/*      */     //   971: aload_0
/*      */     //   972: aload #14
/*      */     //   974: aload_0
/*      */     //   975: getfield grammar : Lantlr/Grammar;
/*      */     //   978: getfield maxk : I
/*      */     //   981: invokevirtual getLookaheadTestExpression : (Lantlr/Alternative;I)Ljava/lang/String;
/*      */     //   984: astore #15
/*      */     //   986: aload #14
/*      */     //   988: getfield cache : [Lantlr/Lookahead;
/*      */     //   991: iconst_1
/*      */     //   992: aaload
/*      */     //   993: getfield fset : Lantlr/collections/impl/BitSet;
/*      */     //   996: invokevirtual degree : ()I
/*      */     //   999: bipush #127
/*      */     //   1001: if_icmple -> 1083
/*      */     //   1004: aload #14
/*      */     //   1006: invokestatic suitableForCaseExpression : (Lantlr/Alternative;)Z
/*      */     //   1009: ifeq -> 1083
/*      */     //   1012: iload #4
/*      */     //   1014: ifne -> 1050
/*      */     //   1017: aload_0
/*      */     //   1018: new java/lang/StringBuffer
/*      */     //   1021: dup
/*      */     //   1022: invokespecial <init> : ()V
/*      */     //   1025: ldc_w '<m1> if '
/*      */     //   1028: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1031: aload #15
/*      */     //   1033: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1036: ldc ':'
/*      */     //   1038: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1041: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1044: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1047: goto -> 1492
/*      */     //   1050: aload_0
/*      */     //   1051: new java/lang/StringBuffer
/*      */     //   1054: dup
/*      */     //   1055: invokespecial <init> : ()V
/*      */     //   1058: ldc_w '<m2> elif '
/*      */     //   1061: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1064: aload #15
/*      */     //   1066: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1069: ldc ':'
/*      */     //   1071: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1074: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1077: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1080: goto -> 1492
/*      */     //   1083: iload #16
/*      */     //   1085: ifeq -> 1145
/*      */     //   1088: aload #14
/*      */     //   1090: getfield semPred : Ljava/lang/String;
/*      */     //   1093: ifnonnull -> 1145
/*      */     //   1096: aload #14
/*      */     //   1098: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1101: ifnonnull -> 1145
/*      */     //   1104: iload #4
/*      */     //   1106: ifne -> 1119
/*      */     //   1109: aload_0
/*      */     //   1110: ldc_w '##<m3> <closing'
/*      */     //   1113: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1116: goto -> 1136
/*      */     //   1119: aload_0
/*      */     //   1120: ldc_w 'else: ## <m4>'
/*      */     //   1123: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1126: aload_0
/*      */     //   1127: dup
/*      */     //   1128: getfield tabs : I
/*      */     //   1131: iconst_1
/*      */     //   1132: iadd
/*      */     //   1133: putfield tabs : I
/*      */     //   1136: aload #7
/*      */     //   1138: iconst_0
/*      */     //   1139: putfield needAnErrorClause : Z
/*      */     //   1142: goto -> 1492
/*      */     //   1145: aload #14
/*      */     //   1147: getfield semPred : Ljava/lang/String;
/*      */     //   1150: ifnull -> 1318
/*      */     //   1153: new antlr/ActionTransInfo
/*      */     //   1156: dup
/*      */     //   1157: invokespecial <init> : ()V
/*      */     //   1160: astore #17
/*      */     //   1162: aload_0
/*      */     //   1163: aload #14
/*      */     //   1165: getfield semPred : Ljava/lang/String;
/*      */     //   1168: aload_1
/*      */     //   1169: getfield line : I
/*      */     //   1172: aload_0
/*      */     //   1173: getfield currentRule : Lantlr/RuleBlock;
/*      */     //   1176: aload #17
/*      */     //   1178: invokevirtual processActionForSpecialSymbols : (Ljava/lang/String;ILantlr/RuleBlock;Lantlr/ActionTransInfo;)Ljava/lang/String;
/*      */     //   1181: astore #18
/*      */     //   1183: aload_0
/*      */     //   1184: getfield grammar : Lantlr/Grammar;
/*      */     //   1187: instanceof antlr/ParserGrammar
/*      */     //   1190: ifne -> 1203
/*      */     //   1193: aload_0
/*      */     //   1194: getfield grammar : Lantlr/Grammar;
/*      */     //   1197: instanceof antlr/LexerGrammar
/*      */     //   1200: ifeq -> 1279
/*      */     //   1203: aload_0
/*      */     //   1204: getfield grammar : Lantlr/Grammar;
/*      */     //   1207: getfield debuggingOutput : Z
/*      */     //   1210: ifeq -> 1279
/*      */     //   1213: new java/lang/StringBuffer
/*      */     //   1216: dup
/*      */     //   1217: invokespecial <init> : ()V
/*      */     //   1220: ldc '('
/*      */     //   1222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1225: aload #15
/*      */     //   1227: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1230: ldc_w ' and fireSemanticPredicateEvaluated(antlr.debug.SemanticPredicateEvent.PREDICTING, '
/*      */     //   1233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1236: aload_0
/*      */     //   1237: aload_0
/*      */     //   1238: getfield charFormatter : Lantlr/CharFormatter;
/*      */     //   1241: aload #18
/*      */     //   1243: invokeinterface escapeString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1248: invokevirtual addSemPred : (Ljava/lang/String;)I
/*      */     //   1251: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   1254: ldc_w ', '
/*      */     //   1257: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1260: aload #18
/*      */     //   1262: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1265: ldc_w '))'
/*      */     //   1268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1271: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1274: astore #15
/*      */     //   1276: goto -> 1318
/*      */     //   1279: new java/lang/StringBuffer
/*      */     //   1282: dup
/*      */     //   1283: invokespecial <init> : ()V
/*      */     //   1286: ldc '('
/*      */     //   1288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1291: aload #15
/*      */     //   1293: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1296: ldc_w ' and ('
/*      */     //   1299: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1302: aload #18
/*      */     //   1304: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1307: ldc_w '))'
/*      */     //   1310: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1313: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1316: astore #15
/*      */     //   1318: iload #4
/*      */     //   1320: ifle -> 1397
/*      */     //   1323: aload #14
/*      */     //   1325: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1328: ifnull -> 1364
/*      */     //   1331: aload_0
/*      */     //   1332: ldc 'else:'
/*      */     //   1334: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1337: aload_0
/*      */     //   1338: dup
/*      */     //   1339: getfield tabs : I
/*      */     //   1342: iconst_1
/*      */     //   1343: iadd
/*      */     //   1344: putfield tabs : I
/*      */     //   1347: aload_0
/*      */     //   1348: aload #14
/*      */     //   1350: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1353: aload #15
/*      */     //   1355: invokevirtual genSynPred : (Lantlr/SynPredBlock;Ljava/lang/String;)V
/*      */     //   1358: iinc #6, 1
/*      */     //   1361: goto -> 1492
/*      */     //   1364: aload_0
/*      */     //   1365: new java/lang/StringBuffer
/*      */     //   1368: dup
/*      */     //   1369: invokespecial <init> : ()V
/*      */     //   1372: ldc_w 'elif '
/*      */     //   1375: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1378: aload #15
/*      */     //   1380: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1383: ldc ':'
/*      */     //   1385: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1388: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1391: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1394: goto -> 1492
/*      */     //   1397: aload #14
/*      */     //   1399: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1402: ifnull -> 1419
/*      */     //   1405: aload_0
/*      */     //   1406: aload #14
/*      */     //   1408: getfield synPred : Lantlr/SynPredBlock;
/*      */     //   1411: aload #15
/*      */     //   1413: invokevirtual genSynPred : (Lantlr/SynPredBlock;Ljava/lang/String;)V
/*      */     //   1416: goto -> 1492
/*      */     //   1419: aload_0
/*      */     //   1420: getfield grammar : Lantlr/Grammar;
/*      */     //   1423: instanceof antlr/TreeWalkerGrammar
/*      */     //   1426: ifeq -> 1463
/*      */     //   1429: aload_0
/*      */     //   1430: ldc_w 'if not _t:'
/*      */     //   1433: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1436: aload_0
/*      */     //   1437: dup
/*      */     //   1438: getfield tabs : I
/*      */     //   1441: iconst_1
/*      */     //   1442: iadd
/*      */     //   1443: putfield tabs : I
/*      */     //   1446: aload_0
/*      */     //   1447: ldc_w '_t = antlr.ASTNULL'
/*      */     //   1450: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1453: aload_0
/*      */     //   1454: dup
/*      */     //   1455: getfield tabs : I
/*      */     //   1458: iconst_1
/*      */     //   1459: isub
/*      */     //   1460: putfield tabs : I
/*      */     //   1463: aload_0
/*      */     //   1464: new java/lang/StringBuffer
/*      */     //   1467: dup
/*      */     //   1468: invokespecial <init> : ()V
/*      */     //   1471: ldc 'if '
/*      */     //   1473: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1476: aload #15
/*      */     //   1478: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1481: ldc ':'
/*      */     //   1483: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   1486: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1489: invokevirtual println : (Ljava/lang/String;)V
/*      */     //   1492: iinc #4, 1
/*      */     //   1495: aload_0
/*      */     //   1496: dup
/*      */     //   1497: getfield tabs : I
/*      */     //   1500: iconst_1
/*      */     //   1501: iadd
/*      */     //   1502: putfield tabs : I
/*      */     //   1505: aload_0
/*      */     //   1506: aload #14
/*      */     //   1508: aload_1
/*      */     //   1509: invokevirtual genAlt : (Lantlr/Alternative;Lantlr/AlternativeBlock;)V
/*      */     //   1512: aload_0
/*      */     //   1513: dup
/*      */     //   1514: getfield tabs : I
/*      */     //   1517: iconst_1
/*      */     //   1518: isub
/*      */     //   1519: putfield tabs : I
/*      */     //   1522: iinc #13, 1
/*      */     //   1525: goto -> 730
/*      */     //   1528: iinc #12, -1
/*      */     //   1531: goto -> 722
/*      */     //   1534: ldc ''
/*      */     //   1536: astore #12
/*      */     //   1538: aload_0
/*      */     //   1539: iload #8
/*      */     //   1541: putfield genAST : Z
/*      */     //   1544: aload_0
/*      */     //   1545: iload #9
/*      */     //   1547: putfield saveText : Z
/*      */     //   1550: iload #5
/*      */     //   1552: ifeq -> 1586
/*      */     //   1555: aload #7
/*      */     //   1557: aload #12
/*      */     //   1559: putfield postscript : Ljava/lang/String;
/*      */     //   1562: aload #7
/*      */     //   1564: iconst_1
/*      */     //   1565: putfield generatedSwitch : Z
/*      */     //   1568: aload #7
/*      */     //   1570: iload #4
/*      */     //   1572: ifle -> 1579
/*      */     //   1575: iconst_1
/*      */     //   1576: goto -> 1580
/*      */     //   1579: iconst_0
/*      */     //   1580: putfield generatedAnIf : Z
/*      */     //   1583: goto -> 1614
/*      */     //   1586: aload #7
/*      */     //   1588: aload #12
/*      */     //   1590: putfield postscript : Ljava/lang/String;
/*      */     //   1593: aload #7
/*      */     //   1595: iconst_0
/*      */     //   1596: putfield generatedSwitch : Z
/*      */     //   1599: aload #7
/*      */     //   1601: iload #4
/*      */     //   1603: ifle -> 1610
/*      */     //   1606: iconst_1
/*      */     //   1607: goto -> 1611
/*      */     //   1610: iconst_0
/*      */     //   1611: putfield generatedAnIf : Z
/*      */     //   1614: aload #7
/*      */     //   1616: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1646	-> 0
/*      */     //   #1647	-> 5
/*      */     //   #1648	-> 8
/*      */     //   #1649	-> 11
/*      */     //   #1651	-> 14
/*      */     //   #1655	-> 23
/*      */     //   #1656	-> 29
/*      */     //   #1658	-> 52
/*      */     //   #1659	-> 58
/*      */     //   #1662	-> 81
/*      */     //   #1667	-> 108
/*      */     //   #1668	-> 124
/*      */     //   #1670	-> 137
/*      */     //   #1672	-> 151
/*      */     //   #1676	-> 184
/*      */     //   #1678	-> 189
/*      */     //   #1679	-> 193
/*      */     //   #1680	-> 203
/*      */     //   #1684	-> 208
/*      */     //   #1687	-> 254
/*      */     //   #1688	-> 264
/*      */     //   #1690	-> 271
/*      */     //   #1695	-> 274
/*      */     //   #1697	-> 285
/*      */     //   #1699	-> 292
/*      */     //   #1700	-> 300
/*      */     //   #1707	-> 339
/*      */     //   #1709	-> 343
/*      */     //   #1711	-> 351
/*      */     //   #1713	-> 364
/*      */     //   #1714	-> 371
/*      */     //   #1727	-> 374
/*      */     //   #1728	-> 377
/*      */     //   #1729	-> 392
/*      */     //   #1730	-> 400
/*      */     //   #1731	-> 408
/*      */     //   #1728	-> 411
/*      */     //   #1736	-> 417
/*      */     //   #1739	-> 426
/*      */     //   #1740	-> 433
/*      */     //   #1742	-> 436
/*      */     //   #1743	-> 446
/*      */     //   #1744	-> 453
/*      */     //   #1745	-> 463
/*      */     //   #1746	-> 470
/*      */     //   #1749	-> 480
/*      */     //   #1751	-> 505
/*      */     //   #1752	-> 512
/*      */     //   #1753	-> 522
/*      */     //   #1755	-> 529
/*      */     //   #1757	-> 539
/*      */     //   #1759	-> 554
/*      */     //   #1762	-> 562
/*      */     //   #1763	-> 570
/*      */     //   #1765	-> 573
/*      */     //   #1766	-> 582
/*      */     //   #1768	-> 601
/*      */     //   #1776	-> 637
/*      */     //   #1777	-> 646
/*      */     //   #1778	-> 656
/*      */     //   #1779	-> 663
/*      */     //   #1757	-> 673
/*      */     //   #1783	-> 679
/*      */     //   #1784	-> 685
/*      */     //   #1800	-> 695
/*      */     //   #1801	-> 718
/*      */     //   #1803	-> 727
/*      */     //   #1805	-> 742
/*      */     //   #1806	-> 750
/*      */     //   #1811	-> 784
/*      */     //   #1812	-> 797
/*      */     //   #1813	-> 804
/*      */     //   #1818	-> 816
/*      */     //   #1820	-> 819
/*      */     //   #1825	-> 829
/*      */     //   #1826	-> 836
/*      */     //   #1828	-> 843
/*      */     //   #1830	-> 852
/*      */     //   #1832	-> 872
/*      */     //   #1836	-> 878
/*      */     //   #1837	-> 885
/*      */     //   #1838	-> 892
/*      */     //   #1844	-> 933
/*      */     //   #1845	-> 943
/*      */     //   #1850	-> 956
/*      */     //   #1851	-> 971
/*      */     //   #1856	-> 986
/*      */     //   #1858	-> 1012
/*      */     //   #1859	-> 1017
/*      */     //   #1862	-> 1050
/*      */     //   #1867	-> 1083
/*      */     //   #1875	-> 1104
/*      */     //   #1876	-> 1109
/*      */     //   #1880	-> 1119
/*      */     //   #1881	-> 1126
/*      */     //   #1885	-> 1136
/*      */     //   #1893	-> 1145
/*      */     //   #1898	-> 1153
/*      */     //   #1899	-> 1162
/*      */     //   #1908	-> 1183
/*      */     //   #1912	-> 1213
/*      */     //   #1918	-> 1279
/*      */     //   #1923	-> 1318
/*      */     //   #1925	-> 1323
/*      */     //   #1927	-> 1331
/*      */     //   #1928	-> 1337
/*      */     //   #1929	-> 1347
/*      */     //   #1930	-> 1358
/*      */     //   #1934	-> 1364
/*      */     //   #1939	-> 1397
/*      */     //   #1941	-> 1405
/*      */     //   #1947	-> 1419
/*      */     //   #1948	-> 1429
/*      */     //   #1949	-> 1436
/*      */     //   #1950	-> 1446
/*      */     //   #1951	-> 1453
/*      */     //   #1953	-> 1463
/*      */     //   #1959	-> 1492
/*      */     //   #1960	-> 1495
/*      */     //   #1961	-> 1505
/*      */     //   #1963	-> 1512
/*      */     //   #1803	-> 1522
/*      */     //   #1801	-> 1528
/*      */     //   #1966	-> 1534
/*      */     //   #1972	-> 1538
/*      */     //   #1975	-> 1544
/*      */     //   #1978	-> 1550
/*      */     //   #1979	-> 1555
/*      */     //   #1980	-> 1562
/*      */     //   #1981	-> 1568
/*      */     //   #1984	-> 1586
/*      */     //   #1985	-> 1593
/*      */     //   #1986	-> 1599
/*      */     //   #1989	-> 1614
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean suitableForCaseExpression(Alternative paramAlternative) {
/* 1993 */     return (paramAlternative.lookaheadDepth == 1 && paramAlternative.semPred == null && !paramAlternative.cache[1].containsEpsilon() && (paramAlternative.cache[1]).fset.degree() <= 127);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genElementAST(AlternativeElement paramAlternativeElement) {
/* 2004 */     if (this.grammar instanceof TreeWalkerGrammar && !this.grammar.buildAST) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2009 */       if (paramAlternativeElement.getLabel() == null) {
/* 2010 */         String str1 = this.lt1Value;
/*      */         
/* 2012 */         String str2 = "tmp" + this.astVarNumber + "_AST";
/* 2013 */         this.astVarNumber++;
/*      */         
/* 2015 */         mapTreeVariable(paramAlternativeElement, str2);
/*      */         
/* 2017 */         println(str2 + "_in = " + str1);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/* 2022 */     if (this.grammar.buildAST && this.syntacticPredLevel == 0) {
/* 2023 */       String str1, str2; boolean bool1 = (this.genAST && (paramAlternativeElement.getLabel() != null || paramAlternativeElement.getAutoGenType() != 3)) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2034 */       if (paramAlternativeElement.getAutoGenType() != 3 && paramAlternativeElement instanceof TokenRefElement)
/*      */       {
/*      */         
/* 2037 */         bool1 = true;
/*      */       }
/*      */       
/* 2040 */       boolean bool2 = (this.grammar.hasSyntacticPredicate && bool1) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2047 */       if (paramAlternativeElement.getLabel() != null) {
/* 2048 */         str1 = paramAlternativeElement.getLabel();
/* 2049 */         str2 = paramAlternativeElement.getLabel();
/*      */       } else {
/*      */         
/* 2052 */         str1 = this.lt1Value;
/*      */         
/* 2054 */         str2 = "tmp" + this.astVarNumber;
/*      */         
/* 2056 */         this.astVarNumber++;
/*      */       } 
/*      */ 
/*      */       
/* 2060 */       if (bool1)
/*      */       {
/* 2062 */         if (paramAlternativeElement instanceof GrammarAtom) {
/* 2063 */           GrammarAtom grammarAtom = (GrammarAtom)paramAlternativeElement;
/* 2064 */           if (grammarAtom.getASTNodeType() != null) {
/* 2065 */             genASTDeclaration(paramAlternativeElement, str2, grammarAtom.getASTNodeType());
/*      */           } else {
/*      */             
/* 2068 */             genASTDeclaration(paramAlternativeElement, str2, this.labeledElementASTType);
/*      */           } 
/*      */         } else {
/*      */           
/* 2072 */           genASTDeclaration(paramAlternativeElement, str2, this.labeledElementASTType);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 2077 */       String str3 = str2 + "_AST";
/*      */ 
/*      */       
/* 2080 */       mapTreeVariable(paramAlternativeElement, str3);
/* 2081 */       if (this.grammar instanceof TreeWalkerGrammar)
/*      */       {
/* 2083 */         println(str3 + "_in = None");
/*      */       }
/*      */ 
/*      */       
/* 2087 */       if (bool2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2094 */       if (paramAlternativeElement.getLabel() != null) {
/* 2095 */         if (paramAlternativeElement instanceof GrammarAtom) {
/* 2096 */           println(str3 + " = " + getASTCreateString((GrammarAtom)paramAlternativeElement, str1) + "");
/*      */         } else {
/*      */           
/* 2099 */           println(str3 + " = " + getASTCreateString(str1) + "");
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 2104 */       if (paramAlternativeElement.getLabel() == null && bool1) {
/* 2105 */         str1 = this.lt1Value;
/* 2106 */         if (paramAlternativeElement instanceof GrammarAtom) {
/* 2107 */           println(str3 + " = " + getASTCreateString((GrammarAtom)paramAlternativeElement, str1) + "");
/*      */         } else {
/*      */           
/* 2110 */           println(str3 + " = " + getASTCreateString(str1) + "");
/*      */         } 
/*      */         
/* 2113 */         if (this.grammar instanceof TreeWalkerGrammar)
/*      */         {
/* 2115 */           println(str3 + "_in = " + str1 + "");
/*      */         }
/*      */       } 
/*      */       
/* 2119 */       if (this.genAST) {
/* 2120 */         switch (paramAlternativeElement.getAutoGenType()) {
/*      */           case 1:
/* 2122 */             println("self.addASTChild(currentAST, " + str3 + ")");
/*      */             break;
/*      */           case 2:
/* 2125 */             println("self.makeASTRoot(currentAST, " + str3 + ")");
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       }
/* 2131 */       if (bool2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorCatchForElement(AlternativeElement paramAlternativeElement) {
/* 2141 */     if (paramAlternativeElement.getLabel() == null)
/* 2142 */       return;  String str = paramAlternativeElement.enclosingRuleName;
/* 2143 */     if (this.grammar instanceof LexerGrammar) {
/* 2144 */       str = CodeGenerator.encodeLexerRuleName(paramAlternativeElement.enclosingRuleName);
/*      */     }
/* 2146 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 2147 */     if (ruleSymbol == null) {
/* 2148 */       this.antlrTool.panic("Enclosing rule not found!");
/*      */     }
/* 2150 */     ExceptionSpec exceptionSpec = ruleSymbol.block.findExceptionSpec(paramAlternativeElement.getLabel());
/* 2151 */     if (exceptionSpec != null) {
/* 2152 */       this.tabs--;
/* 2153 */       genErrorHandler(exceptionSpec);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void genErrorHandler(ExceptionSpec paramExceptionSpec) {
/* 2160 */     for (byte b = 0; b < paramExceptionSpec.handlers.size(); b++) {
/* 2161 */       ExceptionHandler exceptionHandler = (ExceptionHandler)paramExceptionSpec.handlers.elementAt(b);
/*      */       
/* 2163 */       String str1 = "", str2 = "";
/* 2164 */       String str3 = exceptionHandler.exceptionTypeAndName.getText();
/* 2165 */       str3 = removeAssignmentFromDeclaration(str3);
/* 2166 */       str3 = str3.trim();
/*      */ 
/*      */       
/* 2169 */       for (int i = str3.length() - 1; i >= 0; i--) {
/*      */         
/* 2171 */         if (!Character.isLetterOrDigit(str3.charAt(i)) && str3.charAt(i) != '_') {
/*      */ 
/*      */           
/* 2174 */           str1 = str3.substring(0, i);
/* 2175 */           str2 = str3.substring(i + 1);
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 2180 */       println("except " + str1 + ", " + str2 + ":");
/* 2181 */       this.tabs++;
/* 2182 */       if (this.grammar.hasSyntacticPredicate) {
/* 2183 */         println("if not self.inputState.guessing:");
/* 2184 */         this.tabs++;
/*      */       } 
/*      */ 
/*      */       
/* 2188 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 2189 */       printAction(processActionForSpecialSymbols(exceptionHandler.action.getText(), exceptionHandler.action.getLine(), this.currentRule, actionTransInfo));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2195 */       if (this.grammar.hasSyntacticPredicate) {
/* 2196 */         this.tabs--;
/* 2197 */         println("else:");
/* 2198 */         this.tabs++;
/*      */         
/* 2200 */         println("raise " + str2);
/* 2201 */         this.tabs--;
/*      */       } 
/*      */       
/* 2204 */       this.tabs--;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void genErrorTryForElement(AlternativeElement paramAlternativeElement) {
/* 2210 */     if (paramAlternativeElement.getLabel() == null)
/* 2211 */       return;  String str = paramAlternativeElement.enclosingRuleName;
/* 2212 */     if (this.grammar instanceof LexerGrammar) {
/* 2213 */       str = CodeGenerator.encodeLexerRuleName(paramAlternativeElement.enclosingRuleName);
/*      */     }
/* 2215 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(str);
/* 2216 */     if (ruleSymbol == null) {
/* 2217 */       this.antlrTool.panic("Enclosing rule not found!");
/*      */     }
/* 2219 */     ExceptionSpec exceptionSpec = ruleSymbol.block.findExceptionSpec(paramAlternativeElement.getLabel());
/* 2220 */     if (exceptionSpec != null) {
/* 2221 */       println("try: # for error handling");
/* 2222 */       this.tabs++;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement) {
/* 2227 */     genASTDeclaration(paramAlternativeElement, this.labeledElementASTType);
/*      */   }
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement, String paramString) {
/* 2231 */     genASTDeclaration(paramAlternativeElement, paramAlternativeElement.getLabel(), paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genASTDeclaration(AlternativeElement paramAlternativeElement, String paramString1, String paramString2) {
/* 2236 */     if (this.declaredASTVariables.contains(paramAlternativeElement)) {
/*      */       return;
/*      */     }
/*      */     
/* 2240 */     println(paramString1 + "_AST = None");
/*      */ 
/*      */     
/* 2243 */     this.declaredASTVariables.put(paramAlternativeElement, paramAlternativeElement);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genHeader() {
/* 2248 */     println("### $ANTLR " + Tool.version + ": " + "\"" + this.antlrTool.fileMinusPath(this.antlrTool.grammarFile) + "\"" + " -> " + "\"" + this.grammar.getClassName() + ".py\"$");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genLexerTest() {
/* 2264 */     String str = this.grammar.getClassName();
/* 2265 */     println("if __name__ == '__main__' :");
/* 2266 */     this.tabs++;
/* 2267 */     println("import sys");
/* 2268 */     println("import antlr");
/* 2269 */     println("import " + str);
/* 2270 */     println("");
/* 2271 */     println("### create lexer - shall read from stdin");
/* 2272 */     println("try:");
/* 2273 */     this.tabs++;
/* 2274 */     println("for token in " + str + ".Lexer():");
/* 2275 */     this.tabs++;
/* 2276 */     println("print token");
/* 2277 */     println("");
/* 2278 */     this.tabs--;
/* 2279 */     this.tabs--;
/* 2280 */     println("except antlr.TokenStreamException, e:");
/* 2281 */     this.tabs++;
/* 2282 */     println("print \"error: exception caught while lexing: \", e");
/* 2283 */     this.tabs--;
/* 2284 */     this.tabs--;
/*      */   }
/*      */ 
/*      */   
/*      */   private void genLiteralsTest() {
/* 2289 */     println("### option { testLiterals=true } ");
/* 2290 */     println("_ttype = self.testLiteralsTable(_ttype)");
/*      */   }
/*      */   
/*      */   private void genLiteralsTestForPartialToken() {
/* 2294 */     println("_ttype = self.testLiteralsTable(self.text.getString(), _begin, self.text.length()-_begin, _ttype)");
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genMatch(BitSet paramBitSet) {}
/*      */   
/*      */   protected void genMatch(GrammarAtom paramGrammarAtom) {
/* 2301 */     if (paramGrammarAtom instanceof StringLiteralElement) {
/* 2302 */       if (this.grammar instanceof LexerGrammar) {
/* 2303 */         genMatchUsingAtomText(paramGrammarAtom);
/*      */       } else {
/*      */         
/* 2306 */         genMatchUsingAtomTokenType(paramGrammarAtom);
/*      */       }
/*      */     
/* 2309 */     } else if (paramGrammarAtom instanceof CharLiteralElement) {
/* 2310 */       if (this.grammar instanceof LexerGrammar) {
/* 2311 */         genMatchUsingAtomText(paramGrammarAtom);
/*      */       } else {
/*      */         
/* 2314 */         this.antlrTool.error("cannot ref character literals in grammar: " + paramGrammarAtom);
/*      */       }
/*      */     
/* 2317 */     } else if (paramGrammarAtom instanceof TokenRefElement) {
/* 2318 */       genMatchUsingAtomText(paramGrammarAtom);
/*      */     }
/* 2320 */     else if (paramGrammarAtom instanceof WildcardElement) {
/* 2321 */       gen((WildcardElement)paramGrammarAtom);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genMatchUsingAtomText(GrammarAtom paramGrammarAtom) {
/* 2327 */     String str = "";
/* 2328 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 2329 */       str = "_t,";
/*      */     }
/*      */ 
/*      */     
/* 2333 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramGrammarAtom.getAutoGenType() == 3))
/*      */     {
/*      */       
/* 2336 */       println("_saveIndex = self.text.length()");
/*      */     }
/*      */ 
/*      */     
/* 2340 */     print(paramGrammarAtom.not ? "self.matchNot(" : "self.match(");
/* 2341 */     _print(str);
/*      */ 
/*      */     
/* 2344 */     if (paramGrammarAtom.atomText.equals("EOF")) {
/*      */       
/* 2346 */       _print("EOF_TYPE");
/*      */     } else {
/*      */       
/* 2349 */       _print(paramGrammarAtom.atomText);
/*      */     } 
/* 2351 */     _println(")");
/*      */     
/* 2353 */     if (this.grammar instanceof LexerGrammar && (!this.saveText || paramGrammarAtom.getAutoGenType() == 3)) {
/* 2354 */       println("self.text.setLength(_saveIndex)");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genMatchUsingAtomTokenType(GrammarAtom paramGrammarAtom) {
/* 2360 */     String str1 = "";
/* 2361 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 2362 */       str1 = "_t,";
/*      */     }
/*      */ 
/*      */     
/* 2366 */     Object object = null;
/* 2367 */     String str2 = str1 + getValueString(paramGrammarAtom.getType(), true);
/*      */ 
/*      */     
/* 2370 */     println((paramGrammarAtom.not ? "self.matchNot(" : "self.match(") + str2 + ")");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genNextToken() {
/* 2381 */     boolean bool = false;
/* 2382 */     for (byte b1 = 0; b1 < this.grammar.rules.size(); b1++) {
/* 2383 */       RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.rules.elementAt(b1);
/* 2384 */       if (ruleSymbol1.isDefined() && ruleSymbol1.access.equals("public")) {
/* 2385 */         bool = true;
/*      */         break;
/*      */       } 
/*      */     } 
/* 2389 */     if (!bool) {
/* 2390 */       println("");
/* 2391 */       println("def nextToken(self): ");
/* 2392 */       this.tabs++;
/* 2393 */       println("try:");
/* 2394 */       this.tabs++;
/* 2395 */       println("self.uponEOF()");
/* 2396 */       this.tabs--;
/* 2397 */       println("except antlr.CharStreamIOException, csioe:");
/* 2398 */       this.tabs++;
/* 2399 */       println("raise antlr.TokenStreamIOException(csioe.io)");
/* 2400 */       this.tabs--;
/* 2401 */       println("except antlr.CharStreamException, cse:");
/* 2402 */       this.tabs++;
/* 2403 */       println("raise antlr.TokenStreamException(str(cse))");
/* 2404 */       this.tabs--;
/* 2405 */       println("return antlr.CommonToken(type=EOF_TYPE, text=\"\")");
/* 2406 */       this.tabs--;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2411 */     RuleBlock ruleBlock = MakeGrammar.createNextTokenRule(this.grammar, this.grammar.rules, "nextToken");
/*      */ 
/*      */ 
/*      */     
/* 2415 */     RuleSymbol ruleSymbol = new RuleSymbol("mnextToken");
/* 2416 */     ruleSymbol.setDefined();
/* 2417 */     ruleSymbol.setBlock(ruleBlock);
/* 2418 */     ruleSymbol.access = "private";
/* 2419 */     this.grammar.define(ruleSymbol);
/*      */     
/* 2421 */     boolean bool1 = this.grammar.theLLkAnalyzer.deterministic(ruleBlock);
/*      */ 
/*      */     
/* 2424 */     String str1 = null;
/* 2425 */     if (((LexerGrammar)this.grammar).filterMode) {
/* 2426 */       str1 = ((LexerGrammar)this.grammar).filterRule;
/*      */     }
/*      */     
/* 2429 */     println("");
/* 2430 */     println("def nextToken(self):");
/* 2431 */     this.tabs++;
/* 2432 */     println("while True:");
/* 2433 */     this.tabs++;
/* 2434 */     println("try: ### try again ..");
/* 2435 */     this.tabs++;
/* 2436 */     println("while True:");
/*      */     
/* 2438 */     int i = ++this.tabs;
/* 2439 */     println("_token = None");
/* 2440 */     println("_ttype = INVALID_TYPE");
/* 2441 */     if (((LexerGrammar)this.grammar).filterMode) {
/*      */       
/* 2443 */       println("self.setCommitToPath(False)");
/* 2444 */       if (str1 != null) {
/*      */ 
/*      */         
/* 2447 */         if (!this.grammar.isDefined(CodeGenerator.encodeLexerRuleName(str1))) {
/* 2448 */           this.grammar.antlrTool.error("Filter rule " + str1 + " does not exist in this lexer");
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 2453 */           RuleSymbol ruleSymbol1 = (RuleSymbol)this.grammar.getSymbol(CodeGenerator.encodeLexerRuleName(str1));
/*      */           
/* 2455 */           if (!ruleSymbol1.isDefined()) {
/* 2456 */             this.grammar.antlrTool.error("Filter rule " + str1 + " does not exist in this lexer");
/*      */           
/*      */           }
/* 2459 */           else if (ruleSymbol1.access.equals("public")) {
/* 2460 */             this.grammar.antlrTool.error("Filter rule " + str1 + " must be protected");
/*      */           } 
/*      */         } 
/*      */         
/* 2464 */         println("_m = self.mark()");
/*      */       } 
/*      */     } 
/* 2467 */     println("self.resetText()");
/*      */     
/* 2469 */     println("try: ## for char stream error handling");
/*      */     
/* 2471 */     i = ++this.tabs;
/*      */ 
/*      */     
/* 2474 */     println("try: ##for lexical error handling");
/*      */     
/* 2476 */     i = ++this.tabs;
/*      */ 
/*      */ 
/*      */     
/* 2480 */     for (byte b2 = 0; b2 < ruleBlock.getAlternatives().size(); b2++) {
/*      */       
/* 2482 */       Alternative alternative = ruleBlock.getAlternativeAt(b2);
/* 2483 */       if (alternative.cache[1].containsEpsilon()) {
/*      */ 
/*      */         
/* 2486 */         RuleRefElement ruleRefElement = (RuleRefElement)alternative.head;
/* 2487 */         String str = CodeGenerator.decodeLexerRuleName(ruleRefElement.targetRule);
/* 2488 */         this.antlrTool.warning("public lexical rule " + str + " is optional (can match \"nothing\")");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2493 */     String str2 = System.getProperty("line.separator");
/*      */ 
/*      */     
/* 2496 */     PythonBlockFinishingInfo pythonBlockFinishingInfo = genCommonBlock(ruleBlock, false);
/*      */ 
/*      */ 
/*      */     
/* 2500 */     String str3 = "";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2506 */     if (((LexerGrammar)this.grammar).filterMode) {
/*      */ 
/*      */       
/* 2509 */       if (str1 == null)
/*      */       {
/*      */         
/* 2512 */         str3 = str3 + "self.filterdefault(self.LA(1))";
/*      */       }
/*      */       else
/*      */       {
/* 2516 */         str3 = str3 + "self.filterdefault(self.LA(1), self.m" + str1 + ", False)";
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 2528 */       str3 = "self.default(self.LA(1))";
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2533 */     genBlockFinish1(pythonBlockFinishingInfo, str3);
/*      */ 
/*      */     
/* 2536 */     this.tabs = i;
/*      */ 
/*      */     
/* 2539 */     if (((LexerGrammar)this.grammar).filterMode && str1 != null) {
/* 2540 */       println("self.commit()");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2546 */     println("if not self._returnToken:");
/* 2547 */     this.tabs++;
/* 2548 */     println("raise antlr.TryAgain ### found SKIP token");
/* 2549 */     this.tabs--;
/*      */ 
/*      */ 
/*      */     
/* 2553 */     if (((LexerGrammar)this.grammar).getTestLiterals()) {
/*      */       
/* 2555 */       println("### option { testLiterals=true } ");
/*      */       
/* 2557 */       println("self.testForLiteral(self._returnToken)");
/*      */     } 
/*      */ 
/*      */     
/* 2561 */     println("### return token to caller");
/* 2562 */     println("return self._returnToken");
/*      */ 
/*      */     
/* 2565 */     this.tabs--;
/* 2566 */     println("### handle lexical errors ....");
/* 2567 */     println("except antlr.RecognitionException, e:");
/* 2568 */     this.tabs++;
/* 2569 */     if (((LexerGrammar)this.grammar).filterMode)
/*      */     {
/* 2571 */       if (str1 == null) {
/*      */         
/* 2573 */         println("if not self.getCommitToPath():");
/* 2574 */         this.tabs++;
/* 2575 */         println("self.consume()");
/* 2576 */         println("raise antlr.TryAgain()");
/* 2577 */         this.tabs--;
/*      */       }
/*      */       else {
/*      */         
/* 2581 */         println("if not self.getCommitToPath(): ");
/* 2582 */         this.tabs++;
/* 2583 */         println("self.rewind(_m)");
/* 2584 */         println("self.resetText()");
/* 2585 */         println("try:");
/* 2586 */         this.tabs++;
/* 2587 */         println("self.m" + str1 + "(False)");
/* 2588 */         this.tabs--;
/* 2589 */         println("except antlr.RecognitionException, ee:");
/* 2590 */         this.tabs++;
/* 2591 */         println("### horrendous failure: error in filter rule");
/* 2592 */         println("self.reportError(ee)");
/* 2593 */         println("self.consume()");
/* 2594 */         this.tabs--;
/* 2595 */         println("raise antlr.TryAgain()");
/* 2596 */         this.tabs--;
/*      */       } 
/*      */     }
/* 2599 */     if (ruleBlock.getDefaultErrorHandler()) {
/* 2600 */       println("self.reportError(e)");
/* 2601 */       println("self.consume()");
/*      */     }
/*      */     else {
/*      */       
/* 2605 */       println("raise antlr.TokenStreamRecognitionException(e)");
/*      */     } 
/* 2607 */     this.tabs--;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2612 */     this.tabs--;
/* 2613 */     println("### handle char stream errors ...");
/* 2614 */     println("except antlr.CharStreamException,cse:");
/* 2615 */     this.tabs++;
/* 2616 */     println("if isinstance(cse, antlr.CharStreamIOException):");
/* 2617 */     this.tabs++;
/* 2618 */     println("raise antlr.TokenStreamIOException(cse.io)");
/* 2619 */     this.tabs--;
/* 2620 */     println("else:");
/* 2621 */     this.tabs++;
/* 2622 */     println("raise antlr.TokenStreamException(str(cse))");
/* 2623 */     this.tabs--;
/* 2624 */     this.tabs--;
/*      */ 
/*      */ 
/*      */     
/* 2628 */     this.tabs--;
/*      */ 
/*      */ 
/*      */     
/* 2632 */     this.tabs--;
/*      */     
/* 2634 */     println("except antlr.TryAgain:");
/* 2635 */     this.tabs++;
/* 2636 */     println("pass");
/* 2637 */     this.tabs--;
/*      */     
/* 2639 */     this.tabs--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genRule(RuleSymbol paramRuleSymbol, boolean paramBoolean, int paramInt) {
/* 2664 */     this.tabs = 1;
/* 2665 */     if (!paramRuleSymbol.isDefined()) {
/* 2666 */       this.antlrTool.error("undefined rule: " + paramRuleSymbol.getId());
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2671 */     RuleBlock ruleBlock = paramRuleSymbol.getBlock();
/*      */     
/* 2673 */     this.currentRule = ruleBlock;
/* 2674 */     this.currentASTResult = paramRuleSymbol.getId();
/*      */ 
/*      */     
/* 2677 */     this.declaredASTVariables.clear();
/*      */ 
/*      */     
/* 2680 */     boolean bool = this.genAST;
/* 2681 */     this.genAST = (this.genAST && ruleBlock.getAutoGen());
/*      */ 
/*      */     
/* 2684 */     this.saveText = ruleBlock.getAutoGen();
/*      */ 
/*      */     
/* 2687 */     genJavadocComment(paramRuleSymbol);
/*      */ 
/*      */     
/* 2690 */     print("def " + paramRuleSymbol.getId() + "(");
/*      */ 
/*      */     
/* 2693 */     _print(this.commonExtraParams);
/* 2694 */     if (this.commonExtraParams.length() != 0 && ruleBlock.argAction != null) {
/* 2695 */       _print(",");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2700 */     if (ruleBlock.argAction != null) {
/*      */       
/* 2702 */       _println("");
/* 2703 */       this.tabs++;
/* 2704 */       println(ruleBlock.argAction);
/* 2705 */       this.tabs--;
/* 2706 */       print("):");
/*      */     }
/*      */     else {
/*      */       
/* 2710 */       _print("):");
/*      */     } 
/*      */     
/* 2713 */     println("");
/* 2714 */     this.tabs++;
/*      */ 
/*      */     
/* 2717 */     if (ruleBlock.returnAction != null) {
/* 2718 */       if (ruleBlock.returnAction.indexOf('=') >= 0) {
/* 2719 */         println(ruleBlock.returnAction);
/*      */       } else {
/*      */         
/* 2722 */         println(extractIdOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + " = None");
/*      */       } 
/*      */     }
/*      */     
/* 2726 */     println(this.commonLocalVars);
/*      */     
/* 2728 */     if (this.grammar.traceRules) {
/* 2729 */       if (this.grammar instanceof TreeWalkerGrammar) {
/* 2730 */         println("self.traceIn(\"" + paramRuleSymbol.getId() + "\",_t)");
/*      */       } else {
/*      */         
/* 2733 */         println("self.traceIn(\"" + paramRuleSymbol.getId() + "\")");
/*      */       } 
/*      */     }
/*      */     
/* 2737 */     if (this.grammar instanceof LexerGrammar) {
/*      */ 
/*      */       
/* 2740 */       if (paramRuleSymbol.getId().equals("mEOF")) {
/* 2741 */         println("_ttype = EOF_TYPE");
/*      */       } else {
/* 2743 */         println("_ttype = " + paramRuleSymbol.getId().substring(1));
/* 2744 */       }  println("_saveIndex = 0");
/*      */     } 
/*      */ 
/*      */     
/* 2748 */     if (this.grammar.debuggingOutput) {
/* 2749 */       if (this.grammar instanceof ParserGrammar) {
/* 2750 */         println("self.fireEnterRule(" + paramInt + ", 0)");
/* 2751 */       } else if (this.grammar instanceof LexerGrammar) {
/* 2752 */         println("self.fireEnterRule(" + paramInt + ", _ttype)");
/*      */       } 
/*      */     }
/* 2755 */     if (this.grammar.debuggingOutput || this.grammar.traceRules) {
/* 2756 */       println("try: ### debugging");
/* 2757 */       this.tabs++;
/*      */     } 
/*      */ 
/*      */     
/* 2761 */     if (this.grammar instanceof TreeWalkerGrammar) {
/*      */       
/* 2763 */       println(paramRuleSymbol.getId() + "_AST_in = None");
/* 2764 */       println("if _t != antlr.ASTNULL:");
/* 2765 */       this.tabs++;
/* 2766 */       println(paramRuleSymbol.getId() + "_AST_in = _t");
/* 2767 */       this.tabs--;
/*      */     } 
/* 2769 */     if (this.grammar.buildAST) {
/*      */ 
/*      */       
/* 2772 */       println("self.returnAST = None");
/* 2773 */       println("currentAST = antlr.ASTPair()");
/*      */       
/* 2775 */       println(paramRuleSymbol.getId() + "_AST = None");
/*      */     } 
/*      */     
/* 2778 */     genBlockPreamble(ruleBlock);
/* 2779 */     genBlockInitAction(ruleBlock);
/*      */ 
/*      */     
/* 2782 */     ExceptionSpec exceptionSpec = ruleBlock.findExceptionSpec("");
/*      */ 
/*      */     
/* 2785 */     if (exceptionSpec != null || ruleBlock.getDefaultErrorHandler()) {
/* 2786 */       println("try:      ## for error handling");
/* 2787 */       this.tabs++;
/*      */     } 
/* 2789 */     int i = this.tabs;
/*      */     
/* 2791 */     if (ruleBlock.alternatives.size() == 1) {
/*      */ 
/*      */       
/* 2794 */       Alternative alternative = ruleBlock.getAlternativeAt(0);
/* 2795 */       String str = alternative.semPred;
/* 2796 */       if (str != null)
/* 2797 */         genSemPred(str, this.currentRule.line); 
/* 2798 */       if (alternative.synPred != null)
/*      */       {
/* 2800 */         this.antlrTool.warning("Syntactic predicate ignored for single alternative", this.grammar.getFilename(), alternative.synPred.getLine(), alternative.synPred.getColumn());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2807 */       genAlt(alternative, ruleBlock);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2812 */       boolean bool1 = this.grammar.theLLkAnalyzer.deterministic(ruleBlock);
/*      */       
/* 2814 */       PythonBlockFinishingInfo pythonBlockFinishingInfo = genCommonBlock(ruleBlock, false);
/* 2815 */       genBlockFinish(pythonBlockFinishingInfo, this.throwNoViable);
/*      */     } 
/* 2817 */     this.tabs = i;
/*      */ 
/*      */     
/* 2820 */     if (exceptionSpec != null || ruleBlock.getDefaultErrorHandler()) {
/*      */       
/* 2822 */       this.tabs--;
/* 2823 */       println("");
/*      */     } 
/*      */ 
/*      */     
/* 2827 */     if (exceptionSpec != null) {
/* 2828 */       genErrorHandler(exceptionSpec);
/*      */     }
/* 2830 */     else if (ruleBlock.getDefaultErrorHandler()) {
/*      */       
/* 2832 */       println("except " + this.exceptionThrown + ", ex:");
/* 2833 */       this.tabs++;
/*      */       
/* 2835 */       if (this.grammar.hasSyntacticPredicate) {
/* 2836 */         println("if not self.inputState.guessing:");
/* 2837 */         this.tabs++;
/*      */       } 
/* 2839 */       println("self.reportError(ex)");
/* 2840 */       if (!(this.grammar instanceof TreeWalkerGrammar)) {
/*      */         
/* 2842 */         Lookahead lookahead = this.grammar.theLLkAnalyzer.FOLLOW(1, ruleBlock.endNode);
/* 2843 */         String str = getBitsetName(markBitsetForGen(lookahead.fset));
/* 2844 */         println("self.consume()");
/* 2845 */         println("self.consumeUntil(" + str + ")");
/*      */       }
/*      */       else {
/*      */         
/* 2849 */         println("if _t:");
/* 2850 */         this.tabs++;
/* 2851 */         println("_t = _t.getNextSibling()");
/* 2852 */         this.tabs--;
/*      */       } 
/* 2854 */       if (this.grammar.hasSyntacticPredicate) {
/* 2855 */         this.tabs--;
/*      */         
/* 2857 */         println("else:");
/* 2858 */         this.tabs++;
/* 2859 */         println("raise ex");
/* 2860 */         this.tabs--;
/*      */       } 
/*      */       
/* 2863 */       this.tabs--;
/* 2864 */       println("");
/*      */     } 
/*      */ 
/*      */     
/* 2868 */     if (this.grammar.buildAST) {
/* 2869 */       println("self.returnAST = " + paramRuleSymbol.getId() + "_AST");
/*      */     }
/*      */ 
/*      */     
/* 2873 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 2874 */       println("self._retTree = _t");
/*      */     }
/*      */ 
/*      */     
/* 2878 */     if (ruleBlock.getTestLiterals()) {
/* 2879 */       if (paramRuleSymbol.access.equals("protected")) {
/* 2880 */         genLiteralsTestForPartialToken();
/*      */       } else {
/*      */         
/* 2883 */         genLiteralsTest();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2888 */     if (this.grammar instanceof LexerGrammar)
/*      */     {
/* 2890 */       println("self.set_return_token(_createToken, _token, _ttype, _begin)");
/*      */     }
/*      */     
/* 2893 */     if (ruleBlock.returnAction != null)
/*      */     {
/*      */ 
/*      */       
/* 2897 */       println("return " + extractIdOfAction(ruleBlock.returnAction, ruleBlock.getLine(), ruleBlock.getColumn()) + "");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2908 */     if (this.grammar.debuggingOutput || this.grammar.traceRules) {
/* 2909 */       this.tabs--;
/* 2910 */       println("finally:  ### debugging");
/* 2911 */       this.tabs++;
/*      */ 
/*      */       
/* 2914 */       if (this.grammar.debuggingOutput)
/* 2915 */         if (this.grammar instanceof ParserGrammar) {
/* 2916 */           println("self.fireExitRule(" + paramInt + ", 0)");
/* 2917 */         } else if (this.grammar instanceof LexerGrammar) {
/* 2918 */           println("self.fireExitRule(" + paramInt + ", _ttype)");
/*      */         }  
/* 2920 */       if (this.grammar.traceRules) {
/* 2921 */         if (this.grammar instanceof TreeWalkerGrammar) {
/* 2922 */           println("self.traceOut(\"" + paramRuleSymbol.getId() + "\", _t)");
/*      */         } else {
/*      */           
/* 2925 */           println("self.traceOut(\"" + paramRuleSymbol.getId() + "\")");
/*      */         } 
/*      */       }
/* 2928 */       this.tabs--;
/*      */     } 
/* 2930 */     this.tabs--;
/* 2931 */     println("");
/*      */ 
/*      */     
/* 2934 */     this.genAST = bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void GenRuleInvocation(RuleRefElement paramRuleRefElement) {
/* 2942 */     _print("self." + paramRuleRefElement.targetRule + "(");
/*      */ 
/*      */     
/* 2945 */     if (this.grammar instanceof LexerGrammar) {
/*      */       
/* 2947 */       if (paramRuleRefElement.getLabel() != null) {
/* 2948 */         _print("True");
/*      */       } else {
/*      */         
/* 2951 */         _print("False");
/*      */       } 
/* 2953 */       if (this.commonExtraArgs.length() != 0 || paramRuleRefElement.args != null) {
/* 2954 */         _print(", ");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 2959 */     _print(this.commonExtraArgs);
/* 2960 */     if (this.commonExtraArgs.length() != 0 && paramRuleRefElement.args != null) {
/* 2961 */       _print(", ");
/*      */     }
/*      */ 
/*      */     
/* 2965 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/* 2966 */     if (paramRuleRefElement.args != null) {
/*      */       
/* 2968 */       ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 2969 */       String str = processActionForSpecialSymbols(paramRuleRefElement.args, 0, this.currentRule, actionTransInfo);
/* 2970 */       if (actionTransInfo.assignToRoot || actionTransInfo.refRuleRoot != null) {
/* 2971 */         this.antlrTool.error("Arguments of rule reference '" + paramRuleRefElement.targetRule + "' cannot set or ref #" + this.currentRule.getRuleName(), this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */       }
/*      */       
/* 2974 */       _print(str);
/*      */ 
/*      */       
/* 2977 */       if (ruleSymbol.block.argAction == null) {
/* 2978 */         this.antlrTool.warning("Rule '" + paramRuleRefElement.targetRule + "' accepts no arguments", this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 2984 */     else if (ruleSymbol.block.argAction != null) {
/* 2985 */       this.antlrTool.warning("Missing parameters on reference to rule " + paramRuleRefElement.targetRule, this.grammar.getFilename(), paramRuleRefElement.getLine(), paramRuleRefElement.getColumn());
/*      */     } 
/*      */     
/* 2988 */     _println(")");
/*      */ 
/*      */     
/* 2991 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 2992 */       println("_t = self._retTree");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genSemPred(String paramString, int paramInt) {
/* 2998 */     ActionTransInfo actionTransInfo = new ActionTransInfo();
/* 2999 */     paramString = processActionForSpecialSymbols(paramString, paramInt, this.currentRule, actionTransInfo);
/*      */ 
/*      */     
/* 3002 */     String str = this.charFormatter.escapeString(paramString);
/*      */ 
/*      */ 
/*      */     
/* 3006 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar))
/*      */     {
/* 3008 */       paramString = "fireSemanticPredicateEvaluated(antlr.debug.SemanticPredicateEvent.VALIDATING," + addSemPred(str) + ", " + paramString + ")";
/*      */     }
/*      */ 
/*      */     
/* 3012 */     println("if not " + paramString + ":");
/* 3013 */     this.tabs++;
/* 3014 */     println("raise antlr.SemanticException(\"" + str + "\")");
/* 3015 */     this.tabs--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genSemPredMap() {
/* 3022 */     Enumeration enumeration = this.semPreds.elements();
/* 3023 */     println("_semPredNames = [");
/* 3024 */     this.tabs++;
/* 3025 */     while (enumeration.hasMoreElements()) {
/* 3026 */       println("\"" + enumeration.nextElement() + "\",");
/*      */     }
/* 3028 */     this.tabs--;
/* 3029 */     println("]");
/*      */   }
/*      */   
/*      */   protected void genSynPred(SynPredBlock paramSynPredBlock, String paramString) {
/* 3033 */     if (this.DEBUG_CODE_GENERATOR) System.out.println("gen=>(" + paramSynPredBlock + ")");
/*      */ 
/*      */     
/* 3036 */     println("synPredMatched" + paramSynPredBlock.ID + " = False");
/*      */     
/* 3038 */     println("if " + paramString + ":");
/* 3039 */     this.tabs++;
/*      */ 
/*      */     
/* 3042 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3043 */       println("_t" + paramSynPredBlock.ID + " = _t");
/*      */     } else {
/*      */       
/* 3046 */       println("_m" + paramSynPredBlock.ID + " = self.mark()");
/*      */     } 
/*      */ 
/*      */     
/* 3050 */     println("synPredMatched" + paramSynPredBlock.ID + " = True");
/* 3051 */     println("self.inputState.guessing += 1");
/*      */ 
/*      */     
/* 3054 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar))
/*      */     {
/* 3056 */       println("self.fireSyntacticPredicateStarted()");
/*      */     }
/*      */     
/* 3059 */     this.syntacticPredLevel++;
/* 3060 */     println("try:");
/* 3061 */     this.tabs++;
/* 3062 */     gen(paramSynPredBlock);
/* 3063 */     this.tabs--;
/* 3064 */     println("except " + this.exceptionThrown + ", pe:");
/* 3065 */     this.tabs++;
/* 3066 */     println("synPredMatched" + paramSynPredBlock.ID + " = False");
/* 3067 */     this.tabs--;
/*      */ 
/*      */     
/* 3070 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3071 */       println("_t = _t" + paramSynPredBlock.ID + "");
/*      */     } else {
/*      */       
/* 3074 */       println("self.rewind(_m" + paramSynPredBlock.ID + ")");
/*      */     } 
/*      */     
/* 3077 */     println("self.inputState.guessing -= 1");
/*      */ 
/*      */     
/* 3080 */     if (this.grammar.debuggingOutput && (this.grammar instanceof ParserGrammar || this.grammar instanceof LexerGrammar)) {
/*      */       
/* 3082 */       println("if synPredMatched" + paramSynPredBlock.ID + ":");
/* 3083 */       this.tabs++;
/* 3084 */       println("self.fireSyntacticPredicateSucceeded()");
/* 3085 */       this.tabs--;
/* 3086 */       println("else:");
/* 3087 */       this.tabs++;
/* 3088 */       println("self.fireSyntacticPredicateFailed()");
/* 3089 */       this.tabs--;
/*      */     } 
/*      */     
/* 3092 */     this.syntacticPredLevel--;
/* 3093 */     this.tabs--;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3098 */     println("if synPredMatched" + paramSynPredBlock.ID + ":");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void genTokenStrings() {
/* 3112 */     int i = this.tabs;
/* 3113 */     this.tabs = 0;
/*      */     
/* 3115 */     println("");
/* 3116 */     println("_tokenNames = [");
/* 3117 */     this.tabs++;
/*      */ 
/*      */ 
/*      */     
/* 3121 */     Vector vector = this.grammar.tokenManager.getVocabulary();
/* 3122 */     for (byte b = 0; b < vector.size(); b++) {
/* 3123 */       String str = (String)vector.elementAt(b);
/* 3124 */       if (str == null) {
/* 3125 */         str = "<" + String.valueOf(b) + ">";
/*      */       }
/* 3127 */       if (!str.startsWith("\"") && !str.startsWith("<")) {
/* 3128 */         TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/* 3129 */         if (tokenSymbol != null && tokenSymbol.getParaphrase() != null) {
/* 3130 */           str = StringUtils.stripFrontBack(tokenSymbol.getParaphrase(), "\"", "\"");
/*      */         }
/*      */       } 
/* 3133 */       print(this.charFormatter.literalString(str));
/* 3134 */       if (b != vector.size() - 1) {
/* 3135 */         _print(", ");
/*      */       }
/* 3137 */       _println("");
/*      */     } 
/*      */ 
/*      */     
/* 3141 */     this.tabs--;
/* 3142 */     println("]");
/* 3143 */     this.tabs = i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genTokenASTNodeMap() {
/* 3150 */     println("");
/* 3151 */     println("def buildTokenTypeASTClassMap(self):");
/*      */ 
/*      */     
/* 3154 */     this.tabs++;
/* 3155 */     boolean bool = false;
/* 3156 */     byte b1 = 0;
/*      */     
/* 3158 */     Vector vector = this.grammar.tokenManager.getVocabulary();
/* 3159 */     for (byte b2 = 0; b2 < vector.size(); b2++) {
/* 3160 */       String str = (String)vector.elementAt(b2);
/* 3161 */       if (str != null) {
/* 3162 */         TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/* 3163 */         if (tokenSymbol != null && tokenSymbol.getASTNodeType() != null) {
/* 3164 */           b1++;
/* 3165 */           if (!bool) {
/*      */             
/* 3167 */             println("self.tokenTypeToASTClassMap = {}");
/* 3168 */             bool = true;
/*      */           } 
/* 3170 */           println("self.tokenTypeToASTClassMap[" + tokenSymbol.getTokenType() + "] = " + tokenSymbol.getASTNodeType());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3179 */     if (b1 == 0) {
/* 3180 */       println("self.tokenTypeToASTClassMap = None");
/*      */     }
/* 3182 */     this.tabs--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void genTokenTypes(TokenManager paramTokenManager) throws IOException {
/* 3193 */     this.tabs = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3201 */     Vector vector = paramTokenManager.getVocabulary();
/*      */ 
/*      */     
/* 3204 */     println("SKIP                = antlr.SKIP");
/* 3205 */     println("INVALID_TYPE        = antlr.INVALID_TYPE");
/* 3206 */     println("EOF_TYPE            = antlr.EOF_TYPE");
/* 3207 */     println("EOF                 = antlr.EOF");
/* 3208 */     println("NULL_TREE_LOOKAHEAD = antlr.NULL_TREE_LOOKAHEAD");
/* 3209 */     println("MIN_USER_TYPE       = antlr.MIN_USER_TYPE");
/*      */     
/* 3211 */     for (byte b = 4; b < vector.size(); b++) {
/*      */       
/* 3213 */       String str = (String)vector.elementAt(b);
/* 3214 */       if (str != null)
/*      */       {
/* 3216 */         if (str.startsWith("\"")) {
/*      */ 
/*      */           
/* 3219 */           StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)paramTokenManager.getTokenSymbol(str);
/* 3220 */           if (stringLiteralSymbol == null) {
/* 3221 */             this.antlrTool.panic("String literal " + str + " not in symbol table");
/*      */           }
/* 3223 */           if (stringLiteralSymbol.label != null) {
/*      */             
/* 3225 */             println(stringLiteralSymbol.label + " = " + b);
/*      */           }
/*      */           else {
/*      */             
/* 3229 */             String str1 = mangleLiteral(str);
/* 3230 */             if (str1 != null)
/*      */             {
/* 3232 */               println(str1 + " = " + b);
/*      */               
/* 3234 */               stringLiteralSymbol.label = str1;
/*      */             }
/*      */             else
/*      */             {
/* 3238 */               println("### " + str + " = " + b);
/*      */             }
/*      */           
/*      */           } 
/* 3242 */         } else if (!str.startsWith("<")) {
/* 3243 */           println(str + " = " + b);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 3249 */     this.tabs--;
/*      */     
/* 3251 */     exitIfError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(Vector paramVector) {
/* 3258 */     if (paramVector.size() == 0) {
/* 3259 */       return "";
/*      */     }
/* 3261 */     StringBuffer stringBuffer = new StringBuffer();
/* 3262 */     stringBuffer.append("antlr.make(");
/* 3263 */     for (byte b = 0; b < paramVector.size(); b++) {
/* 3264 */       stringBuffer.append(paramVector.elementAt(b));
/* 3265 */       if (b + 1 < paramVector.size()) {
/* 3266 */         stringBuffer.append(", ");
/*      */       }
/*      */     } 
/* 3269 */     stringBuffer.append(")");
/* 3270 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(GrammarAtom paramGrammarAtom, String paramString) {
/* 3279 */     if (paramGrammarAtom != null && paramGrammarAtom.getASTNodeType() != null)
/*      */     {
/*      */       
/* 3282 */       return "self.astFactory.create(" + paramString + ", " + paramGrammarAtom.getASTNodeType() + ")";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3287 */     return getASTCreateString(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getASTCreateString(String paramString) {
/* 3300 */     if (paramString == null) {
/* 3301 */       paramString = "";
/*      */     }
/* 3303 */     byte b = 0; int i;
/* 3304 */     for (i = 0; i < paramString.length(); i++) {
/* 3305 */       if (paramString.charAt(i) == ',') {
/* 3306 */         b++;
/*      */       }
/*      */     } 
/* 3309 */     if (b < 2) {
/* 3310 */       i = paramString.indexOf(',');
/* 3311 */       int j = paramString.lastIndexOf(',');
/* 3312 */       String str = paramString;
/* 3313 */       if (b > 0) {
/* 3314 */         str = paramString.substring(0, i);
/*      */       }
/* 3316 */       TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbol(str);
/* 3317 */       if (tokenSymbol != null) {
/* 3318 */         String str1 = tokenSymbol.getASTNodeType();
/* 3319 */         String str2 = "";
/* 3320 */         if (b == 0)
/*      */         {
/* 3322 */           str2 = ", \"\"";
/*      */         }
/* 3324 */         if (str1 != null) {
/* 3325 */           return "self.astFactory.create(" + paramString + str2 + ", " + str1 + ")";
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 3330 */       if (this.labeledElementASTType.equals("AST")) {
/* 3331 */         return "self.astFactory.create(" + paramString + ")";
/*      */       }
/* 3333 */       return "self.astFactory.create(" + paramString + ")";
/*      */     } 
/*      */ 
/*      */     
/* 3337 */     return "self.astFactory.create(" + paramString + ")";
/*      */   }
/*      */   
/*      */   protected String getLookaheadTestExpression(Lookahead[] paramArrayOfLookahead, int paramInt) {
/* 3341 */     StringBuffer stringBuffer = new StringBuffer(100);
/* 3342 */     boolean bool = true;
/*      */     
/* 3344 */     stringBuffer.append("(");
/* 3345 */     for (byte b = 1; b <= paramInt; b++) {
/* 3346 */       BitSet bitSet = (paramArrayOfLookahead[b]).fset;
/* 3347 */       if (!bool) {
/* 3348 */         stringBuffer.append(") and (");
/*      */       }
/* 3350 */       bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3355 */       if (paramArrayOfLookahead[b].containsEpsilon()) {
/* 3356 */         stringBuffer.append("True");
/*      */       } else {
/*      */         
/* 3359 */         stringBuffer.append(getLookaheadTestTerm(b, bitSet));
/*      */       } 
/*      */     } 
/*      */     
/* 3363 */     stringBuffer.append(")");
/* 3364 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLookaheadTestExpression(Alternative paramAlternative, int paramInt) {
/* 3373 */     int i = paramAlternative.lookaheadDepth;
/* 3374 */     if (i == Integer.MAX_VALUE)
/*      */     {
/*      */ 
/*      */       
/* 3378 */       i = this.grammar.maxk;
/*      */     }
/*      */     
/* 3381 */     if (paramInt == 0)
/*      */     {
/*      */ 
/*      */       
/* 3385 */       return "True";
/*      */     }
/*      */     
/* 3388 */     return getLookaheadTestExpression(paramAlternative.cache, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLookaheadTestTerm(int paramInt, BitSet paramBitSet) {
/* 3401 */     String str1 = lookaheadString(paramInt);
/*      */ 
/*      */     
/* 3404 */     int[] arrayOfInt = paramBitSet.toArray();
/* 3405 */     if (elementsAreRange(arrayOfInt)) {
/* 3406 */       return getRangeExpression(paramInt, arrayOfInt);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3412 */     int i = paramBitSet.degree();
/* 3413 */     if (i == 0) {
/* 3414 */       return "True";
/*      */     }
/*      */     
/* 3417 */     if (i >= this.bitsetTestThreshold) {
/* 3418 */       int j = markBitsetForGen(paramBitSet);
/* 3419 */       return getBitsetName(j) + ".member(" + str1 + ")";
/*      */     } 
/*      */ 
/*      */     
/* 3423 */     StringBuffer stringBuffer = new StringBuffer();
/* 3424 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */       
/* 3426 */       String str = getValueString(arrayOfInt[b], true);
/*      */ 
/*      */       
/* 3429 */       if (b > 0) stringBuffer.append(" or "); 
/* 3430 */       stringBuffer.append(str1);
/* 3431 */       stringBuffer.append("==");
/* 3432 */       stringBuffer.append(str);
/*      */     } 
/* 3434 */     String str2 = stringBuffer.toString();
/* 3435 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRangeExpression(int paramInt, int[] paramArrayOfint) {
/* 3444 */     if (!elementsAreRange(paramArrayOfint)) {
/* 3445 */       this.antlrTool.panic("getRangeExpression called with non-range");
/*      */     }
/* 3447 */     int i = paramArrayOfint[0];
/* 3448 */     int j = paramArrayOfint[paramArrayOfint.length - 1];
/* 3449 */     return "(" + lookaheadString(paramInt) + " >= " + getValueString(i, true) + " and " + lookaheadString(paramInt) + " <= " + getValueString(j, true) + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getValueString(int paramInt, boolean paramBoolean) {
/*      */     String str1;
/* 3459 */     if (this.grammar instanceof LexerGrammar) {
/* 3460 */       str1 = this.charFormatter.literalChar(paramInt);
/* 3461 */       if (paramBoolean)
/* 3462 */         str1 = "u'" + str1 + "'"; 
/* 3463 */       return str1;
/*      */     } 
/*      */ 
/*      */     
/* 3467 */     TokenSymbol tokenSymbol = this.grammar.tokenManager.getTokenSymbolAt(paramInt);
/*      */ 
/*      */ 
/*      */     
/* 3471 */     if (tokenSymbol == null) {
/* 3472 */       str1 = "" + paramInt;
/* 3473 */       return str1;
/*      */     } 
/*      */     
/* 3476 */     String str2 = tokenSymbol.getId();
/* 3477 */     if (!(tokenSymbol instanceof StringLiteralSymbol)) {
/*      */       
/* 3479 */       str1 = str2;
/* 3480 */       return str1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3486 */     StringLiteralSymbol stringLiteralSymbol = (StringLiteralSymbol)tokenSymbol;
/* 3487 */     String str3 = stringLiteralSymbol.getLabel();
/* 3488 */     if (str3 != null) {
/* 3489 */       str1 = str3;
/*      */     }
/*      */     else {
/*      */       
/* 3493 */       str1 = mangleLiteral(str2);
/* 3494 */       if (str1 == null) {
/* 3495 */         str1 = String.valueOf(paramInt);
/*      */       }
/*      */     } 
/* 3498 */     return str1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean lookaheadIsEmpty(Alternative paramAlternative, int paramInt) {
/* 3503 */     int i = paramAlternative.lookaheadDepth;
/* 3504 */     if (i == Integer.MAX_VALUE) {
/* 3505 */       i = this.grammar.maxk;
/*      */     }
/* 3507 */     for (byte b = 1; b <= i && b <= paramInt; b++) {
/* 3508 */       BitSet bitSet = (paramAlternative.cache[b]).fset;
/* 3509 */       if (bitSet.degree() != 0) {
/* 3510 */         return false;
/*      */       }
/*      */     } 
/* 3513 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private String lookaheadString(int paramInt) {
/* 3518 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3519 */       return "_t.getType()";
/*      */     }
/* 3521 */     return "self.LA(" + paramInt + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String mangleLiteral(String paramString) {
/* 3531 */     String str = this.antlrTool.literalsPrefix;
/* 3532 */     for (byte b = 1; b < paramString.length() - 1; b++) {
/* 3533 */       if (!Character.isLetter(paramString.charAt(b)) && paramString.charAt(b) != '_')
/*      */       {
/* 3535 */         return null;
/*      */       }
/* 3537 */       str = str + paramString.charAt(b);
/*      */     } 
/* 3539 */     if (this.antlrTool.upperCaseMangledLiterals) {
/* 3540 */       str = str.toUpperCase();
/*      */     }
/* 3542 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String mapTreeId(String paramString, ActionTransInfo paramActionTransInfo) {
/* 3554 */     if (this.currentRule == null) return paramString;
/*      */     
/* 3556 */     boolean bool = false;
/* 3557 */     String str1 = paramString;
/* 3558 */     if (this.grammar instanceof TreeWalkerGrammar) {
/* 3559 */       if (!this.grammar.buildAST) {
/* 3560 */         bool = true;
/*      */       
/*      */       }
/* 3563 */       else if (str1.length() > 3 && str1.lastIndexOf("_in") == str1.length() - 3) {
/*      */         
/* 3565 */         str1 = str1.substring(0, str1.length() - 3);
/* 3566 */         bool = true;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3572 */     for (byte b = 0; b < this.currentRule.labeledElements.size(); b++) {
/* 3573 */       AlternativeElement alternativeElement = (AlternativeElement)this.currentRule.labeledElements.elementAt(b);
/* 3574 */       if (alternativeElement.getLabel().equals(str1)) {
/* 3575 */         return bool ? str1 : (str1 + "_AST");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3582 */     String str2 = (String)this.treeVariableMap.get(str1);
/* 3583 */     if (str2 != null) {
/* 3584 */       if (str2 == NONUNIQUE) {
/*      */         
/* 3586 */         this.antlrTool.error("Ambiguous reference to AST element " + str1 + " in rule " + this.currentRule.getRuleName());
/*      */ 
/*      */         
/* 3589 */         return null;
/*      */       } 
/* 3591 */       if (str2.equals(this.currentRule.getRuleName())) {
/*      */ 
/*      */         
/* 3594 */         this.antlrTool.error("Ambiguous reference to AST element " + str1 + " in rule " + this.currentRule.getRuleName());
/*      */         
/* 3596 */         return null;
/*      */       } 
/*      */       
/* 3599 */       return bool ? (str2 + "_in") : str2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3605 */     if (str1.equals(this.currentRule.getRuleName())) {
/* 3606 */       String str = bool ? (str1 + "_AST_in") : (str1 + "_AST");
/* 3607 */       if (paramActionTransInfo != null && 
/* 3608 */         !bool) {
/* 3609 */         paramActionTransInfo.refRuleRoot = str;
/*      */       }
/*      */       
/* 3612 */       return str;
/*      */     } 
/*      */ 
/*      */     
/* 3616 */     return str1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void mapTreeVariable(AlternativeElement paramAlternativeElement, String paramString) {
/* 3625 */     if (paramAlternativeElement instanceof TreeElement) {
/* 3626 */       mapTreeVariable(((TreeElement)paramAlternativeElement).root, paramString);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3631 */     String str = null;
/*      */ 
/*      */     
/* 3634 */     if (paramAlternativeElement.getLabel() == null) {
/* 3635 */       if (paramAlternativeElement instanceof TokenRefElement) {
/*      */         
/* 3637 */         str = ((TokenRefElement)paramAlternativeElement).atomText;
/*      */       }
/* 3639 */       else if (paramAlternativeElement instanceof RuleRefElement) {
/*      */         
/* 3641 */         str = ((RuleRefElement)paramAlternativeElement).targetRule;
/*      */       } 
/*      */     }
/*      */     
/* 3645 */     if (str != null) {
/* 3646 */       if (this.treeVariableMap.get(str) != null) {
/*      */         
/* 3648 */         this.treeVariableMap.remove(str);
/* 3649 */         this.treeVariableMap.put(str, NONUNIQUE);
/*      */       } else {
/*      */         
/* 3652 */         this.treeVariableMap.put(str, paramString);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String processActionForSpecialSymbols(String paramString, int paramInt, RuleBlock paramRuleBlock, ActionTransInfo paramActionTransInfo) {
/* 3664 */     if (paramString == null || paramString.length() == 0) {
/* 3665 */       return null;
/*      */     }
/* 3667 */     if (isEmpty(paramString)) {
/* 3668 */       return "";
/*      */     }
/*      */ 
/*      */     
/* 3672 */     if (this.grammar == null)
/*      */     {
/* 3674 */       return paramString;
/*      */     }
/*      */ 
/*      */     
/* 3678 */     ActionLexer actionLexer = new ActionLexer(paramString, paramRuleBlock, this, paramActionTransInfo);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3685 */     actionLexer.setLineOffset(paramInt);
/* 3686 */     actionLexer.setFilename(this.grammar.getFilename());
/* 3687 */     actionLexer.setTool(this.antlrTool);
/*      */     
/*      */     try {
/* 3690 */       actionLexer.mACTION(true);
/* 3691 */       paramString = actionLexer.getTokenObject().getText();
/*      */     }
/* 3693 */     catch (RecognitionException recognitionException) {
/* 3694 */       actionLexer.reportError(recognitionException);
/*      */     }
/* 3696 */     catch (TokenStreamException tokenStreamException) {
/* 3697 */       this.antlrTool.panic("Error reading action:" + paramString);
/*      */     }
/* 3699 */     catch (CharStreamException charStreamException) {
/* 3700 */       this.antlrTool.panic("Error reading action:" + paramString);
/*      */     } 
/* 3702 */     return paramString;
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isEmpty(String paramString) {
/* 3707 */     boolean bool = true;
/*      */ 
/*      */     
/* 3710 */     for (byte b = 0; bool && b < paramString.length(); b++) {
/* 3711 */       char c = paramString.charAt(b);
/* 3712 */       switch (c) {
/*      */         case '\t':
/*      */         case '\n':
/*      */         case '\f':
/*      */         case '\r':
/*      */         case ' ':
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 3722 */           bool = false;
/*      */           break;
/*      */       } 
/*      */     } 
/* 3726 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   protected String processActionCode(String paramString, int paramInt) {
/* 3731 */     if (paramString == null || isEmpty(paramString)) {
/* 3732 */       return "";
/*      */     }
/* 3734 */     CodeLexer codeLexer = new CodeLexer(paramString, this.grammar.getFilename(), paramInt, this.antlrTool);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3743 */       codeLexer.mACTION(true);
/* 3744 */       paramString = codeLexer.getTokenObject().getText();
/*      */     }
/* 3746 */     catch (RecognitionException recognitionException) {
/* 3747 */       codeLexer.reportError(recognitionException);
/*      */     }
/* 3749 */     catch (TokenStreamException tokenStreamException) {
/* 3750 */       this.antlrTool.panic("Error reading action:" + paramString);
/*      */     }
/* 3752 */     catch (CharStreamException charStreamException) {
/* 3753 */       this.antlrTool.panic("Error reading action:" + paramString);
/*      */     } 
/* 3755 */     return paramString;
/*      */   }
/*      */   
/*      */   protected void printActionCode(String paramString, int paramInt) {
/* 3759 */     paramString = processActionCode(paramString, paramInt);
/* 3760 */     printAction(paramString);
/*      */   }
/*      */   
/*      */   private void setupGrammarParameters(Grammar paramGrammar) {
/* 3764 */     if (paramGrammar instanceof ParserGrammar) {
/*      */       
/* 3766 */       this.labeledElementASTType = "";
/* 3767 */       if (paramGrammar.hasOption("ASTLabelType")) {
/*      */         
/* 3769 */         Token token = paramGrammar.getOption("ASTLabelType");
/* 3770 */         if (token != null) {
/* 3771 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3772 */           if (str != null) {
/* 3773 */             this.labeledElementASTType = str;
/*      */           }
/*      */         } 
/*      */       } 
/* 3777 */       this.labeledElementType = "";
/* 3778 */       this.labeledElementInit = "None";
/* 3779 */       this.commonExtraArgs = "";
/* 3780 */       this.commonExtraParams = "self";
/* 3781 */       this.commonLocalVars = "";
/* 3782 */       this.lt1Value = "self.LT(1)";
/* 3783 */       this.exceptionThrown = "antlr.RecognitionException";
/* 3784 */       this.throwNoViable = "raise antlr.NoViableAltException(self.LT(1), self.getFilename())";
/* 3785 */       this.parserClassName = "Parser";
/* 3786 */       if (paramGrammar.hasOption("className")) {
/*      */         
/* 3788 */         Token token = paramGrammar.getOption("className");
/* 3789 */         if (token != null) {
/* 3790 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3791 */           if (str != null) {
/* 3792 */             this.parserClassName = str;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/* 3799 */     if (paramGrammar instanceof LexerGrammar) {
/*      */       
/* 3801 */       this.labeledElementType = "char ";
/* 3802 */       this.labeledElementInit = "'\\0'";
/* 3803 */       this.commonExtraArgs = "";
/* 3804 */       this.commonExtraParams = "self, _createToken";
/* 3805 */       this.commonLocalVars = "_ttype = 0\n        _token = None\n        _begin = self.text.length()";
/* 3806 */       this.lt1Value = "self.LA(1)";
/* 3807 */       this.exceptionThrown = "antlr.RecognitionException";
/* 3808 */       this.throwNoViable = "self.raise_NoViableAlt(self.LA(1))";
/* 3809 */       this.lexerClassName = "Lexer";
/* 3810 */       if (paramGrammar.hasOption("className")) {
/*      */         
/* 3812 */         Token token = paramGrammar.getOption("className");
/* 3813 */         if (token != null) {
/* 3814 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3815 */           if (str != null) {
/* 3816 */             this.lexerClassName = str;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/* 3823 */     if (paramGrammar instanceof TreeWalkerGrammar) {
/*      */       
/* 3825 */       this.labeledElementASTType = "";
/* 3826 */       this.labeledElementType = "";
/* 3827 */       if (paramGrammar.hasOption("ASTLabelType")) {
/* 3828 */         Token token = paramGrammar.getOption("ASTLabelType");
/* 3829 */         if (token != null) {
/* 3830 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3831 */           if (str != null) {
/* 3832 */             this.labeledElementASTType = str;
/* 3833 */             this.labeledElementType = str;
/*      */           } 
/*      */         } 
/*      */       } 
/* 3837 */       if (!paramGrammar.hasOption("ASTLabelType")) {
/* 3838 */         paramGrammar.setOption("ASTLabelType", new Token(6, "<4>AST"));
/*      */       }
/* 3840 */       this.labeledElementInit = "None";
/* 3841 */       this.commonExtraArgs = "_t";
/* 3842 */       this.commonExtraParams = "self, _t";
/* 3843 */       this.commonLocalVars = "";
/* 3844 */       this.lt1Value = "_t";
/* 3845 */       this.exceptionThrown = "antlr.RecognitionException";
/* 3846 */       this.throwNoViable = "raise antlr.NoViableAltException(_t)";
/* 3847 */       this.treeWalkerClassName = "Walker";
/* 3848 */       if (paramGrammar.hasOption("className")) {
/*      */         
/* 3850 */         Token token = paramGrammar.getOption("className");
/* 3851 */         if (token != null) {
/* 3852 */           String str = StringUtils.stripFrontBack(token.getText(), "\"", "\"");
/* 3853 */           if (str != null) {
/* 3854 */             this.treeWalkerClassName = str;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 3862 */     this.antlrTool.panic("Unknown grammar type");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setupOutput(String paramString) throws IOException {
/* 3870 */     this.currentOutput = this.antlrTool.openOutputFile(paramString + ".py");
/*      */   }
/*      */   
/*      */   protected boolean isspace(char paramChar) {
/* 3874 */     boolean bool = true;
/* 3875 */     switch (paramChar) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '\t':
/*      */       case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 3885 */         return bool;
/*      */     } 
/*      */     bool = false;
/*      */   } protected void _printAction(String paramString) {
/* 3889 */     if (paramString == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3903 */     byte b = 0;
/* 3904 */     int j = paramString.length();
/*      */ 
/*      */     
/* 3907 */     int i = 0;
/* 3908 */     boolean bool1 = true;
/*      */     
/* 3910 */     while (b < j && bool1) {
/*      */       
/* 3912 */       char c = paramString.charAt(b++);
/* 3913 */       switch (c) {
/*      */         case '\n':
/* 3915 */           i = b;
/*      */           continue;
/*      */         case '\r':
/* 3918 */           if (b <= j && paramString.charAt(b) == '\n')
/* 3919 */             b++; 
/* 3920 */           i = b;
/*      */           continue;
/*      */         
/*      */         case ' ':
/*      */           continue;
/*      */       } 
/* 3926 */       bool1 = false;
/*      */     } 
/*      */ 
/*      */     
/* 3930 */     if (!bool1) {
/* 3931 */       b--;
/*      */     }
/* 3933 */     i = b - i;
/*      */ 
/*      */     
/* 3936 */     j--;
/* 3937 */     while (j > b && isspace(paramString.charAt(j))) {
/* 3938 */       j--;
/*      */     }
/*      */     
/* 3941 */     boolean bool2 = false;
/*      */ 
/*      */     
/* 3944 */     for (int k = b; k <= j; k++) {
/*      */       
/* 3946 */       char c = paramString.charAt(k);
/* 3947 */       switch (c) {
/*      */         case '\n':
/* 3949 */           bool2 = true;
/*      */           break;
/*      */         case '\r':
/* 3952 */           bool2 = true;
/* 3953 */           if (k + 1 <= j && paramString.charAt(k + 1) == '\n') {
/* 3954 */             k++;
/*      */           }
/*      */           break;
/*      */         case '\t':
/* 3958 */           System.err.println("warning: tab characters used in Python action");
/* 3959 */           this.currentOutput.print("        ");
/*      */           break;
/*      */         case ' ':
/* 3962 */           this.currentOutput.print(" ");
/*      */           break;
/*      */         default:
/* 3965 */           this.currentOutput.print(c);
/*      */           break;
/*      */       } 
/*      */       
/* 3969 */       if (bool2) {
/*      */         
/* 3971 */         this.currentOutput.print("\n");
/* 3972 */         printTabs();
/* 3973 */         byte b1 = 0;
/* 3974 */         bool2 = false;
/*      */         
/* 3976 */         for (; ++k <= j; k++) {
/*      */           
/* 3978 */           c = paramString.charAt(k);
/* 3979 */           if (!isspace(c)) {
/* 3980 */             k--;
/*      */             break;
/*      */           } 
/* 3983 */           switch (c) {
/*      */             case '\n':
/* 3985 */               bool2 = true;
/*      */               break;
/*      */             case '\r':
/* 3988 */               if (k + 1 <= j && paramString.charAt(k + 1) == '\n') {
/* 3989 */                 k++;
/*      */               }
/* 3991 */               bool2 = true;
/*      */               break;
/*      */           } 
/*      */           
/* 3995 */           if (bool2) {
/*      */             
/* 3997 */             this.currentOutput.print("\n");
/* 3998 */             printTabs();
/* 3999 */             b1 = 0;
/* 4000 */             bool2 = false;
/*      */ 
/*      */           
/*      */           }
/* 4004 */           else if (b1 < i) {
/* 4005 */             b1++;
/*      */           } else {
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4015 */     this.currentOutput.println();
/*      */   }
/*      */   
/*      */   protected void od(String paramString1, int paramInt1, int paramInt2, String paramString2) {
/* 4019 */     System.out.println(paramString2);
/*      */     
/* 4021 */     for (int i = paramInt1; i <= paramInt2; i++) {
/*      */       
/* 4023 */       char c = paramString1.charAt(i);
/* 4024 */       switch (c) {
/*      */         case '\n':
/* 4026 */           System.out.print(" nl ");
/*      */           break;
/*      */         case '\t':
/* 4029 */           System.out.print(" ht ");
/*      */           break;
/*      */         case ' ':
/* 4032 */           System.out.print(" sp ");
/*      */           break;
/*      */         default:
/* 4035 */           System.out.print(" " + c + " "); break;
/*      */       } 
/*      */     } 
/* 4038 */     System.out.println("");
/*      */   }
/*      */   
/*      */   protected void printAction(String paramString) {
/* 4042 */     if (paramString != null) {
/* 4043 */       printTabs();
/* 4044 */       _printAction(paramString);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void printGrammarAction(Grammar paramGrammar) {
/* 4049 */     println("### user action >>>");
/* 4050 */     printAction(processActionForSpecialSymbols(paramGrammar.classMemberAction.getText(), paramGrammar.classMemberAction.getLine(), this.currentRule, (ActionTransInfo)null));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4057 */     println("### user action <<<");
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _printJavadoc(String paramString) {
/* 4062 */     int i = paramString.length();
/* 4063 */     byte b1 = 0;
/* 4064 */     boolean bool = false;
/*      */     
/* 4066 */     this.currentOutput.print("\n");
/* 4067 */     printTabs();
/* 4068 */     this.currentOutput.print("###");
/*      */     
/* 4070 */     for (byte b2 = b1; b2 < i; b2++) {
/*      */       
/* 4072 */       char c = paramString.charAt(b2);
/* 4073 */       switch (c) {
/*      */         case '\n':
/* 4075 */           bool = true;
/*      */           break;
/*      */         case '\r':
/* 4078 */           bool = true;
/* 4079 */           if (b2 + 1 <= i && paramString.charAt(b2 + 1) == '\n') {
/* 4080 */             b2++;
/*      */           }
/*      */           break;
/*      */         case '\t':
/* 4084 */           this.currentOutput.print("\t");
/*      */           break;
/*      */         case ' ':
/* 4087 */           this.currentOutput.print(" ");
/*      */           break;
/*      */         default:
/* 4090 */           this.currentOutput.print(c);
/*      */           break;
/*      */       } 
/*      */       
/* 4094 */       if (bool) {
/*      */         
/* 4096 */         this.currentOutput.print("\n");
/* 4097 */         printTabs();
/* 4098 */         this.currentOutput.print("###");
/* 4099 */         bool = false;
/*      */       } 
/*      */     } 
/*      */     
/* 4103 */     this.currentOutput.println();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genJavadocComment(Grammar paramGrammar) {
/* 4108 */     if (paramGrammar.comment != null) {
/* 4109 */       _printJavadoc(paramGrammar.comment);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void genJavadocComment(RuleSymbol paramRuleSymbol) {
/* 4115 */     if (paramRuleSymbol.comment != null)
/* 4116 */       _printJavadoc(paramRuleSymbol.comment); 
/*      */   }
/*      */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\PythonCodeGenerator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */