/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SemanticException
/*    */   extends RecognitionException
/*    */ {
/*    */   public SemanticException(String paramString) {
/* 12 */     super(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public SemanticException(String paramString1, String paramString2, int paramInt) {
/* 17 */     this(paramString1, paramString2, paramInt, -1);
/*    */   }
/*    */   
/*    */   public SemanticException(String paramString1, String paramString2, int paramInt1, int paramInt2) {
/* 21 */     super(paramString1, paramString2, paramInt1, paramInt2);
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\SemanticException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */