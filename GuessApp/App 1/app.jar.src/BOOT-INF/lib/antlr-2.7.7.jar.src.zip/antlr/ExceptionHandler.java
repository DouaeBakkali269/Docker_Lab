/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExceptionHandler
/*    */ {
/*    */   protected Token exceptionTypeAndName;
/*    */   protected Token action;
/*    */   
/*    */   public ExceptionHandler(Token paramToken1, Token paramToken2) {
/* 19 */     this.exceptionTypeAndName = paramToken1;
/* 20 */     this.action = paramToken2;
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ExceptionHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */