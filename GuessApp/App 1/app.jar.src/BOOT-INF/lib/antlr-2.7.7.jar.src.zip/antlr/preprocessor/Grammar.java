/*     */ package antlr.preprocessor;
/*     */ 
/*     */ import antlr.CodeGenerator;
/*     */ import antlr.Tool;
/*     */ import antlr.collections.impl.IndexedVector;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Grammar
/*     */ {
/*     */   protected String name;
/*     */   protected String fileName;
/*     */   protected String superGrammar;
/*     */   protected String type;
/*     */   protected IndexedVector rules;
/*     */   protected IndexedVector options;
/*     */   protected String tokenSection;
/*     */   protected String preambleAction;
/*     */   protected String memberAction;
/*     */   protected Hierarchy hier;
/*     */   protected boolean predefined = false;
/*     */   protected boolean alreadyExpanded = false;
/*     */   protected boolean specifiedVocabulary = false;
/*  34 */   protected String superClass = null;
/*     */   
/*  36 */   protected String importVocab = null;
/*  37 */   protected String exportVocab = null;
/*     */   protected Tool antlrTool;
/*     */   
/*     */   public Grammar(Tool paramTool, String paramString1, String paramString2, IndexedVector paramIndexedVector) {
/*  41 */     this.name = paramString1;
/*  42 */     this.superGrammar = paramString2;
/*  43 */     this.rules = paramIndexedVector;
/*  44 */     this.antlrTool = paramTool;
/*     */   }
/*     */   
/*     */   public void addOption(Option paramOption) {
/*  48 */     if (this.options == null) {
/*  49 */       this.options = new IndexedVector();
/*     */     }
/*  51 */     this.options.appendElement(paramOption.getName(), paramOption);
/*     */   }
/*     */   
/*     */   public void addRule(Rule paramRule) {
/*  55 */     this.rules.appendElement(paramRule.getName(), paramRule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandInPlace() {
/*  65 */     if (this.alreadyExpanded) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  70 */     Grammar grammar = getSuperGrammar();
/*  71 */     if (grammar == null)
/*     */       return; 
/*  73 */     if (this.exportVocab == null)
/*     */     {
/*  75 */       this.exportVocab = getName();
/*     */     }
/*  77 */     if (grammar.isPredefined())
/*     */       return; 
/*  79 */     grammar.expandInPlace();
/*     */ 
/*     */     
/*  82 */     this.alreadyExpanded = true;
/*     */     
/*  84 */     GrammarFile grammarFile = this.hier.getFile(getFileName());
/*  85 */     grammarFile.setExpanded(true);
/*     */ 
/*     */     
/*  88 */     IndexedVector indexedVector1 = grammar.getRules();
/*  89 */     for (Enumeration enumeration = indexedVector1.elements(); enumeration.hasMoreElements(); ) {
/*  90 */       Rule rule = enumeration.nextElement();
/*  91 */       inherit(rule, grammar);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  96 */     IndexedVector indexedVector2 = grammar.getOptions();
/*  97 */     if (indexedVector2 != null) {
/*  98 */       for (Enumeration enumeration1 = indexedVector2.elements(); enumeration1.hasMoreElements(); ) {
/*  99 */         Option option = enumeration1.nextElement();
/* 100 */         inherit(option, grammar);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 105 */     if ((this.options != null && this.options.getElement("importVocab") == null) || this.options == null) {
/*     */       
/* 107 */       Option option = new Option("importVocab", grammar.exportVocab + ";", this);
/* 108 */       addOption(option);
/*     */       
/* 110 */       String str1 = grammar.getFileName();
/* 111 */       String str2 = this.antlrTool.pathToFile(str1);
/* 112 */       String str3 = str2 + grammar.exportVocab + CodeGenerator.TokenTypesFileSuffix + CodeGenerator.TokenTypesFileExt;
/*     */ 
/*     */       
/* 115 */       String str4 = this.antlrTool.fileMinusPath(str3);
/* 116 */       if (!str2.equals("." + System.getProperty("file.separator"))) {
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */           
/* 122 */           this.antlrTool.copyFile(str3, str4);
/*     */         }
/* 124 */         catch (IOException iOException) {
/* 125 */           this.antlrTool.toolError("cannot find/copy importVocab file " + str3);
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 132 */     inherit(grammar.memberAction, grammar);
/*     */   }
/*     */   
/*     */   public String getFileName() {
/* 136 */     return this.fileName;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 140 */     return this.name;
/*     */   }
/*     */   
/*     */   public IndexedVector getOptions() {
/* 144 */     return this.options;
/*     */   }
/*     */   
/*     */   public IndexedVector getRules() {
/* 148 */     return this.rules;
/*     */   }
/*     */   
/*     */   public Grammar getSuperGrammar() {
/* 152 */     if (this.superGrammar == null) return null; 
/* 153 */     return this.hier.getGrammar(this.superGrammar);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSuperGrammarName() {
/* 158 */     return this.superGrammar;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 162 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void inherit(Option paramOption, Grammar paramGrammar) {
/* 167 */     if (paramOption.getName().equals("importVocab") || paramOption.getName().equals("exportVocab")) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 172 */     Option option = null;
/* 173 */     if (this.options != null) {
/* 174 */       option = (Option)this.options.getElement(paramOption.getName());
/*     */     }
/*     */     
/* 177 */     if (option == null) {
/* 178 */       addOption(paramOption);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void inherit(Rule paramRule, Grammar paramGrammar) {
/* 184 */     Rule rule = (Rule)this.rules.getElement(paramRule.getName());
/* 185 */     if (rule != null) {
/*     */       
/* 187 */       if (!rule.sameSignature(paramRule))
/*     */       {
/* 189 */         this.antlrTool.warning("rule " + getName() + "." + rule.getName() + " has different signature than " + paramGrammar.getName() + "." + rule.getName());
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 195 */       addRule(paramRule);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void inherit(String paramString, Grammar paramGrammar) {
/* 200 */     if (this.memberAction != null)
/* 201 */       return;  if (paramString != null) {
/* 202 */       this.memberAction = paramString;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isPredefined() {
/* 207 */     return this.predefined;
/*     */   }
/*     */   
/*     */   public void setFileName(String paramString) {
/* 211 */     this.fileName = paramString;
/*     */   }
/*     */   
/*     */   public void setHierarchy(Hierarchy paramHierarchy) {
/* 215 */     this.hier = paramHierarchy;
/*     */   }
/*     */   
/*     */   public void setMemberAction(String paramString) {
/* 219 */     this.memberAction = paramString;
/*     */   }
/*     */   
/*     */   public void setOptions(IndexedVector paramIndexedVector) {
/* 223 */     this.options = paramIndexedVector;
/*     */   }
/*     */   
/*     */   public void setPreambleAction(String paramString) {
/* 227 */     this.preambleAction = paramString;
/*     */   }
/*     */   
/*     */   public void setPredefined(boolean paramBoolean) {
/* 231 */     this.predefined = paramBoolean;
/*     */   }
/*     */   
/*     */   public void setTokenSection(String paramString) {
/* 235 */     this.tokenSection = paramString;
/*     */   }
/*     */   
/*     */   public void setType(String paramString) {
/* 239 */     this.type = paramString;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 243 */     StringBuffer stringBuffer = new StringBuffer(10000);
/* 244 */     if (this.preambleAction != null) {
/* 245 */       stringBuffer.append(this.preambleAction);
/*     */     }
/* 247 */     if (this.superGrammar == null) {
/* 248 */       return "class " + this.name + ";";
/*     */     }
/* 250 */     if (this.superClass != null) {
/*     */ 
/*     */       
/* 253 */       stringBuffer.append("class " + this.name + " extends " + this.superClass + ";");
/*     */     } else {
/*     */       
/* 256 */       stringBuffer.append("class " + this.name + " extends " + this.type + ";");
/*     */     } 
/* 258 */     stringBuffer.append(System.getProperty("line.separator") + System.getProperty("line.separator"));
/*     */ 
/*     */     
/* 261 */     if (this.options != null) {
/* 262 */       stringBuffer.append(Hierarchy.optionsToString(this.options));
/*     */     }
/* 264 */     if (this.tokenSection != null) {
/* 265 */       stringBuffer.append(this.tokenSection + "\n");
/*     */     }
/* 267 */     if (this.memberAction != null) {
/* 268 */       stringBuffer.append(this.memberAction + System.getProperty("line.separator"));
/*     */     }
/* 270 */     for (byte b = 0; b < this.rules.size(); b++) {
/* 271 */       Rule rule = (Rule)this.rules.elementAt(b);
/* 272 */       if (!getName().equals(rule.enclosingGrammar.getName())) {
/* 273 */         stringBuffer.append("// inherited from grammar " + rule.enclosingGrammar.getName() + System.getProperty("line.separator"));
/*     */       }
/* 275 */       stringBuffer.append(rule + System.getProperty("line.separator") + System.getProperty("line.separator"));
/*     */     } 
/*     */ 
/*     */     
/* 279 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\preprocessor\Grammar.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */