/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WildcardElement
/*    */   extends GrammarAtom
/*    */ {
/*    */   protected String label;
/*    */   
/*    */   public WildcardElement(Grammar paramGrammar, Token paramToken, int paramInt) {
/* 14 */     super(paramGrammar, paramToken, paramInt);
/* 15 */     this.line = paramToken.getLine();
/*    */   }
/*    */   
/*    */   public void generate() {
/* 19 */     this.grammar.generator.gen(this);
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 23 */     return this.label;
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 27 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */   
/*    */   public void setLabel(String paramString) {
/* 31 */     this.label = paramString;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 35 */     String str = " ";
/* 36 */     if (this.label != null) str = str + this.label + ":"; 
/* 37 */     return str + ".";
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\WildcardElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */