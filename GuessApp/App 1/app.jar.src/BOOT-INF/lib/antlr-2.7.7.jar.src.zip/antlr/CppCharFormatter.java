/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CppCharFormatter
/*    */   implements CharFormatter
/*    */ {
/*    */   public String escapeChar(int paramInt, boolean paramBoolean) {
/* 28 */     switch (paramInt) { case 10:
/* 29 */         return "\\n";
/* 30 */       case 9: return "\\t";
/* 31 */       case 13: return "\\r";
/* 32 */       case 92: return "\\\\";
/* 33 */       case 39: return "\\'";
/* 34 */       case 34: return "\\\""; }
/*    */     
/* 36 */     if (paramInt < 32 || paramInt > 126) {
/*    */       
/* 38 */       if (paramInt > 255) {
/*    */         
/* 40 */         String str = Integer.toString(paramInt, 16);
/*    */         
/* 42 */         while (str.length() < 4)
/* 43 */           str = '0' + str; 
/* 44 */         return "\\u" + str;
/*    */       } 
/*    */       
/* 47 */       return "\\" + Integer.toString(paramInt, 8);
/*    */     } 
/*    */ 
/*    */     
/* 51 */     return String.valueOf((char)paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String escapeString(String paramString) {
/* 65 */     String str = new String();
/* 66 */     for (byte b = 0; b < paramString.length(); b++) {
/* 67 */       str = str + escapeChar(paramString.charAt(b), false);
/*    */     }
/* 69 */     return str;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String literalChar(int paramInt) {
/* 78 */     String str = "0x" + Integer.toString(paramInt, 16);
/* 79 */     if (paramInt >= 0 && paramInt <= 126)
/* 80 */       str = str + " /* '" + escapeChar(paramInt, true) + "' */ "; 
/* 81 */     return str;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String literalString(String paramString) {
/* 94 */     return "\"" + escapeString(paramString) + "\"";
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\CppCharFormatter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */