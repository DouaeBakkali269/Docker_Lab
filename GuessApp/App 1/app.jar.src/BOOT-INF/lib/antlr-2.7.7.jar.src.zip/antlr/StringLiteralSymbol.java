/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringLiteralSymbol
/*    */   extends TokenSymbol
/*    */ {
/*    */   protected String label;
/*    */   
/*    */   public StringLiteralSymbol(String paramString) {
/* 15 */     super(paramString);
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 19 */     return this.label;
/*    */   }
/*    */   
/*    */   public void setLabel(String paramString) {
/* 23 */     this.label = paramString;
/*    */   }
/*    */ }


/* Location:              C:\Users\Usuario\Downloads\Lab001\GuessApp\App 1\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\StringLiteralSymbol.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */